﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  High-voltage sneaker detail.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private backBtn As SDUI5Button 'ignore
	Private buyBtn As SDUI5Button 'ignore
	Private bidBtn As SDUI5Button 'ignore
	Private selectedSize As String = "US 9.5"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with deep carbon background
	Dim page As SDUI5Container
	page.Initialize(Me, "detailPage", "detailPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_25px_60px_-15px_rgba(204,255,0,0.15)] bg-[#0D0E12] text-white font-['Plus_Jakarta_Sans',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top Navigation Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBarD", "topBarD")
	topBar.ParentID = "detailPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	backBtn.Initialize(Me, "backBtn", "backBtn")
	backBtn.ParentID = "topBarD"
	backBtn.Text = "< DROPS"
	backBtn.Classes = "btn-sm rounded-full bg-[#1A1D26] text-white border border-white/10 font-mono text-xs font-bold"
	BANano.Await(backBtn.AddComponent)

	Dim authBadge As SDUI5Badge
	authBadge.Initialize(Me, "authBadge", "authBadge")
	authBadge.ParentID = "topBarD"
	authBadge.Text = "VERIFIED DEADSTOCK"
	authBadge.Classes = "badge-sm rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-[10px]"
	BANano.Await(authBadge.AddComponent)

	' Hero Sneaker Image
	Dim heroWrap As SDUI5Container
	heroWrap.Initialize(Me, "heroWrap", "heroWrap")
	heroWrap.ParentID = "detailPage"
	heroWrap.Container = False
	heroWrap.Classes = "rounded-[28px] overflow-hidden bg-[#16181F] border border-white/10 p-3 my-4 relative shadow-2xl"
	BANano.Await(heroWrap.AddComponent)

	Dim hero As SDUI5Image
	hero.Initialize(Me, "detailHero", "detailHero")
	hero.ParentID = "heroWrap"
	hero.Src = "./assets/shoes.webp"
	hero.Alt = "Nike Air Zoom Pulse"
	hero.Classes = "w-full h-60 object-cover rounded-2xl"
	BANano.Await(hero.AddComponent)

	' Product Metadata
	Dim metaSec As SDUI5Container
	metaSec.Initialize(Me, "metaSec", "metaSec")
	metaSec.ParentID = "detailPage"
	metaSec.Container = False
	metaSec.Classes = "flex flex-col"
	BANano.Await(metaSec.AddComponent)

	BANano.Await(AddText("brandTag", "metaSec", "NIKE RUNNING // DROP 07", "p", "xs", "bold", "tracking-widest uppercase text-[#CCFF00] font-mono", "#CCFF00"))
	BANano.Await(AddText("detailTitle", "metaSec", "AIR ZOOM PULSE", "h1", "3xl", "black", "font-['Space_Grotesk'] tracking-tight text-white mt-1", "#FFFFFF"))

	Dim priceRow As SDUI5Container
	priceRow.Initialize(Me, "priceRow", "priceRow")
	priceRow.ParentID = "metaSec"
	priceRow.Container = False
	priceRow.Classes = "flex items-baseline gap-3 mt-1"
	BANano.Await(priceRow.AddComponent)

	BANano.Await(AddText("detailPrice", "priceRow", "$129.00", "p", "2xl", "black", "font-mono text-[#CCFF00]", "#CCFF00"))
	BANano.Await(AddText("detailRetail", "priceRow", "Retail $180 (Save 28%)", "span", "xs", "semibold", "text-neutral-400 line-through", "#A3A3A3"))

	' Size Selector Grid
	BANano.Await(AddText("sizeLabel", "detailPage", "SELECT SIZE (US MEN):", "h2", "xs", "bold", "tracking-wider uppercase text-neutral-400 font-mono mt-4 mb-2", "#A3A3A3"))

	Dim sizeGrid As SDUI5Container
	sizeGrid.Initialize(Me, "sizeGrid", "sizeGrid")
	sizeGrid.ParentID = "detailPage"
	sizeGrid.Container = False
	sizeGrid.Classes = "grid grid-cols-4 gap-2"
	BANano.Await(sizeGrid.AddComponent)

	BANano.Await(AddSizeChip("sz1", "sizeGrid", "US 8.5", False))
	BANano.Await(AddSizeChip("sz2", "sizeGrid", "US 9.0", False))
	BANano.Await(AddSizeChip("sz3", "sizeGrid", "US 9.5", True))
	BANano.Await(AddSizeChip("sz4", "sizeGrid", "US 10.0", False))

	' Buy / Bid Action Bar
	Dim ctlRow As SDUI5Container
	ctlRow.Initialize(Me, "ctlRowD", "ctlRowD")
	ctlRow.ParentID = "detailPage"
	ctlRow.Container = False
	ctlRow.Classes = "grid grid-cols-2 gap-3 mt-6"
	BANano.Await(ctlRow.AddComponent)

	bidBtn.Initialize(Me, "bidBtn", "bidBtn")
	bidBtn.ParentID = "ctlRowD"
	bidBtn.Text = "PLACE BID"
	bidBtn.Classes = "rounded-2xl bg-[#1A1D26] text-white font-mono font-bold text-xs py-3.5 border border-white/10"
	BANano.Await(bidBtn.AddComponent)

	buyBtn.Initialize(Me, "buyBtn", "buyBtn")
	buyBtn.ParentID = "ctlRowD"
	buyBtn.Text = "BUY NOW - $129"
	buyBtn.Classes = "rounded-2xl bg-[#CCFF00] text-black font-black text-xs py-3.5 shadow-lg shadow-lime-500/25 border-none"
	BANano.Await(buyBtn.AddComponent)

	BANano.Await(AddText("detailNote", "detailPage", "Includes NFC Authentic Chip Verification & Free Shipping", "p", "xs", "normal", "text-center text-neutral-500 mt-4", "#737373"))
	pgIndex.UpdateTitle("Air Zoom Pulse | Kickflip")
End Sub

Private Sub AddSizeChip(id As String, parentId As String, sizeText As String, isSel As Boolean)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = sizeText
	If isSel Then
		b.Classes = "rounded-xl bg-[#CCFF00] text-black font-mono font-black text-xs py-2 border-none"
	Else
		b.Classes = "rounded-xl bg-[#16181F] text-neutral-300 font-mono font-semibold text-xs py-2 border border-white/10 hover:border-lime-400"
	End If
	BANano.Await(b.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub backBtn_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgMarket.Show)
End Sub

Private Sub buyBtn_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Order placed for Nike Air Zoom Pulse (" & selectedSize & ")", 2500)
End Sub

Private Sub bidBtn_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalInfoToast("Bid placed at $115.00 for size " & selectedSize, 2000)
End Sub
