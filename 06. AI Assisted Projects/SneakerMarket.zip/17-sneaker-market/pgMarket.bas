﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  High-voltage sneaker market.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private cartBtn As SDUI5Button 'ignore
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with deep carbon background
	Dim page As SDUI5Container
	page.Initialize(Me, "marketPage", "marketPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_25px_60px_-15px_rgba(204,255,0,0.15)] bg-[#0D0E12] text-white font-['Plus_Jakarta_Sans',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top App Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "marketTop", "marketTop")
	topBar.ParentID = "marketPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	BANano.Await(AddText("brandName", "marketTop", "KICKFLIP // TOKYO", "h1", "xl", "black", "tracking-widest font-['Space_Grotesk'] text-[#CCFF00]", "#CCFF00"))

	cartBtn.Initialize(Me, "cartBtn", "cartBtn")
	cartBtn.ParentID = "marketTop"
	cartBtn.Text = "CART"
	cartBtn.Classes = "btn-sm rounded-full bg-[#1A1D26] text-white border border-white/10 font-bold"
	cartBtn.Badge = "3"
	BANano.Await(cartBtn.AddComponent)

	' Headline Section
	Dim heroHead As SDUI5Container
	heroHead.Initialize(Me, "heroHead", "heroHead")
	heroHead.ParentID = "marketPage"
	heroHead.Container = False
	heroHead.Classes = "mt-4"
	BANano.Await(heroHead.AddComponent)

	BANano.Await(AddText("marketHeadline", "heroHead", "HEAT DROPS ONLY.", "h2", "3xl", "black", "font-['Space_Grotesk'] uppercase tracking-tight text-white", "#FFFFFF"))
	BANano.Await(AddText("marketSub", "heroHead", "Verified Authentic Streetwear - Season 2026", "p", "xs", "semibold", "text-neutral-400 mt-1 uppercase tracking-wider", "#A3A3A3"))

	' State Switcher Bar
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "marketPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-3"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-[#1A1D26] text-neutral-300"
	Dim skelStyle As String = "bg-[#1A1D26] text-neutral-300"
	Dim empStyle As String = "bg-[#1A1D26] text-neutral-300"
	Dim errStyle As String = "bg-[#1A1D26] text-neutral-300"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-[#CCFF00] text-black font-black"
	Else If currentViewState = "empty" Then
		empStyle = "bg-[#CCFF00] text-black font-black"
	Else If currentViewState = "error" Then
		errStyle = "bg-[#CCFF00] text-black font-black"
	Else
		popStyle = "bg-[#CCFF00] text-black font-black"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "DROPS", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "SCANNING", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "SOLD OUT", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "API DOWN", errStyle))

	' Dynamic Content Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "marketPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-3"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("marketNote", "marketPage", "StockX & GOAT Pricing Telemetry | 100% Legit Check Guarantee", "p", "xs", "normal", "text-center text-neutral-500 mt-4", "#737373"))
	pgIndex.UpdateTitle("Kickflip Market | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-xl font-bold text-[10px] border-none " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	Dim grid As SDUI5Container
	grid.Initialize(Me, "marketGrid", "marketGrid")
	grid.ParentID = "contentWrapper"
	grid.Container = False
	grid.Classes = "grid grid-cols-2 gap-3"
	BANano.Await(grid.AddComponent)

	BANano.Await(AddDropCard("drop1", "marketGrid", "HOT DROP", "Air Zoom Pulse", "$129", "./assets/shoes.webp", "btnView1"))
	BANano.Await(AddDropCard("drop2", "marketGrid", "NEW COLOR", "Court Low Volt", "$149", "./assets/shoes1.jpg", "btnView2"))
	BANano.Await(AddDropCard("drop3", "marketGrid", "LIMITED 50", "Runner Flux Knit", "$99", "./assets/swiper_10.jpg", "btnView3"))
	BANano.Await(AddDropCard("drop4", "marketGrid", "RESTOCKED", "Skate High OG", "$119", "./assets/swiper_11.jpg", "btnView4"))
End Sub

Private Sub RenderSkeletonView
	Dim skelGrid As SDUI5Container
	skelGrid.Initialize(Me, "skelGrid", "skelGrid")
	skelGrid.ParentID = "contentWrapper"
	skelGrid.Container = False
	skelGrid.Classes = "grid grid-cols-2 gap-3"
	BANano.Await(skelGrid.AddComponent)

	For i = 1 To 4
		Dim skelCard As SDUI5Skeleton
		skelCard.Initialize(Me, "skelCard" & i, "skelCard" & i)
		skelCard.ParentID = "skelGrid"
		skelCard.Classes = "w-full h-52 rounded-2xl bg-[#1A1D26]"
		BANano.Await(skelCard.AddComponent)
	Next
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-[#16181F] border border-white/10 text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "ALL DROPS SOLD OUT"
	empTitle.Classes = "text-xl font-black uppercase text-white"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "Tonight's drop sold out in 42 seconds. Enable push notifications for the next drop queue."
	empMsg.Classes = "text-xs font-medium text-neutral-400 mt-2 max-w-xs leading-relaxed"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "NOTIFY NEXT DROP"
	empCta.Classes = "mt-5 rounded-full bg-[#CCFF00] text-black font-black text-xs px-6 py-3 shadow-lg shadow-lime-500/20 border-none"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-red-950/80 border border-red-500/30 text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "STOCK API DOWN"
	errTitle.Classes = "text-xl font-black uppercase text-red-300"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Unable to fetch live sneaker bids from the global order book. Check connection."
	errMsg.Classes = "text-xs font-medium text-red-200 mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "RECONNECT ORDER BOOK"
	errCta.Classes = "mt-5 rounded-full bg-red-600 text-white font-black text-xs px-6 py-3 shadow-lg shadow-red-500/30 border-none"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddDropCard(id As String, parentId As String, tagText As String, title As String, price As String, imgUrl As String, btnId As String)
	Dim card As SDUI5Container
	card.Initialize(Me, id, id)
	card.ParentID = parentId
	card.Container = False
	card.Classes = "rounded-[24px] p-3 bg-[#16181F] border border-white/10 flex flex-col justify-between hover:border-lime-400/50 transition-colors"
	BANano.Await(card.AddComponent)

	Dim imgWrap As SDUI5Container
	imgWrap.Initialize(Me, id & "Wrap", id & "Wrap")
	imgWrap.ParentID = id
	imgWrap.Container = False
	imgWrap.Classes = "relative rounded-2xl overflow-hidden bg-black/40"
	BANano.Await(imgWrap.AddComponent)

	Dim img As SDUI5Image
	img.Initialize(Me, id & "Img", id & "Img")
	img.ParentID = id & "Wrap"
	img.Src = imgUrl
	img.Alt = title
	img.Classes = "w-full h-32 object-cover"
	BANano.Await(img.AddComponent)

	Dim badge As SDUI5Badge
	badge.Initialize(Me, id & "Tag", id & "Tag")
	badge.ParentID = id
	badge.Text = tagText
	badge.Classes = "badge-xs rounded-full bg-[#CCFF00] text-black font-extrabold text-[9px] mt-2 border-none w-max"
	BANano.Await(badge.AddComponent)

	BANano.Await(AddText(id & "Title", id, title, "h3", "xs", "bold", "font-['Space_Grotesk'] text-white mt-1 truncate", "#FFFFFF"))
	BANano.Await(AddText(id & "Price", id, price, "p", "sm", "black", "text-[#CCFF00] font-mono mt-0.5", "#CCFF00"))

	Dim viewBtn As SDUI5Button
	viewBtn.Initialize(Me, btnId, btnId)
	viewBtn.ParentID = id
	viewBtn.Text = "VIEW DROP >"
	viewBtn.Classes = "mt-2.5 w-full rounded-xl bg-white/10 hover:bg-[#CCFF00] hover:text-black text-white font-mono font-bold text-[10px] py-1.5 transition-colors border-none"
	BANano.Await(viewBtn.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Drop reminder registered via SMS", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Order book restored with live bids", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub btnView1_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgDetail.Show)
End Sub

Private Sub btnView2_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgDetail.Show)
End Sub

Private Sub btnView3_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgDetail.Show)
End Sub

Private Sub btnView4_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgDetail.Show)
End Sub

Private Sub cartBtn_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalInfoToast("Your cart contains 3 reserved drops", 1500)
End Sub
