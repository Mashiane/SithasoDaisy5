﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
'=== pgLanding.bas ===
'App 1 - Award-Winning SithasoDaisy5 Developer SaaS Landing Page (ARCH-01).
'Components showcased: SDUI5Hero, SDUI5Card, SDUI5Stat, SDUI5Button, SDUI5Divider,
'SDUI5Footer, SDUI5Text, SDUI5Container, SDUI5Skeleton, SDUI5Badge.

Sub Process_Globals
	Private BANano As BANano	'ignore
	Private app As SDUI5App	'ignore

	Private currentViewState As String = "populated"
	Private heroCTA As SDUI5Button 'ignore
	Private bottomCTA As SDUI5Button 'ignore
End Sub

Sub Show
	app = pgIndex.App

	BANano.Await(app.ClearPageView)
	app.RemoveClass("w-screen")

	'Main Landing Viewport Container
	Dim mainContainer As SDUI5Container
	mainContainer.Initialize(Me, "mainContainer", "mainContainer")
	mainContainer.ParentID = app.PageView
	mainContainer.Container = False
	mainContainer.Classes = "mx-auto max-w-6xl px-4 py-4"
	BANano.Await(mainContainer.AddComponent)

	'Interactive State Switcher Deck (Demo & Quality Gate Evidence)
	Dim stateDeck As SDUI5Container
	stateDeck.Initialize(Me, "stateDeck", "stateDeck")
	stateDeck.ParentID = "mainContainer"
	stateDeck.Container = False
	stateDeck.Classes = "flex justify-center items-center gap-1.5 mb-4 p-1.5 rounded-2xl bg-base-200 border border-base-300 shadow-sm"
	BANano.Await(stateDeck.AddComponent)

	Dim popStyle As String = "btn-ghost"
	Dim skelStyle As String = "btn-ghost"
	Dim empStyle As String = "btn-ghost"
	Dim errStyle As String = "btn-ghost"

	If currentViewState = "skeleton" Then
		skelStyle = "btn-primary"
	Else If currentViewState = "empty" Then
		empStyle = "btn-primary"
	Else If currentViewState = "error" Then
		errStyle = "btn-primary"
	Else
		popStyle = "btn-primary"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateDeck", "LIVE DEMO", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateDeck", "SKELETON", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateDeck", "MAINTENANCE", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateDeck", "OFFLINE", errStyle))

	'Dynamic Content Host
	Dim contentHost As SDUI5Container
	contentHost.Initialize(Me, "contentHost", "contentHost")
	contentHost.ParentID = "mainContainer"
	contentHost.Container = False
	contentHost.Classes = "w-full"
	BANano.Await(contentHost.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	pgIndex.UpdateTitle("SithasoDaisy5 - Build Faster with B4J & BANano")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClass As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Size = "xs"
	b.Classes = "rounded-xl font-bold " & extraClass
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	'1. Hero Section: Local BackgroundImage + Overlay variant
	Dim heroBanner As SDUI5Hero
	heroBanner.Initialize(Me, "heroBanner", "heroBanner")
	heroBanner.ParentID = "contentHost"
	heroBanner.BackgroundImage = "./assets/photo-1507358522600.webp"
	heroBanner.Overlay = True
	heroBanner.ContentTextAlign = "center"
	heroBanner.Height = "440px"
	heroBanner.Rounded = "2xl"
	heroBanner.Classes = "overflow-hidden shadow-2xl border border-base-300"
	heroBanner.TextColor = "neutral-content"
	BANano.Await(heroBanner.AddComponent)

	Dim heroContent As SDUI5Container
	heroContent.Initialize(Me, "heroContent", "heroContent")
	heroContent.ParentID = "heroBanner_content"
	heroContent.Container = False
	heroContent.MaxWidth = "md"
	heroContent.Width = "full"
	heroContent.Classes = "w-full max-w-2xl px-6 flex flex-col items-center"
	BANano.Await(heroContent.AddComponent)

	Dim heroPill As SDUI5Badge
	heroPill.Initialize(Me, "heroPill", "heroPill")
	heroPill.ParentID = "heroContent"
	heroPill.Text = "NEW: SITHASODAISY5 + TAILWIND v4"
	heroPill.Color = "primary"
	heroPill.Classes = "badge-md rounded-full font-bold mb-4 shadow-md uppercase tracking-wider"
	BANano.Await(heroPill.AddComponent)

	Dim heroHeading As SDUI5Text
	heroHeading.Initialize(Me, "heroHeading", "heroHeading")
	heroHeading.ParentID = "heroContent"
	heroHeading.ApplyDefaults = False
	heroHeading.Text = "Build Web Apps 10x Faster"
	heroHeading.TextSize = "4xl"
	heroHeading.FontWeight = "extrabold"
	heroHeading.Classes = "max-w-full break-words sm:text-5xl tracking-tight text-white drop-shadow-md"
	heroHeading.TextTag = "h1"
	BANano.Await(heroHeading.AddComponent)

	Dim heroSub As SDUI5Text
	heroSub.Initialize(Me, "heroSub", "heroSub")
	heroSub.ParentID = "heroContent"
	heroSub.Text = "Write clean, type-safe B4J and compile directly to browser-native Web applications with 144 pre-built DaisyUI components."
	heroSub.Classes = "mt-4 text-sm sm:text-base text-neutral-200 max-w-xl text-center leading-relaxed"
	BANano.Await(heroSub.AddComponent)

	heroCTA.Initialize(Me, "heroCTA", "heroCTA")
	heroCTA.ParentID = "heroContent"
	heroCTA.Color = "primary"
	heroCTA.Size = "lg"
	heroCTA.Text = "Get Started Free"
	heroCTA.Classes = "mt-6 rounded-2xl font-bold shadow-lg shadow-primary/30"
	BANano.Await(heroCTA.AddComponent)

	'2. Section Divider
	Dim dividerWhy As SDUI5Divider
	dividerWhy.Initialize(Me, "dividerWhy", "dividerWhy")
	dividerWhy.ParentID = "contentHost"
	dividerWhy.Text = "Why Choose SithasoDaisy5"
	dividerWhy.Classes = "my-8 font-bold text-base-content/80"
	BANano.Await(dividerWhy.AddComponent)

	'3. 3-Column Developer Feature Cards Grid
	Dim featureRow As SDUI5Row
	featureRow.Initialize(Me, "featureRow", "featureRow")
	featureRow.ParentID = "contentHost"
	featureRow.Classes = "gap-4"
	BANano.Await(featureRow.AddComponent)

	'Card 1: Type-safe B4J
	Dim col1 As SDUI5Column
	col1.Initialize(Me, "col1", "col1")
	col1.ParentID = "featureRow"
	col1.Size = "12"
	col1.SizeMd = "4"
	BANano.Await(col1.AddComponent)

	Dim card1 As SDUI5Card
	card1.Initialize(Me, "card1", "card1")
	card1.ParentID = "col1"
	card1.Width = "full"
	card1.Title = "Type-safe B4J Language"
	card1.Content = "Enjoy compile-time checks, smart autocomplete, and clean syntax that transpiles directly into optimized JavaScript."
	card1.BackgroundColor = "primary"
	card1.TextColor = "primary-content"
	card1.MDSide = True
	card1.Image = "./assets/1.jpg"
	card1.Classes = "shadow-lg rounded-2xl h-full"
	BANano.Await(card1.AddComponent)

	'Card 2: 144 Components
	Dim col2 As SDUI5Column
	col2.Initialize(Me, "col2", "col2")
	col2.ParentID = "featureRow"
	col2.Size = "12"
	col2.SizeMd = "4"
	BANano.Await(col2.AddComponent)

	Dim card2 As SDUI5Card
	card2.Initialize(Me, "card2", "card2")
	card2.ParentID = "col2"
	card2.Width = "full"
	card2.Title = "144 Native Components"
	card2.Content = "Full coverage of daisyUI components with native reactivity, drawer navigation, modals, and rich charts."
	card2.BackgroundColor = "secondary"
	card2.TextColor = "secondary-content"
	card2.MDSide = True
	card2.Image = "./assets/2.jpg"
	card2.Classes = "shadow-lg rounded-2xl h-full"
	BANano.Await(card2.AddComponent)

	'Card 3: First-Time-Right
	Dim col3 As SDUI5Column
	col3.Initialize(Me, "col3", "col3")
	col3.ParentID = "featureRow"
	col3.Size = "12"
	col3.SizeMd = "4"
	BANano.Await(col3.AddComponent)

	Dim card3 As SDUI5Card
	card3.Initialize(Me, "card3", "card3")
	card3.ParentID = "col3"
	card3.Width = "full"
	card3.Title = "First-Time-Right Engine"
	card3.Content = "Built-in static pre-scanners and runtime Chrome CDP audits guarantee 0 horizontal overflows and 0 asset 404s."
	card3.BackgroundColor = "accent"
	card3.TextColor = "accent-content"
	card3.MDSide = True
	card3.Image = "./assets/3.jpg"
	card3.Classes = "shadow-lg rounded-2xl h-full"
	BANano.Await(card3.AddComponent)

	'4. Section Divider
	Dim dividerStats As SDUI5Divider
	dividerStats.Initialize(Me, "dividerStats", "dividerStats")
	dividerStats.ParentID = "contentHost"
	dividerStats.Text = "Trusted by Teams & Creators"
	dividerStats.Classes = "my-8 font-bold text-base-content/80"
	BANano.Await(dividerStats.AddComponent)

	'5. Responsive KPI Stat Grid
	Dim statBlock As SDUI5Stat
	statBlock.Initialize(Me, "statBlock", "statBlock")
	statBlock.ParentID = "contentHost"
	statBlock.Direction = "vertical"
	statBlock.LGDirection = "horizontal"
	statBlock.Shadow = "lg"
	statBlock.Border = True
	statBlock.BackgroundColor = "base-200"
	statBlock.RoundedBox = True
	statBlock.Classes = "w-full my-6 rounded-2xl"
	BANano.Await(statBlock.AddComponent)

	Dim stat1 As SDUI5StatItem
	stat1.Initialize(Me, "stat1", "stat1")
	stat1.ParentID = "statBlock"
	stat1.Title = "Components"
	stat1.Value = "144+"
	stat1.Desc = "Tested SDUI5* Classes"
	stat1.ValueTextColor = "primary"
	BANano.Await(stat1.AddComponent)

	Dim stat2 As SDUI5StatItem
	stat2.Initialize(Me, "stat2", "stat2")
	stat2.ParentID = "statBlock"
	stat2.Title = "Themes"
	stat2.Value = "35+"
	stat2.Desc = "Built-in DaisyUI Themes"
	stat2.ValueTextColor = "secondary"
	BANano.Await(stat2.AddComponent)

	Dim stat3 As SDUI5StatItem
	stat3.Initialize(Me, "stat3", "stat3")
	stat3.ParentID = "statBlock"
	stat3.Title = "Verified Demos"
	stat3.Value = "121"
	stat3.Desc = "Reference Implementations"
	stat3.ValueTextColor = "accent"
	BANano.Await(stat3.AddComponent)

	Dim stat4 As SDUI5StatItem
	stat4.Initialize(Me, "stat4", "stat4")
	stat4.ParentID = "statBlock"
	stat4.Title = "Quality Gates"
	stat4.Value = "100%"
	stat4.Desc = "Pass Rate on Dual Audit"
	stat4.ValueTextColor = "success"
	BANano.Await(stat4.AddComponent)

	'6. Primary Bottom CTA Row (accent rarity compliant)
	Dim ctaRow As SDUI5Container
	ctaRow.Initialize(Me, "ctaRow", "ctaRow")
	ctaRow.ParentID = "contentHost"
	ctaRow.Container = False
	ctaRow.Classes = "flex flex-col items-center text-center mt-10 p-8 rounded-3xl bg-base-200 border border-base-300 shadow-md"
	BANano.Await(ctaRow.AddComponent)

	Dim ctaTitle As SDUI5Text
	ctaTitle.Initialize(Me, "ctaTitle", "ctaTitle")
	ctaTitle.ParentID = "ctaRow"
	ctaTitle.Text = "Ready to Supercharge Your B4J Workflow?"
	ctaTitle.TextTag = "h2"
	ctaTitle.TextSize = "2xl"
	ctaTitle.FontWeight = "bold"
	ctaTitle.Classes = "text-base-content"
	BANano.Await(ctaTitle.AddComponent)

	bottomCTA.Initialize(Me, "bottomCTA", "bottomCTA")
	bottomCTA.ParentID = "ctaRow"
	bottomCTA.Text = "Download Framework"
	bottomCTA.Color = "accent"
	bottomCTA.Size = "lg"
	bottomCTA.Classes = "mt-4 rounded-2xl font-bold shadow-md shadow-accent/20"
	BANano.Await(bottomCTA.AddComponent)

	'7. Centered Footer
	Dim footerBar As SDUI5Footer
	footerBar.Initialize(Me, "footerBar", "footerBar")
	footerBar.ParentID = "contentHost"
	footerBar.PositionStyle = "none"
	footerBar.Center = True
	footerBar.Classes = "mt-12 p-6 text-base-content/70"
	BANano.Await(footerBar.AddComponent)

	Dim footerText As SDUI5Text
	footerText.Initialize(Me, "footerText", "footerText")
	footerText.ParentID = "footerBar"
	footerText.Text = "&copy; 2026 SithasoDaisy5. MIT Licensed. Crafted with B4J & BANano."
	footerText.TextSize = "sm"
	footerText.TextAlign = "center"
	BANano.Await(footerText.AddComponent)
End Sub

Private Sub RenderSkeletonView
	Dim skelHero As SDUI5Skeleton
	skelHero.Initialize(Me, "skelHero", "skelHero")
	skelHero.ParentID = "contentHost"
	skelHero.Classes = "w-full h-[400px] rounded-2xl mb-8"
	BANano.Await(skelHero.AddComponent)

	Dim skelGrid As SDUI5Container
	skelGrid.Initialize(Me, "skelGrid", "skelGrid")
	skelGrid.ParentID = "contentHost"
	skelGrid.Container = False
	skelGrid.Classes = "grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
	BANano.Await(skelGrid.AddComponent)

	For i = 1 To 3
		Dim skelCard As SDUI5Skeleton
		skelCard.Initialize(Me, "skelCard" & i, "skelCard" & i)
		skelCard.ParentID = "skelGrid"
		skelCard.Classes = "w-full h-48 rounded-2xl"
		BANano.Await(skelCard.AddComponent)
	Next

	Dim skelStat As SDUI5Skeleton
	skelStat.Initialize(Me, "skelStat", "skelStat")
	skelStat.ParentID = "contentHost"
	skelStat.Classes = "w-full h-24 rounded-2xl mb-6"
	BANano.Await(skelStat.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyBox As SDUI5Container
	emptyBox.Initialize(Me, "emptyBox", "emptyBox")
	emptyBox.ParentID = "contentHost"
	emptyBox.Container = False
	emptyBox.Classes = "flex flex-col items-center justify-center p-12 my-12 rounded-3xl bg-base-200 border border-base-300 text-center shadow-lg"
	BANano.Await(emptyBox.AddComponent)

	Dim emptyTitle As SDUI5Text
	emptyTitle.Initialize(Me, "emptyTitle", "emptyTitle")
	emptyTitle.ParentID = "emptyBox"
	emptyTitle.TextTag = "h2"
	emptyTitle.Text = "MAINTENANCE WINDOW IN PROGRESS"
	emptyTitle.TextSize = "xl"
	emptyTitle.FontWeight = "bold"
	emptyTitle.Classes = "text-base-content"
	BANano.Await(emptyTitle.AddComponent)

	Dim emptySub As SDUI5Text
	emptySub.Initialize(Me, "emptySub", "emptySub")
	emptySub.ParentID = "emptyBox"
	emptySub.Text = "We are updating our live component catalog. Please check back in a few minutes or switch back to Live Demo."
	emptySub.Classes = "text-sm text-base-content/70 mt-2 max-w-md"
	BANano.Await(emptySub.AddComponent)

	Dim btnReload As SDUI5Button
	btnReload.Initialize(Me, "btnReload", "btnReload")
	btnReload.ParentID = "emptyBox"
	btnReload.Text = "Return to Live Demo"
	btnReload.Color = "neutral"
	btnReload.Classes = "mt-5 rounded-2xl font-bold"
	BANano.Await(btnReload.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errBox As SDUI5Container
	errBox.Initialize(Me, "errBox", "errBox")
	errBox.ParentID = "contentHost"
	errBox.Container = False
	errBox.Classes = "flex flex-col items-center justify-center p-12 my-12 rounded-3xl bg-error/10 border border-error/30 text-center shadow-lg"
	BANano.Await(errBox.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errBox"
	errTitle.TextTag = "h2"
	errTitle.Text = "CANNOT REACH CLOUD SERVICES"
	errTitle.TextSize = "xl"
	errTitle.FontWeight = "bold"
	errTitle.Classes = "text-error"
	BANano.Await(errTitle.AddComponent)

	Dim errSub As SDUI5Text
	errSub.Initialize(Me, "errSub", "errSub")
	errSub.ParentID = "errBox"
	errSub.Text = "The live documentation server could not be reached (Error 503). Verify network connectivity."
	errSub.Classes = "text-sm text-base-content/70 mt-2 max-w-md"
	BANano.Await(errSub.AddComponent)

	Dim btnRetry As SDUI5Button
	btnRetry.Initialize(Me, "btnRetry", "btnRetry")
	btnRetry.ParentID = "errBox"
	btnRetry.Text = "Retry Connection"
	btnRetry.Color = "error"
	btnRetry.Classes = "mt-5 rounded-2xl font-bold"
	BANano.Await(btnRetry.AddComponent)
End Sub

'Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub btnReload_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnRetry_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Network reconnected", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub heroCTA_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Welcome to SithasoDaisy5! Initializing sandbox...", 2500)
End Sub

Private Sub bottomCTA_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Downloading SithasoDaisy5 Release Package...", 2500)
End Sub
