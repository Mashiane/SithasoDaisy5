﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'Static code module
'=== pgLanding.bas ===
'App 1 — Beginner landing page (ARCH-01).
'Components showcased: SDUI5Hero, SDUI5Card, SDUI5Stat, SDUI5Button, SDUI5Divider,
'SDUI5Footer, SDUI5Text (inside Hero content), SDUI5Container (Hero content host).
'NOTE: the local SDUI5App instance is lowercase `app` (matches the real reference
'demos AND the L5 lifecycle gate regex: BANano.Await(app.ClearPageView)).

Sub Process_Globals
    Private BANano As BANano	'ignore
    Private app As SDUI5App	'ignore

    Private SDUI5Container1 As SDUI5Container	'ignore
    Private SDUI5Hero1 As SDUI5Hero	'ignore
    Private SDUI5HeroContent1 As SDUI5Container	'ignore
    Private SDUI5Text1 As SDUI5Text	'ignore
    Private SDUI5Text2 As SDUI5Text	'ignore
    Private SDUI5HeroButton1 As SDUI5Button	'ignore
    Private SDUI5Divider1 As SDUI5Divider	'ignore
    Private SDUI5Row1 As SDUI5Row	'ignore
    Private SDUI5Column1 As SDUI5Column	'ignore
    Private SDUI5Column2 As SDUI5Column	'ignore
    Private SDUI5Column3 As SDUI5Column	'ignore
    Private SDUI5Card1 As SDUI5Card	'ignore
    Private SDUI5Card2 As SDUI5Card	'ignore
    Private SDUI5Card3 As SDUI5Card	'ignore
    Private SDUI5Stat1 As SDUI5Stat	'ignore
    Private SDUI5StatItem1 As SDUI5StatItem	'ignore
    Private SDUI5StatItem2 As SDUI5StatItem	'ignore
    Private SDUI5StatItem3 As SDUI5StatItem	'ignore
    Private SDUI5StatItem4 As SDUI5StatItem	'ignore
    Private SDUI5Divider2 As SDUI5Divider	'ignore
    Private SDUI5Row3 As SDUI5Container	'ignore
    Private SDUI5Button1 As SDUI5Button	'ignore
    Private SDUI5Footer1 As SDUI5Footer	'ignore
End Sub

Sub Show
    app = pgIndex.App

    BANano.Await(app.ClearPageView)
    app.RemoveClass("w-screen")

    SDUI5Container1.Initialize(Me, "SDUI5Container1", "SDUI5Container1")
    SDUI5Container1.ParentID = app.PageView
    SDUI5Container1.Classes = "mx-auto max-w-6xl p-4"
    BANano.Await(SDUI5Container1.AddComponent)

    '--- Hero: BackgroundImage + Overlay variant (mirrors pgHero.bas hero4) ---
    SDUI5Hero1.Initialize(Me, "SDUI5Hero1", "SDUI5Hero1")
    SDUI5Hero1.ParentID = "SDUI5Container1"
    SDUI5Hero1.BackgroundImage = "./assets/photo-1507358522600.webp"
    SDUI5Hero1.Overlay = True
    SDUI5Hero1.ContentTextAlign = "center"
    SDUI5Hero1.Height = "480px"
    SDUI5Hero1.Rounded = "lg"
    SDUI5Hero1.Classes = "overflow-hidden"
    SDUI5Hero1.Shadow = "lg"
    SDUI5Hero1.TextColor = "neutral-content"
    BANano.Await(SDUI5Hero1.AddComponent)

    SDUI5HeroContent1.Initialize(Me, "SDUI5HeroContent1", "SDUI5HeroContent1")
    SDUI5HeroContent1.ParentID = "SDUI5Hero1_content"
    SDUI5HeroContent1.Container = False
    SDUI5HeroContent1.MaxWidth = "md"
    BANano.Await(SDUI5HeroContent1.AddComponent)

    SDUI5Text1.Initialize(Me, "SDUI5Text1", "SDUI5Text1")
    SDUI5Text1.ParentID = "SDUI5HeroContent1"
    SDUI5Text1.ApplyDefaults = False
    SDUI5Text1.FontWeight = "bold"
    SDUI5Text1.Text = "Build web apps 10x faster"
    SDUI5Text1.TextSize = "5xl"
    SDUI5Text1.TextTag = "h1"
    BANano.Await(SDUI5Text1.AddComponent)

    SDUI5Text2.Initialize(Me, "SDUI5Text2", "SDUI5Text2")
    SDUI5Text2.ParentID = "SDUI5HeroContent1"
    SDUI5Text2.Text = "SithasoDaisy5 + BANano — 144 daisyUI components, one B4J language."
    SDUI5Text2.PaddingAXYTBLR = "a=?; x=?; y=6; t=?; b=?; l=?; r=?"
    BANano.Await(SDUI5Text2.AddComponent)

    SDUI5HeroButton1.Initialize(Me, "SDUI5HeroButton1", "SDUI5HeroButton1")
    SDUI5HeroButton1.ParentID = "SDUI5HeroContent1"
    SDUI5HeroButton1.Color = "primary"
    SDUI5HeroButton1.Size = "lg"
    SDUI5HeroButton1.Text = "Get Started"
    SDUI5HeroButton1.LeftIcon = ""
    BANano.Await(SDUI5HeroButton1.AddComponent)

    SDUI5Divider1.Initialize(Me, "SDUI5Divider1", "SDUI5Divider1")
    SDUI5Divider1.ParentID = "SDUI5Container1"
    SDUI5Divider1.Text = "Why choose us"
    BANano.Await(SDUI5Divider1.AddComponent)

    SDUI5Row1.Initialize(Me, "SDUI5Row1", "SDUI5Row1")
    SDUI5Row1.ParentID = "SDUI5Container1"
    SDUI5Row1.Classes = "gap-4"
    BANano.Await(SDUI5Row1.AddComponent)

    SDUI5Column1.Initialize(Me, "SDUI5Column1", "SDUI5Column1")
    SDUI5Column1.ParentID = "SDUI5Row1"
    SDUI5Column1.Size = "12"
    SDUI5Column1.SizeMd = "4"
    BANano.Await(SDUI5Column1.AddComponent)

    SDUI5Card1.Initialize(Me, "SDUI5Card1", "SDUI5Card1")
    SDUI5Card1.ParentID = "SDUI5Column1"
    SDUI5Card1.Width = "full"
    SDUI5Card1.Title = "Type-safe B4J"
    SDUI5Card1.Content = "Write B4J, BANano transpiles to clean browser JavaScript. No raw HTML, no hex colors."
    SDUI5Card1.BackgroundColor = "primary"
    SDUI5Card1.TextColor = "primary-content"
    SDUI5Card1.Side = True
    SDUI5Card1.Image = "./assets/1.jpg"
    BANano.Await(SDUI5Card1.AddComponent)

    SDUI5Column2.Initialize(Me, "SDUI5Column2", "SDUI5Column2")
    SDUI5Column2.ParentID = "SDUI5Row1"
    SDUI5Column2.Size = "12"
    SDUI5Column2.SizeMd = "4"
    BANano.Await(SDUI5Column2.AddComponent)

    SDUI5Card2.Initialize(Me, "SDUI5Card2", "SDUI5Card2")
    SDUI5Card2.ParentID = "SDUI5Column2"
    SDUI5Card2.Width = "full"
    SDUI5Card2.Title = "144 components"
    SDUI5Card2.Content = "Every daisyUI v5 + Tailwind v4 primitive as a thin B4J wrapper. Demonstrated, Documented-only, or Orphan — all classified."
    SDUI5Card2.BackgroundColor = "secondary"
    SDUI5Card2.TextColor = "secondary-content"
    SDUI5Card2.Side = True
    SDUI5Card2.Image = "./assets/2.jpg"
    BANano.Await(SDUI5Card2.AddComponent)

    SDUI5Column3.Initialize(Me, "SDUI5Column3", "SDUI5Column3")
    SDUI5Column3.ParentID = "SDUI5Row1"
    SDUI5Column3.Size = "12"
    SDUI5Column3.SizeMd = "4"
    BANano.Await(SDUI5Column3.AddComponent)

    SDUI5Card3.Initialize(Me, "SDUI5Card3", "SDUI5Card3")
    SDUI5Card3.ParentID = "SDUI5Column3"
    SDUI5Card3.Width = "full"
    SDUI5Card3.Title = "First-time-right"
    SDUI5Card3.Content = "Six-stage workflow + L4/L5 hard gates catch banned patterns before you ship."
    SDUI5Card3.BackgroundColor = "accent"
    SDUI5Card3.TextColor = "accent-content"
    SDUI5Card3.Side = True
    SDUI5Card3.Image = "./assets/3.jpg"
    BANano.Await(SDUI5Card3.AddComponent)

    SDUI5Divider2.Initialize(Me, "SDUI5Divider2", "SDUI5Divider2")
    SDUI5Divider2.ParentID = "SDUI5Container1"
    SDUI5Divider2.Text = "Trusted by teams"
    BANano.Await(SDUI5Divider2.AddComponent)

    SDUI5Stat1.Initialize(Me, "SDUI5Stat1", "SDUI5Stat1")
    SDUI5Stat1.ParentID = "SDUI5Container1"
    SDUI5Stat1.Direction = "vertical"
    SDUI5Stat1.LGDirection = "horizontal"
    SDUI5Stat1.Shadow = "md"
    SDUI5Stat1.Border = True
    SDUI5Stat1.BackgroundColor = "base-100"
    SDUI5Stat1.RoundedBox = True
    SDUI5Stat1.Classes = "w-full my-6"
    BANano.Await(SDUI5Stat1.AddComponent)

    SDUI5StatItem1.Initialize(Me, "SDUI5StatItem1", "SDUI5StatItem1")
    SDUI5StatItem1.ParentID = "SDUI5Stat1"
    SDUI5StatItem1.Title = "Components"
    SDUI5StatItem1.Value = "144"
    SDUI5StatItem1.Desc = "SDUI5* classes"
    SDUI5StatItem1.ValueTextColor = "primary"
    BANano.Await(SDUI5StatItem1.AddComponent)

    SDUI5StatItem2.Initialize(Me, "SDUI5StatItem2", "SDUI5StatItem2")
    SDUI5StatItem2.ParentID = "SDUI5Stat1"
    SDUI5StatItem2.Title = "Themes"
    SDUI5StatItem2.Value = "35+"
    SDUI5StatItem2.Desc = "daisyUI themes"
    SDUI5StatItem2.ValueTextColor = "secondary"
    BANano.Await(SDUI5StatItem2.AddComponent)

    SDUI5StatItem3.Initialize(Me, "SDUI5StatItem3", "SDUI5StatItem3")
    SDUI5StatItem3.ParentID = "SDUI5Stat1"
    SDUI5StatItem3.Title = "Demos"
    SDUI5StatItem3.Value = "121"
    SDUI5StatItem3.Desc = "verified pg*.bas"
    SDUI5StatItem3.ValueTextColor = "accent"
    BANano.Await(SDUI5StatItem3.AddComponent)

    SDUI5StatItem4.Initialize(Me, "SDUI5StatItem4", "SDUI5StatItem4")
    SDUI5StatItem4.ParentID = "SDUI5Stat1"
    SDUI5StatItem4.Title = "L4/L5 Gates"
    SDUI5StatItem4.Value = "100%"
    SDUI5StatItem4.Desc = "pass rate"
    SDUI5StatItem4.ValueTextColor = "success"
    BANano.Await(SDUI5StatItem4.AddComponent)

    SDUI5Row3.Initialize(Me, "SDUI5Row3", "SDUI5Row3")
    SDUI5Row3.ParentID = "SDUI5Container1"
    SDUI5Row3.Container = False
    SDUI5Row3.Classes = "flex justify-center mt-6"
    BANano.Await(SDUI5Row3.AddComponent)

    SDUI5Button1.Initialize(Me, "SDUI5Button1", "SDUI5Button1")
    SDUI5Button1.ParentID = "SDUI5Row3"
    SDUI5Button1.Text = "Get Started"
    SDUI5Button1.Color = "primary"
    SDUI5Button1.Size = "xl"
    SDUI5Button1.LeftIcon = ""
    BANano.Await(SDUI5Button1.AddComponent)

    SDUI5Footer1.Initialize(Me, "SDUI5Footer1", "SDUI5Footer1")
    SDUI5Footer1.ParentID = "SDUI5Container1"
    SDUI5Footer1.PositionStyle = "none"
    SDUI5Footer1.Center = True
    SDUI5Footer1.Classes = "mt-12 p-4"
    BANano.Await(SDUI5Footer1.AddComponent)

    Dim footerText As SDUI5Text
    footerText.Initialize(Me, "footerText", "footerText")
    footerText.ParentID = "SDUI5Footer1"
    footerText.Text = "SithasoDaisy5 — MIT licensed — build anything."
    footerText.TextSize = "sm"
    footerText.TextAlign = "center"
    BANano.Await(footerText.AddComponent)

    pgIndex.UpdateTitle("SithasoDaisy5 — Build faster")
End Sub

Sub SDUI5HeroButton1_Click(e As BANanoEvent)
    app.ShowSwalSuccess("Welcome to SithasoDaisy5! Let's get started.")
End Sub

Sub SDUI5Button1_Click(e As BANanoEvent)
    app.ShowSwalSuccess("Welcome to SithasoDaisy5! Let's get started.")
End Sub