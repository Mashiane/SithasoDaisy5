﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
'=== pgIndex.bas - page registry + minimal app shell ===
#IgnoreWarnings:12
Sub Process_Globals
	Public BANano As BANano		'ignore
	Public App As SDUI5App	'ignore
	Private pageView As SDUI5Container		'ignore
End Sub

Sub Initialize					'ignoreDeadCode
	BANano.Await(App.Initialize(Me))
	App.RemoveClass("w-screen")
	'load icons - the showcase pages use FontAwesome icons
	BANano.Await(App.UsesFontAwesome)
	'create the page host (id "pageview" so App.PageView = "#pageview" resolves)
	pageView.Initialize(Me, "pageview", "pageview")
	pageView.ParentID = App.Here
	pageView.Container = False
	BANano.Await(pageView.AddComponent)
	'show the app's landing page
	pgLanding.Show
	App.pageresume
End Sub

'update the document title
Sub UpdateTitle(s As String)
	BANano.Window.SetField("document.title", s)
End Sub
