﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Finance Dashboard (Light Mode Modern Fintech)
#IgnoreWarnings:12
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private savingsProgress As SDUI5Progress 'ignore
	Private currentViewState As String = "populated"
	Private contentWrapper As SDUI5Container 'ignore
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	'Root container with desktop mobile-phone chassis ergonomics
	Dim page As SDUI5Container
	page.Initialize(Me, "financePage", "financePage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-6 sm:rounded-[36px] sm:shadow-[0_20px_50px_rgba(15,118,110,0.12)] sm:border sm:border-emerald-900/10 overflow-hidden relative pb-10 bg-[#FBF9F5]"
	BANano.Await(page.AddComponent)

	'Header Section
	Dim headerBox As SDUI5Container
	headerBox.Initialize(Me, "headerBox", "headerBox")
	headerBox.ParentID = "financePage"
	headerBox.Container = False
	headerBox.Classes = "pt-6 px-6"
	BANano.Await(headerBox.AddComponent)

	BANano.Await(AddText("eyebrow", "headerBox", "SOVEREIGN WEALTH", "p", "xs", "semibold", "font-['Plus_Jakarta_Sans'] tracking-[0.2em]", "#0F766E"))
	BANano.Await(AddText("heading", "headerBox", "Good morning, Alex", "h1", "2xl", "bold", "font-['Plus_Jakarta_Sans'] mt-1 text-slate-900", "#0F172A"))
	BANano.Await(AddText("dateLine", "headerBox", "October Overview | Personal Account", "p", "xs", "normal", "mt-1", "#64748B"))

	'State Switcher Deck (Demonstrates 4-state completeness)
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "financePage"
	stateBar.Container = False
	stateBar.Classes = "flex items-center justify-center gap-1 mx-4 mt-3 p-1 rounded-xl bg-slate-200/50 border border-slate-300/60"
	BANano.Await(stateBar.AddComponent)

	BANano.Await(AddStateBtn("btnStatePopulated", "stateBar", "Populated", currentViewState = "populated"))
	BANano.Await(AddStateBtn("btnStateSkeleton", "stateBar", "Skeleton", currentViewState = "skeleton"))
	BANano.Await(AddStateBtn("btnStateEmpty", "stateBar", "Empty", currentViewState = "empty"))
	BANano.Await(AddStateBtn("btnStateError", "stateBar", "Error", currentViewState = "error"))

	'Dynamic Content Host
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "financePage"
	contentWrapper.Container = False
	contentWrapper.Classes = "w-full"
	BANano.Await(contentWrapper.AddComponent)

	'Render active state view
	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "financePage", "Illustrative figures only | Not connected to bank feed", "p", "xs", "normal", "text-center pb-4 mt-4", "#94A3B8"))

	pgIndex.UpdateTitle("Finance Dashboard")
End Sub

'--- VIEW 1: POPULATED SHOWCASE (Award-winning Modern Fintech) ---
Private Sub RenderPopulatedView
	'Card 1: Sovereign Teal Total Balance Card
	Dim balanceCard As SDUI5Container
	balanceCard.Initialize(Me, "balanceCard", "balanceCard")
	balanceCard.ParentID = "contentWrapper"
	balanceCard.Container = False
	balanceCard.Classes = "rounded-3xl p-6 mx-4 mt-4 bg-gradient-to-br from-[#0F766E] to-[#115E59] text-white shadow-[0_15px_30px_-5px_rgba(15,118,110,0.35)]"
	BANano.Await(balanceCard.AddComponent)

	Dim balTop As SDUI5Container
	balTop.Initialize(Me, "balTop", "balTop")
	balTop.ParentID = "balanceCard"
	balTop.Container = False
	balTop.Classes = "flex items-center justify-between"
	BANano.Await(balTop.AddComponent)
	BANano.Await(AddText("balanceLabel", "balTop", "TOTAL NET WORTH", "p", "xs", "semibold", "tracking-widest text-teal-200", "#CCFBF1"))

	Dim growthBadge As SDUI5Container
	growthBadge.Initialize(Me, "growthBadge", "growthBadge")
	growthBadge.ParentID = "balTop"
	growthBadge.Container = False
	growthBadge.Classes = "px-2.5 py-0.5 rounded-full bg-teal-400/20 text-teal-100 text-xs font-semibold border border-teal-300/30"
	BANano.Await(growthBadge.AddComponent)
	BANano.Await(AddText("growthText", "growthBadge", "+8.2% this month", "span", "xs", "semibold", "", "#F0FDFA"))

	BANano.Await(AddText("balanceValue", "balanceCard", "$24,680.50", "h2", "3xl", "bold", "font-['Plus_Jakarta_Sans'] mt-2 tracking-tight", "#FFFFFF"))
	BANano.Await(AddText("availableCash", "balanceCard", "Available cash: $18,240.00 | Investments: $6,440.50", "p", "xs", "normal", "mt-1 text-teal-100/80", "#CCFBF1"))

	'Quick Actions Row
	Dim actionsRow As SDUI5Container
	actionsRow.Initialize(Me, "actionsRow", "actionsRow")
	actionsRow.ParentID = "balanceCard"
	actionsRow.Container = False
	actionsRow.Classes = "grid grid-cols-4 gap-2 mt-5 pt-4 border-t border-teal-600/40"
	BANano.Await(actionsRow.AddComponent)

	BANano.Await(AddQuickAction("act1", "actionsRow", "Send", "bg-teal-700/60"))
	BANano.Await(AddQuickAction("act2", "actionsRow", "Receive", "bg-teal-700/60"))
	BANano.Await(AddQuickAction("act3", "actionsRow", "Top Up", "bg-teal-700/60"))
	BANano.Await(AddQuickAction("act4", "actionsRow", "Analytics", "bg-teal-700/60"))

	'Card 2: Monthly Spending Breakdown with Donut Chart
	Dim spendingCard As SDUI5Container
	spendingCard.Initialize(Me, "spendingCard", "spendingCard")
	spendingCard.ParentID = "contentWrapper"
	spendingCard.Container = False
	spendingCard.Classes = "rounded-3xl p-5 mx-4 mt-4 bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)] border border-slate-200/60"
	BANano.Await(spendingCard.AddComponent)

	Dim spendHead As SDUI5Container
	spendHead.Initialize(Me, "spendHead", "spendHead")
	spendHead.ParentID = "spendingCard"
	spendHead.Container = False
	spendHead.Classes = "flex items-center justify-between mb-3"
	BANano.Await(spendHead.AddComponent)
	BANano.Await(AddText("spendingTitle", "spendHead", "Monthly Spending", "h2", "base", "bold", "font-['Plus_Jakarta_Sans'] text-slate-900", "#0F172A"))
	BANano.Await(AddText("spendingTotal", "spendHead", "$2,495 | October", "span", "xs", "semibold", "text-slate-500", "#64748B"))

	Dim spendingRow As SDUI5Container
	spendingRow.Initialize(Me, "spendingRow", "spendingRow")
	spendingRow.ParentID = "spendingCard"
	spendingRow.Container = False
	spendingRow.Classes = "flex items-center gap-5"
	BANano.Await(spendingRow.AddComponent)

	'Visual Donut Chart
	Dim donut As SDUI5Container
	donut.Initialize(Me, "spendingDonut", "spendingDonut")
	donut.ParentID = "spendingRow"
	donut.Container = False
	donut.Classes = "w-28 h-28 rounded-full grid place-items-center shrink-0 shadow-inner"
	donut.Styles = "background=conic-gradient(#0F766E 0% 50%, #F43F5E 50% 77%, #F59E0B 77% 90%, #94A3B8 90% 100%)"
	BANano.Await(donut.AddComponent)

	Dim donutCenter As SDUI5Container
	donutCenter.Initialize(Me, "donutCenter", "donutCenter")
	donutCenter.ParentID = "spendingDonut"
	donutCenter.Container = False
	donutCenter.Classes = "w-20 h-20 rounded-full bg-white grid place-items-center text-center shadow-sm"
	BANano.Await(donutCenter.AddComponent)
	BANano.Await(AddText("donutCaption", "donutCenter", "$2,495", "span", "xs", "bold", "text-slate-900", "#0F172A"))

	'Legend Column
	Dim legend As SDUI5Container
	legend.Initialize(Me, "spendingLegend", "spendingLegend")
	legend.ParentID = "spendingRow"
	legend.Container = False
	legend.Classes = "flex flex-col gap-1.5 flex-1"
	BANano.Await(legend.AddComponent)

	BANano.Await(AddLegendItem("leg1", "spendingLegend", "Housing", "$1,250", "bg-[#0F766E]"))
	BANano.Await(AddLegendItem("leg2", "spendingLegend", "Dining", "$680", "bg-[#F43F5E]"))
	BANano.Await(AddLegendItem("leg3", "spendingLegend", "Transport", "$320", "bg-[#F59E0B]"))
	BANano.Await(AddLegendItem("leg4", "spendingLegend", "Other", "$245", "bg-[#94A3B8]"))

	'Card 3: Vacation Savings Goal
	Dim savingsCard As SDUI5Container
	savingsCard.Initialize(Me, "savingsCard", "savingsCard")
	savingsCard.ParentID = "contentWrapper"
	savingsCard.Container = False
	savingsCard.Classes = "rounded-3xl p-5 mx-4 mt-4 bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)] border border-slate-200/60"
	BANano.Await(savingsCard.AddComponent)

	Dim saveHead As SDUI5Container
	saveHead.Initialize(Me, "saveHead", "saveHead")
	saveHead.ParentID = "savingsCard"
	saveHead.Container = False
	saveHead.Classes = "flex items-center justify-between"
	BANano.Await(saveHead.AddComponent)
	BANano.Await(AddText("savingsTitle", "saveHead", "Vacation Savings Goal", "h2", "sm", "bold", "font-['Plus_Jakarta_Sans'] text-slate-900", "#0F172A"))
	BANano.Await(AddText("savingsPercent", "saveHead", "68% reached", "span", "xs", "bold", "text-[#0F766E]", "#0F766E"))

	BANano.Await(AddText("savingsAmount", "savingsCard", "$3,400 saved of $5,000 target", "p", "xs", "normal", "mt-1 mb-3 text-slate-500", "#64748B"))

	savingsProgress.Initialize(Me, "savingsProgress", "savingsProgress")
	savingsProgress.ParentID = "savingsCard"
	savingsProgress.Label = "Savings goal progress"
	savingsProgress.Value = 68
	savingsProgress.Color = "#0F766E"
	savingsProgress.Height = "8px"
	BANano.Await(savingsProgress.AddComponent)

	'Card 4: Expense Categories List
	Dim catCard As SDUI5Container
	catCard.Initialize(Me, "categoriesCard", "categoriesCard")
	catCard.ParentID = "contentWrapper"
	catCard.Container = False
	catCard.Classes = "rounded-3xl p-5 mx-4 mt-4 bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)] border border-slate-200/60"
	BANano.Await(catCard.AddComponent)

	BANano.Await(AddText("categoriesTitle", "categoriesCard", "Recent Category Outflows", "h2", "base", "bold", "font-['Plus_Jakarta_Sans'] mb-2 text-slate-900", "#0F172A"))

	BANano.Await(AddCategoryRow("housingRow", "categoriesCard", "Rent & Utilities", "Housing", "$1,250", "bg-emerald-100 text-emerald-800"))
	BANano.Await(AddCategoryRow("foodRow", "categoriesCard", "Supermarkets & Cafes", "Dining", "$680", "bg-rose-100 text-rose-800"))
	BANano.Await(AddCategoryRow("transportRow", "categoriesCard", "Subway & Rideshare", "Transit", "$320", "bg-amber-100 text-amber-800"))
	BANano.Await(AddCategoryRow("shoppingRow", "categoriesCard", "Gadgets & Apparel", "Retail", "$245", "bg-slate-100 text-slate-800"))
End Sub

'--- VIEW 2: LOADING SKELETON STATE ---
Private Sub RenderSkeletonView
	Dim skelCard1 As SDUI5Container
	skelCard1.Initialize(Me, "skelCard1", "skelCard1")
	skelCard1.ParentID = "contentWrapper"
	skelCard1.Container = False
	skelCard1.Classes = "rounded-3xl p-6 mx-4 mt-4 bg-slate-200/60 border border-slate-300/40"
	BANano.Await(skelCard1.AddComponent)

	Dim s1 As SDUI5Skeleton
	s1.Initialize(Me, "s1", "s1")
	s1.ParentID = "skelCard1"
	s1.Width = "8rem"
	s1.Height = "1rem"
	s1.Classes = "rounded-md mb-3 bg-slate-300"
	BANano.Await(s1.AddComponent)

	Dim s2 As SDUI5Skeleton
	s2.Initialize(Me, "s2", "s2")
	s2.ParentID = "skelCard1"
	s2.Width = "14rem"
	s2.Height = "2.5rem"
	s2.Classes = "rounded-md mb-4 bg-slate-300"
	BANano.Await(s2.AddComponent)

	Dim skelCard2 As SDUI5Container
	skelCard2.Initialize(Me, "skelCard2", "skelCard2")
	skelCard2.ParentID = "contentWrapper"
	skelCard2.Container = False
	skelCard2.Classes = "rounded-3xl p-6 mx-4 mt-4 bg-white shadow-sm border border-slate-200/60"
	BANano.Await(skelCard2.AddComponent)

	Dim s3 As SDUI5Skeleton
	s3.Initialize(Me, "s3", "s3")
	s3.ParentID = "skelCard2"
	s3.Width = "100%"
	s3.Height = "4rem"
	s3.Classes = "rounded-xl bg-slate-100"
	BANano.Await(s3.AddComponent)
End Sub

'--- VIEW 3: ILLUSTRATED EMPTY STATE ---
Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "rounded-3xl p-8 mx-4 mt-6 text-center bg-white shadow-sm border border-slate-200/60"
	BANano.Await(emptyCard.AddComponent)

	BANano.Await(AddText("emptyIcon", "emptyCard", "[ VAULT EMPTY ]", "div", "sm", "bold", "font-['Plus_Jakarta_Sans'] tracking-widest text-[#0F766E] mb-2", "#0F766E"))
	BANano.Await(AddText("emptyTitle", "emptyCard", "No Transactions Found", "h2", "xl", "bold", "font-['Plus_Jakarta_Sans'] text-slate-900", "#0F172A"))
	BANano.Await(AddText("emptyDesc", "emptyCard", "Connect your banking institution or add a transaction to begin real-time budget forecasting and automated category tracking.", "p", "xs", "normal", "mt-2 mb-6 max-w-xs mx-auto leading-relaxed text-slate-500", "#64748B"))

	Dim addBtn As SDUI5Button
	addBtn.Initialize(Me, "btnAddTransaction", "btnAddTransaction")
	addBtn.ParentID = "emptyCard"
	addBtn.Text = "Add First Transaction"
	addBtn.Block = True
	addBtn.Classes = "rounded-2xl font-semibold bg-[#0F766E] text-white shadow-md border-none"
	BANano.Await(addBtn.AddComponent)
End Sub

'--- VIEW 4: ACTIONABLE ERROR STATE ---
Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "rounded-3xl p-6 mx-4 mt-6 text-center bg-rose-50 border border-rose-200"
	BANano.Await(errCard.AddComponent)

	BANano.Await(AddText("errIcon", "errCard", "[ FEED SYNC OFFLINE ]", "div", "xs", "bold", "tracking-widest text-rose-600 mb-2", "#E11D48"))
	BANano.Await(AddText("errTitle", "errCard", "Banking Sync Interrupted", "h2", "lg", "bold", "font-['Plus_Jakarta_Sans'] text-slate-900", "#0F172A"))
	BANano.Await(AddText("errDesc", "errCard", "The Open Banking gateway timed out while fetching October statements. Re-authenticate credentials to resume live tracking.", "p", "xs", "normal", "mt-2 mb-6 leading-relaxed text-slate-600", "#475569"))

	Dim retryBtn As SDUI5Button
	retryBtn.Initialize(Me, "btnRetry", "btnRetry")
	retryBtn.ParentID = "errCard"
	retryBtn.Text = "Retry Account Sync"
	retryBtn.Block = True
	retryBtn.Classes = "rounded-2xl font-semibold bg-rose-600 text-white shadow-md border-none"
	BANano.Await(retryBtn.AddComponent)
End Sub

'--- EVENT HANDLERS ---
Private Sub btnAddTransaction_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnRetry_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStatePopulated_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStateSkeleton_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStateEmpty_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStateError_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

'--- REUSABLE BUILDERS ---
Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

Private Sub AddQuickAction(id As String, parentId As String, label As String, bgClass As String)
	Dim act As SDUI5Container
	act.Initialize(Me, id, id)
	act.ParentID = parentId
	act.Container = False
	act.Classes = bgClass & " p-2 rounded-xl text-center cursor-pointer hover:bg-teal-600/80 transition-colors"
	BANano.Await(act.AddComponent)
	BANano.Await(AddText(id & "Lbl", id, label, "p", "xs", "semibold", "text-white", "#FFFFFF"))
End Sub

Private Sub AddLegendItem(id As String, parentId As String, label As String, amount As String, dotClass As String)
	Dim row As SDUI5Container
	row.Initialize(Me, id, id)
	row.ParentID = parentId
	row.Container = False
	row.Classes = "flex items-center justify-between text-xs"
	BANano.Await(row.AddComponent)

	Dim leftBox As SDUI5Container
	leftBox.Initialize(Me, id & "Left", id & "Left")
	leftBox.ParentID = id
	leftBox.Container = False
	leftBox.Classes = "flex items-center gap-2"
	BANano.Await(leftBox.AddComponent)

	Dim dot As SDUI5Container
	dot.Initialize(Me, id & "Dot", id & "Dot")
	dot.ParentID = id & "Left"
	dot.Container = False
	dot.Classes = "w-2.5 h-2.5 rounded-full " & dotClass
	BANano.Await(dot.AddComponent)

	BANano.Await(AddText(id & "Lbl", id & "Left", label, "span", "xs", "medium", "text-slate-700", "#334155"))
	BANano.Await(AddText(id & "Amt", id, amount, "span", "xs", "bold", "text-slate-900", "#0F172A"))
End Sub

Private Sub AddCategoryRow(id As String, parentId As String, subtitle As String, category As String, amount As String, badgeClass As String)
	Dim row As SDUI5Container
	row.Initialize(Me, id, id)
	row.ParentID = parentId
	row.Container = False
	row.Classes = "flex items-center justify-between py-2.5 border-b border-slate-100 last:border-none"
	BANano.Await(row.AddComponent)

	Dim leftBox As SDUI5Container
	leftBox.Initialize(Me, id & "Left", id & "Left")
	leftBox.ParentID = id
	leftBox.Container = False
	leftBox.Classes = "flex items-center gap-3"
	BANano.Await(leftBox.AddComponent)

	Dim badge As SDUI5Container
	badge.Initialize(Me, id & "Badge", id & "Badge")
	badge.ParentID = id & "Left"
	badge.Container = False
	badge.Classes = "w-9 h-9 rounded-xl grid place-items-center text-xs font-bold " & badgeClass
	BANano.Await(badge.AddComponent)
	BANano.Await(AddText(id & "BadgeText", id & "Badge", category.SubString2(0, 1), "span", "xs", "bold", "", "#0F172A"))

	Dim textBox As SDUI5Container
	textBox.Initialize(Me, id & "Text", id & "Text")
	textBox.ParentID = id & "Left"
	textBox.Container = False
	BANano.Await(textBox.AddComponent)
	BANano.Await(AddText(id & "Cat", id & "Text", category, "p", "xs", "bold", "text-slate-900", "#0F172A"))
	BANano.Await(AddText(id & "Sub", id & "Text", subtitle, "p", "xs", "normal", "text-slate-400", "#94A3B8"))

	BANano.Await(AddText(id & "Amt", id, amount, "span", "sm", "bold", "text-slate-900", "#0F172A"))
End Sub

Private Sub AddStateBtn(id As String, parentId As String, label As String, isActive As Boolean)
	Dim btn As SDUI5Button
	btn.Initialize(Me, id, id)
	btn.ParentID = parentId
	btn.Text = label
	btn.TextSize = "xs"
	btn.Size = "xs"
	If isActive Then
		btn.Classes = "rounded-lg font-semibold bg-[#0F766E] text-white border-none px-2.5 py-1 shadow-sm"
	Else
		btn.Classes = "rounded-lg text-slate-600 hover:bg-slate-200/80 border-none px-2 py-1"
	End If
	BANano.Await(btn.AddComponent)
End Sub
