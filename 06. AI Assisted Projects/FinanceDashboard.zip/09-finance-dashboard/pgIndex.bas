﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public BANano As BANano 'ignore
	Public App As SDUI5App	'ignore
	Private pageView As SDUI5Container 'ignore
End Sub

Sub Initialize
	BANano.Await(App.Initialize(Me))
	App.RemoveClass("w-screen")
	App.AddClass("font-['Plus_Jakarta_Sans',sans-serif] antialiased min-h-screen bg-[#FBF9F5] text-slate-800 selection:bg-[#0F766E] selection:text-white")
	pageView.Initialize(Me, "pageview", "pageview")
	pageView.ParentID = App.Here
	pageView.Container = False
	BANano.Await(pageView.AddComponent)
	pgFinanceDashboard.Show
	App.pageresume
End Sub

Sub UpdateTitle(s As String)
	BANano.Window.SetField("document.title", s)
End Sub
