﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  weekly fitness summary.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private calorieRing As SDUI5RadialProgress 'ignore
	Private streakBadge As SDUI5Badge 'ignore
	Private userAvatar As SDUI5Avatar 'ignore
	Private btnLogWorkout As SDUI5Button 'ignore
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment
	Dim page As SDUI5Container
	page.Initialize(Me, "fitPage", "fitPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_20px_50px_-12px_rgba(43,33,24,0.15)] bg-[#FAF6F0] text-[#1C1917] font-['Plus_Jakarta_Sans',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top User Header Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBar", "topBar")
	topBar.ParentID = "fitPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	Dim userMetaRow As SDUI5Container
	userMetaRow.Initialize(Me, "userMetaRow", "userMetaRow")
	userMetaRow.ParentID = "topBar"
	userMetaRow.Container = False
	userMetaRow.Classes = "flex items-center gap-3"
	BANano.Await(userMetaRow.AddComponent)

	userAvatar.Initialize(Me, "userAvatar", "userAvatar")
	userAvatar.ParentID = "userMetaRow"
	userAvatar.AvatarType = "image"
	userAvatar.Image = "./assets/Angela.jpg"
	userAvatar.Mask = "circle"
	userAvatar.Size = "12"
	userAvatar.Ring = True
	userAvatar.RingColor = "#FF5A36"
	BANano.Await(userAvatar.AddComponent)

	Dim userMeta As SDUI5Container
	userMeta.Initialize(Me, "userMeta", "userMeta")
	userMeta.ParentID = "userMetaRow"
	userMeta.Container = False
	userMeta.Classes = "flex flex-col"
	BANano.Await(userMeta.AddComponent)

	BANano.Await(AddText("eyebrow", "userMeta", "WEEKLY METRICS", "p", "xs", "bold", "tracking-widest uppercase text-[#FF5A36]", "#FF5A36"))
	BANano.Await(AddText("heading", "userMeta", "Alex Morgan", "h1", "2xl", "extrabold", "tracking-tight text-[#1C1917]", "#1C1917"))

	streakBadge.Initialize(Me, "streakBadge", "streakBadge")
	streakBadge.ParentID = "topBar"
	streakBadge.Text = "12-DAY STREAK"
	streakBadge.Classes = "badge-md rounded-full bg-[#FF5A36] text-white font-extrabold text-xs shadow-md shadow-orange-500/20 border-none"
	BANano.Await(streakBadge.AddComponent)

	' State Switcher Deck
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "fitPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-4"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white text-stone-700 shadow-sm"
	Dim skelStyle As String = "bg-white text-stone-700 shadow-sm"
	Dim empStyle As String = "bg-white text-stone-700 shadow-sm"
	Dim errStyle As String = "bg-white text-stone-700 shadow-sm"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-[#1C1917] text-white"
	Else If currentViewState = "empty" Then
		empStyle = "bg-[#1C1917] text-white"
	Else If currentViewState = "error" Then
		errStyle = "bg-[#1C1917] text-white"
	Else
		popStyle = "bg-[#1C1917] text-white"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "ACTIVE", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "SYNCING", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "REST DAY", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "OFFLINE", errStyle))

	' Dynamic View Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "fitPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-4"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "fitPage", "Sample telemetry data | Synchronized with HealthKit", "p", "xs", "normal", "text-center text-stone-400 mt-4", "#A8A29E"))
	pgIndex.UpdateTitle("Fitness Dashboard | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-xl font-bold text-[10px] border-none " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Hero Ring Card (Warm Porcelain with Coral Radial Ring)
	Dim heroCard As SDUI5Container
	heroCard.Initialize(Me, "heroCard", "heroCard")
	heroCard.ParentID = "contentWrapper"
	heroCard.Container = False
	heroCard.Classes = "rounded-[28px] p-5 bg-white shadow-sm border border-stone-100 flex items-center justify-between"
	BANano.Await(heroCard.AddComponent)

	Dim ringInfo As SDUI5Container
	ringInfo.Initialize(Me, "ringInfo", "ringInfo")
	ringInfo.ParentID = "heroCard"
	ringInfo.Container = False
	ringInfo.Classes = "flex flex-col"
	BANano.Await(ringInfo.AddComponent)

	BANano.Await(AddText("heroLabel", "ringInfo", "CALORIES BURNED", "p", "xs", "bold", "tracking-wider text-stone-500", "#78716C"))
	BANano.Await(AddText("heroKcal", "ringInfo", "3,840", "h2", "3xl", "extrabold", "font-['Outfit'] text-[#1C1917] mt-0.5", "#1C1917"))
	BANano.Await(AddText("heroTarget", "ringInfo", "Goal: 5,600 kcal", "p", "xs", "semibold", "text-stone-400 mt-0.5", "#A8A29E"))

	Dim pacePill As SDUI5Badge
	pacePill.Initialize(Me, "pacePill", "pacePill")
	pacePill.ParentID = "ringInfo"
	pacePill.Text = "69% On Target"
	pacePill.Classes = "badge-sm rounded-full bg-orange-100 text-[#FF5A36] font-bold mt-3 border-none w-max"
	BANano.Await(pacePill.AddComponent)

	calorieRing.Initialize(Me, "calorieRing", "calorieRing")
	calorieRing.ParentID = "heroCard"
	calorieRing.Value = "69"
	calorieRing.Classes = "text-[#FF5A36]"
	calorieRing.ProgressSize = "7.5rem"
	calorieRing.ProgressThickness = "10px"
	BANano.Await(calorieRing.AddComponent)

	' Weekly Activity Summary Stat Row (3-column Bento)
	Dim bentoRow As SDUI5Container
	bentoRow.Initialize(Me, "bentoRow", "bentoRow")
	bentoRow.ParentID = "contentWrapper"
	bentoRow.Container = False
	bentoRow.Classes = "grid grid-cols-3 gap-2.5 mt-3"
	BANano.Await(bentoRow.AddComponent)

	BANano.Await(AddBentoStat("statSteps", "bentoRow", "Steps", "48,210", "+12%", "text-emerald-600", "bg-emerald-50"))
	BANano.Await(AddBentoStat("statWorkouts", "bentoRow", "Workouts", "5", "3 str / 2 run", "text-sky-600", "bg-sky-50"))
	BANano.Await(AddBentoStat("statTime", "bentoRow", "Active Time", "6.4h", "Avg 55m/d", "text-purple-600", "bg-purple-50"))

	' Daily Activity Bar Card
	Dim weekCard As SDUI5Container
	weekCard.Initialize(Me, "weekCard", "weekCard")
	weekCard.ParentID = "contentWrapper"
	weekCard.Container = False
	weekCard.Classes = "rounded-[28px] p-5 bg-white shadow-sm border border-stone-100 mt-3"
	BANano.Await(weekCard.AddComponent)

	Dim weekHead As SDUI5Container
	weekHead.Initialize(Me, "weekHead", "weekHead")
	weekHead.ParentID = "weekCard"
	weekHead.Container = False
	weekHead.Classes = "flex items-center justify-between mb-3"
	BANano.Await(weekHead.AddComponent)

	BANano.Await(AddText("weekTitle", "weekHead", "Daily Active Minutes", "h2", "sm", "bold", "text-[#1C1917]", "#1C1917"))
	BANano.Await(AddText("weekAvg", "weekHead", "Target: 45 min", "p", "xs", "semibold", "text-stone-400", "#A8A29E"))

	BANano.Await(AddDayBar("monBar", "weekCard", "Mon", "45 min", 56, "progress-neutral"))
	BANano.Await(AddDayBar("tueBar", "weekCard", "Tue", "30 min", 38, "progress-neutral"))
	BANano.Await(AddDayBar("wedBar", "weekCard", "Wed", "62 min", 78, "progress-primary"))
	BANano.Await(AddDayBar("thuBar", "weekCard", "Thu", "20 min", 25, "progress-neutral"))
	BANano.Await(AddDayBar("friBar", "weekCard", "Fri", "55 min", 69, "progress-neutral"))
	BANano.Await(AddDayBar("satBar", "weekCard", "Sat", "90 min (Peak)", 100, "progress-primary"))
	BANano.Await(AddDayBar("sunBar", "weekCard", "Sun", "40 min", 50, "progress-neutral"))

	' Bottom Quick Action Button
	btnLogWorkout.Initialize(Me, "btnLogWorkout", "btnLogWorkout")
	btnLogWorkout.ParentID = "contentWrapper"
	btnLogWorkout.Text = "+ RECORD WORKOUT"
	btnLogWorkout.Classes = "mt-4 w-full rounded-2xl bg-[#FF5A36] text-white font-extrabold text-sm py-3.5 shadow-lg shadow-orange-500/25 border-none"
	BANano.Await(btnLogWorkout.AddComponent)
End Sub

Private Sub RenderSkeletonView
	Dim skelHero As SDUI5Skeleton
	skelHero.Initialize(Me, "skelHero", "skelHero")
	skelHero.ParentID = "contentWrapper"
	skelHero.Classes = "w-full h-36 rounded-[28px] bg-stone-200/70"
	BANano.Await(skelHero.AddComponent)

	Dim skelBento As SDUI5Skeleton
	skelBento.Initialize(Me, "skelBento", "skelBento")
	skelBento.ParentID = "contentWrapper"
	skelBento.Classes = "w-full h-24 rounded-[28px] bg-stone-200/70 mt-3"
	BANano.Await(skelBento.AddComponent)

	Dim skelWeek As SDUI5Skeleton
	skelWeek.Initialize(Me, "skelWeek", "skelWeek")
	skelWeek.ParentID = "contentWrapper"
	skelWeek.Classes = "w-full h-64 rounded-[28px] bg-stone-200/70 mt-3"
	BANano.Await(skelWeek.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-white shadow-md border border-stone-100 text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "SCHEDULED RECOVERY DAY"
	empTitle.Classes = "text-xl font-black text-[#1C1917]"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "Muscles rebuild and consolidate gains during active recovery. Hydrate, stretch, or log a gentle walk."
	empMsg.Classes = "text-xs font-medium text-stone-500 mt-2 max-w-xs leading-relaxed"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "+ LOG GENTLE WALK"
	empCta.Classes = "mt-5 rounded-2xl bg-[#0284C7] text-white font-extrabold text-sm px-6 py-2.5 shadow-md shadow-sky-500/20 border-none"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-red-50 shadow-md border border-red-100 text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "CHEST STRAP DISCONNECTED"
	errTitle.Classes = "text-xl font-black text-red-900"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Bluetooth biometric stream halted. Ensure heart-rate band battery is above 10% and re-pair."
	errMsg.Classes = "text-xs font-medium text-red-600 mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "RECONNECT BLUETOOTH"
	errCta.Classes = "mt-5 rounded-2xl bg-red-600 text-white font-extrabold text-sm px-6 py-2.5 shadow-md shadow-red-500/20 border-none"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddBentoStat(id As String, parentId As String, title As String, value As String, subText As String, textAccent As String, bgAccent As String)
	Dim card As SDUI5Container
	card.Initialize(Me, id, id)
	card.ParentID = parentId
	card.Container = False
	card.Classes = "p-3 rounded-2xl bg-white border border-stone-100 shadow-sm flex flex-col justify-between"
	BANano.Await(card.AddComponent)

	BANano.Await(AddText(id & "Title", id, title, "p", "xs", "semibold", "text-stone-400 text-[11px]", "#A8A29E"))
	BANano.Await(AddText(id & "Val", id, value, "p", "lg", "extrabold", "font-['Outfit'] text-[#1C1917] mt-1", "#1C1917"))
	BANano.Await(AddText(id & "Sub", id, subText, "p", "xs", "bold", textAccent & " text-[10px] mt-0.5", "#10B981"))
End Sub

Private Sub AddDayBar(id As String, parentId As String, day As String, duration As String, pct As Int, barColorClass As String)
	Dim row As SDUI5Container
	row.Initialize(Me, id & "Row", id & "Row")
	row.ParentID = parentId
	row.Container = False
	row.Classes = "flex items-center gap-3 my-1.5"
	BANano.Await(row.AddComponent)

	Dim lbl As SDUI5Text
	lbl.Initialize(Me, id & "Lbl", id & "Lbl")
	lbl.ParentID = id & "Row"
	lbl.TextTag = "span"
	lbl.Text = day
	lbl.Classes = "w-8 text-xs font-bold text-stone-600 font-mono"
	BANano.Await(lbl.AddComponent)

	Dim bar As SDUI5Progress
	bar.Initialize(Me, id, id)
	bar.ParentID = id & "Row"
	bar.Value = pct
	bar.Height = "8px"
	bar.Classes = "flex-1 rounded-full " & barColorClass
	BANano.Await(bar.AddComponent)

	Dim dur As SDUI5Text
	dur.Initialize(Me, id & "Dur", id & "Dur")
	dur.ParentID = id & "Row"
	dur.TextTag = "span"
	dur.Text = duration
	dur.Classes = "w-24 text-right text-xs font-semibold text-stone-500 font-mono"
	BANano.Await(dur.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' State Switcher Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Gentle walk recorded: 3.2 km", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Biometric sensor reconnected", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub streakBadge_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Alex is on fire! 12 consecutive training days.", 2000)
End Sub

Private Sub btnLogWorkout_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Workout session saved: High Intensity Interval", 2000)
End Sub

Private Sub userAvatar_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Alex Morgan - Profile verified", 2000)
End Sub
