﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  trustworthy flight tracker.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with deep midnight aviation palette
	Dim page As SDUI5Container
	page.Initialize(Me, "flightPage", "flightPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_25px_60px_-15px_rgba(2,132,199,0.25)] bg-[#0A1128] text-white font-['Plus_Jakarta_Sans',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top Aviation Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBar", "topBar")
	topBar.ParentID = "flightPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	Dim fltMeta As SDUI5Container
	fltMeta.Initialize(Me, "fltMeta", "fltMeta")
	fltMeta.ParentID = "topBar"
	fltMeta.Container = False
	fltMeta.Classes = "flex flex-col"
	BANano.Await(fltMeta.AddComponent)

	BANano.Await(AddText("eyebrow", "fltMeta", "LUFTHANSA FLIGHT", "p", "xs", "bold", "tracking-widest uppercase text-cyan-400 font-mono", "#22D3EE"))
	BANano.Await(AddText("flightCode", "fltMeta", "LH 401", "h1", "2xl", "extrabold", "font-['Space_Grotesk'] tracking-tight text-white mt-0.5", "#FFFFFF"))

	Dim statusBadge As SDUI5Badge
	statusBadge.Initialize(Me, "statusBadge", "statusBadge")
	statusBadge.ParentID = "topBar"
	statusBadge.Text = "EN ROUTE - ON TIME"
	statusBadge.Classes = "badge-sm rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold"
	BANano.Await(statusBadge.AddComponent)

	' State Switcher Deck
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "flightPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-4"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white/10 text-cyan-200"
	Dim skelStyle As String = "bg-white/10 text-cyan-200"
	Dim empStyle As String = "bg-white/10 text-cyan-200"
	Dim errStyle As String = "bg-white/10 text-cyan-200"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-cyan-500 text-slate-950 font-bold"
	Else If currentViewState = "empty" Then
		empStyle = "bg-cyan-500 text-slate-950 font-bold"
	Else If currentViewState = "error" Then
		errStyle = "bg-cyan-500 text-slate-950 font-bold"
	Else
		popStyle = "bg-cyan-500 text-slate-950 font-bold"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "AIRBORNE", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "RADAR SCAN", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "LANDED", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "DIVERTED", errStyle))

	' Content Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "flightPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-4"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "flightPage", "ADS-B Ground Station Telemetry | Altitude Accuracy +/- 25ft", "p", "xs", "normal", "text-center text-slate-500 mt-4", "#64748B"))
	pgIndex.UpdateTitle("Flight Tracker | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-xl font-bold text-[10px] border-none " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Route Hero Card with Extra-Large Airport Codes
	Dim heroCard As SDUI5Container
	heroCard.Initialize(Me, "heroCard", "heroCard")
	heroCard.ParentID = "contentWrapper"
	heroCard.Container = False
	heroCard.Classes = "rounded-[28px] p-6 bg-gradient-to-br from-[#1C2541] to-[#0B132B] border border-cyan-500/20 shadow-xl"
	BANano.Await(heroCard.AddComponent)

	Dim airportRow As SDUI5Container
	airportRow.Initialize(Me, "airportRow", "airportRow")
	airportRow.ParentID = "heroCard"
	airportRow.Container = False
	airportRow.Classes = "flex items-center justify-between"
	BANano.Await(airportRow.AddComponent)

	Dim origBox As SDUI5Container
	origBox.Initialize(Me, "origBox", "origBox")
	origBox.ParentID = "airportRow"
	origBox.Container = False
	origBox.Classes = "flex flex-col"
	BANano.Await(origBox.AddComponent)

	BANano.Await(AddText("codeJFK", "origBox", "JFK", "h2", "4xl", "black", "font-['Space_Grotesk'] tracking-tight text-white", "#FFFFFF"))
	BANano.Await(AddText("cityJFK", "origBox", "New York", "p", "xs", "semibold", "text-cyan-300 mt-0.5", "#67E8F9"))
	BANano.Await(AddText("timeJFK", "origBox", "08:10 EDT", "p", "xs", "bold", "font-mono text-slate-400 mt-1", "#94A3B8"))

	Dim planePill As SDUI5Badge
	planePill.Initialize(Me, "planePill", "planePill")
	planePill.ParentID = "airportRow"
	planePill.Text = "> > [AIR] > >"
	planePill.Classes = "badge-md rounded-full bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 font-mono font-bold"
	BANano.Await(planePill.AddComponent)

	Dim destBox As SDUI5Container
	destBox.Initialize(Me, "destBox", "destBox")
	destBox.ParentID = "airportRow"
	destBox.Container = False
	destBox.Classes = "flex flex-col items-end text-right"
	BANano.Await(destBox.AddComponent)

	BANano.Await(AddText("codeFRA", "destBox", "FRA", "h2", "4xl", "black", "font-['Space_Grotesk'] tracking-tight text-white", "#FFFFFF"))
	BANano.Await(AddText("cityFRA", "destBox", "Frankfurt", "p", "xs", "semibold", "text-cyan-300 mt-0.5", "#67E8F9"))
	BANano.Await(AddText("timeFRA", "destBox", "22:05 CEST", "p", "xs", "bold", "font-mono text-slate-400 mt-1", "#94A3B8"))

	' Trajectory Progress
	Dim trajBox As SDUI5Container
	trajBox.Initialize(Me, "trajBox", "trajBox")
	trajBox.ParentID = "heroCard"
	trajBox.Container = False
	trajBox.Classes = "mt-5"
	BANano.Await(trajBox.AddComponent)

	Dim prog As SDUI5Progress
	prog.Initialize(Me, "fltProg", "fltProg")
	prog.ParentID = "trajBox"
	prog.Value = "62"
	prog.Height = "8px"
	prog.Classes = "rounded-full progress-info bg-slate-800"
	BANano.Await(prog.AddComponent)

	Dim progMeta As SDUI5Container
	progMeta.Initialize(Me, "progMeta", "progMeta")
	progMeta.ParentID = "trajBox"
	progMeta.Container = False
	progMeta.Classes = "flex justify-between items-center text-xs font-mono font-bold text-slate-400 mt-2"
	BANano.Await(progMeta.AddComponent)

	BANano.Await(AddText("elapTime", "progMeta", "Elapsed: 4h 12m", "span", "xs", "bold", "", "#94A3B8"))
	BANano.Await(AddText("remTime", "progMeta", "Remaining: 2h 14m", "span", "xs", "bold", "text-cyan-300", "#67E8F9"))

	' Flight Telemetry Bento Grid
	Dim bentoGrid As SDUI5Container
	bentoGrid.Initialize(Me, "bentoGrid", "bentoGrid")
	bentoGrid.ParentID = "contentWrapper"
	bentoGrid.Container = False
	bentoGrid.Classes = "grid grid-cols-2 gap-3 mt-3"
	BANano.Await(bentoGrid.AddComponent)

	BANano.Await(AddTelemetryCard("tcAlt", "bentoGrid", "ALTITUDE", "36,000 FT", "Cruising Flight Level 360", "text-cyan-400"))
	BANano.Await(AddTelemetryCard("tcSpd", "bentoGrid", "GROUND SPEED", "540 MPH", "Tailwind +24 kts", "text-emerald-400"))
	BANano.Await(AddTelemetryCard("tcCraft", "bentoGrid", "AIRCRAFT", "Boeing 747-8", "Reg: D-ABYA", "text-purple-300"))
	BANano.Await(AddTelemetryCard("tcEta", "bentoGrid", "ESTIMATED ARRIVAL", "22:05 CEST", "Gate B24 Ready", "text-amber-300"))

	' Boarding Pass & Cabin Card
	Dim passCard As SDUI5Container
	passCard.Initialize(Me, "passCard", "passCard")
	passCard.ParentID = "contentWrapper"
	passCard.Container = False
	passCard.Classes = "rounded-[24px] p-5 bg-white/5 border border-white/10 backdrop-blur-md mt-3"
	BANano.Await(passCard.AddComponent)

	Dim passHead As SDUI5Container
	passHead.Initialize(Me, "passHead", "passHead")
	passHead.ParentID = "passCard"
	passHead.Container = False
	passHead.Classes = "flex justify-between items-center mb-3"
	BANano.Await(passHead.AddComponent)

	BANano.Await(AddText("passTitle", "passHead", "BOARDING INFORMATION", "h3", "xs", "bold", "tracking-wider text-slate-400 uppercase", "#94A3B8"))
	BANano.Await(AddText("passClass", "passHead", "BUSINESS CLASS", "span", "xs", "bold", "text-cyan-400 font-mono", "#22D3EE"))

	Dim passDetails As SDUI5Container
	passDetails.Initialize(Me, "passDetails", "passDetails")
	passDetails.ParentID = "passCard"
	passDetails.Container = False
	passDetails.Classes = "grid grid-cols-3 gap-2 text-center"
	BANano.Await(passDetails.AddComponent)

	BANano.Await(AddPassPill("ppGate", "passDetails", "GATE", "B24"))
	BANano.Await(AddPassPill("ppSeat", "passDetails", "SEAT", "14A"))
	BANano.Await(AddPassPill("ppBag", "passDetails", "BAGGAGE", "BELT 4"))
End Sub

Private Sub RenderSkeletonView
	Dim skelHero As SDUI5Skeleton
	skelHero.Initialize(Me, "skelHero", "skelHero")
	skelHero.ParentID = "contentWrapper"
	skelHero.Classes = "w-full h-44 rounded-[28px] bg-slate-800/60"
	BANano.Await(skelHero.AddComponent)

	Dim skelBento As SDUI5Skeleton
	skelBento.Initialize(Me, "skelBento", "skelBento")
	skelBento.ParentID = "contentWrapper"
	skelBento.Classes = "w-full h-36 rounded-[24px] bg-slate-800/60 mt-3"
	BANano.Await(skelBento.AddComponent)

	Dim skelPass As SDUI5Skeleton
	skelPass.Initialize(Me, "skelPass", "skelPass")
	skelPass.ParentID = "contentWrapper"
	skelPass.Classes = "w-full h-32 rounded-[24px] bg-slate-800/60 mt-3"
	BANano.Await(skelPass.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-[#1C2541] border border-cyan-500/20 text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "FLIGHT TOUCHED DOWN"
	empTitle.Classes = "text-xl font-bold uppercase text-white"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "LH 401 has safely arrived at Frankfurt Gate B24. Baggage available on Belt 4."
	empMsg.Classes = "text-xs font-medium text-slate-300 mt-2 max-w-xs leading-relaxed"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "+ TRACK ANOTHER FLIGHT"
	empCta.Classes = "mt-5 rounded-full bg-cyan-400 text-slate-950 font-extrabold text-xs px-6 py-3 shadow-lg shadow-cyan-500/25 border-none"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-red-950/80 border border-red-500/30 text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "FLIGHT PATH DIVERTED"
	errTitle.Classes = "text-xl font-bold uppercase text-red-300"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Severe weather reported over North Sea corridor. LH 401 holds in holding stack Alpha."
	errMsg.Classes = "text-xs font-medium text-red-200 mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "VIEW RADAR OVERLAY"
	errCta.Classes = "mt-5 rounded-full bg-red-600 text-white font-extrabold text-xs px-6 py-3 shadow-lg shadow-red-500/30 border-none"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddTelemetryCard(id As String, parentId As String, title As String, value As String, subText As String, textAccent As String)
	Dim card As SDUI5Container
	card.Initialize(Me, id, id)
	card.ParentID = parentId
	card.Container = False
	card.Classes = "p-3.5 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between"
	BANano.Await(card.AddComponent)

	BANano.Await(AddText(id & "Title", id, title, "p", "xs", "bold", "text-slate-400 text-[10px] tracking-wider uppercase font-mono", "#94A3B8"))
	BANano.Await(AddText(id & "Val", id, value, "p", "lg", "extrabold", "font-['Space_Grotesk'] text-white mt-1", "#FFFFFF"))
	BANano.Await(AddText(id & "Sub", id, subText, "p", "xs", "medium", textAccent & " text-[10px] mt-0.5", "#67E8F9"))
End Sub

Private Sub AddPassPill(id As String, parentId As String, label As String, value As String)
	Dim pill As SDUI5Container
	pill.Initialize(Me, id, id)
	pill.ParentID = parentId
	pill.Container = False
	pill.Classes = "p-2 rounded-xl bg-white/5 border border-white/10"
	BANano.Await(pill.AddComponent)

	BANano.Await(AddText(id & "Lbl", id, label, "p", "xs", "bold", "text-slate-400 text-[10px] font-mono", "#94A3B8"))
	BANano.Await(AddText(id & "Val", id, value, "p", "sm", "extrabold", "text-white font-mono mt-0.5", "#FFFFFF"))
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Searching for connecting flight", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Radar stream refreshed", 2000)
	currentViewState = "populated"
	Show
End Sub
