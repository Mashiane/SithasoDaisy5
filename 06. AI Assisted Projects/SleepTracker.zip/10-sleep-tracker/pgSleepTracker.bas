﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Sleep Tracker Dashboard (Ethereal Glassmorphism)
#IgnoreWarnings:12
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private scoreRing As SDUI5RadialProgress 'ignore
	Private deepBar As SDUI5Progress 'ignore
	Private lightBar As SDUI5Progress 'ignore
	Private remBar As SDUI5Progress 'ignore
	Private smartAlarm As SDUI5Toggle 'ignore
	Private alarmBtn As SDUI5Button 'ignore
	Private currentViewState As String = "populated"
	Private contentWrapper As SDUI5Container 'ignore
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	'Root container with desktop mobile-phone chassis ergonomics & ethereal cosmic gradient
	Dim page As SDUI5Container
	page.Initialize(Me, "sleepPage", "sleepPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-6 sm:rounded-[36px] sm:shadow-[0_20px_60px_rgba(124,58,237,0.35)] sm:border sm:border-purple-500/20 overflow-hidden relative pb-10 bg-gradient-to-b from-[#221247] via-[#110926] to-[#080415]"
	BANano.Await(page.AddComponent)

	'Celestial Ambient Header
	Dim headerBox As SDUI5Container
	headerBox.Initialize(Me, "headerBox", "headerBox")
	headerBox.ParentID = "sleepPage"
	headerBox.Container = False
	headerBox.Classes = "pt-6 px-6 text-center"
	BANano.Await(headerBox.AddComponent)

	BANano.Await(AddText("eyebrow", "headerBox", "* SLEEP SANCTUARY *", "p", "xs", "semibold", "font-['Outfit'] tracking-[0.25em]", "#C4B5FD"))
	BANano.Await(AddText("heading", "headerBox", "Good night, Alex", "h1", "2xl", "bold", "font-['Outfit'] mt-1 text-white", "#FFFFFF"))
	BANano.Await(AddText("dateLine", "headerBox", "Last night | 7h 48m | Optimal rest", "p", "xs", "normal", "mt-1", "#A79BDB"))

	'State Switcher Deck (Demonstrates 4-state completeness)
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "sleepPage"
	stateBar.Container = False
	stateBar.Classes = "flex items-center justify-center gap-1 mx-4 mt-3 p-1 rounded-xl bg-white/5 border border-white/10"
	BANano.Await(stateBar.AddComponent)

	BANano.Await(AddStateBtn("btnStatePopulated", "stateBar", "Populated", currentViewState = "populated"))
	BANano.Await(AddStateBtn("btnStateSkeleton", "stateBar", "Skeleton", currentViewState = "skeleton"))
	BANano.Await(AddStateBtn("btnStateEmpty", "stateBar", "Empty", currentViewState = "empty"))
	BANano.Await(AddStateBtn("btnStateError", "stateBar", "Error", currentViewState = "error"))

	'Dynamic Content Host
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "sleepPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "w-full"
	BANano.Await(contentWrapper.AddComponent)

	'Render active state view
	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "sleepPage", "Illustrative figures only | Not a medical device", "p", "xs", "normal", "text-center pb-4 mt-4", "#7B6F9E"))

	pgIndex.UpdateTitle("Sleep Tracker")
End Sub

'--- VIEW 1: POPULATED SHOWCASE (Award-winning Ethereal Glassmorphism) ---
Private Sub RenderPopulatedView
	'Card 1: Sleep Quality Score & Breathing Aurora Circle
	BANano.Await(AddCard("scoreCard", "contentWrapper", "rounded-3xl p-5 mx-4 mt-4 text-center bg-white/5 backdrop-blur-xl border border-purple-400/20 shadow-[0_15px_35px_-10px_rgba(124,58,237,0.35)]"))
	BANano.Await(AddText("scoreLabel", "scoreCard", "RECOVERY SCORE", "p", "xs", "semibold", "font-['Outfit'] tracking-widest", "#DDD6FE"))

	'Glowing aura disc hosting radial progress
	Dim auraDisc As SDUI5Container
	auraDisc.Initialize(Me, "auraDisc", "auraDisc")
	auraDisc.ParentID = "scoreCard"
	auraDisc.Container = False
	auraDisc.Classes = "my-3 flex items-center justify-center relative"
	BANano.Await(auraDisc.AddComponent)

	scoreRing.Initialize(Me, "scoreRing", "scoreRing")
	scoreRing.ParentID = "auraDisc"
	scoreRing.Value = "88"
	scoreRing.Color = "#A855F7"
	scoreRing.ProgressSize = "10.5rem"
	scoreRing.ProgressThickness = "11px"
	scoreRing.TextColor = "#FFFFFF"
	scoreRing.Classes = "font-['Outfit'] font-bold drop-shadow-[0_0_20px_rgba(168,85,247,0.6)]"
	BANano.Await(scoreRing.AddComponent)

	Dim recoveryBadge As SDUI5Container
	recoveryBadge.Initialize(Me, "recoveryBadge", "recoveryBadge")
	recoveryBadge.ParentID = "scoreCard"
	recoveryBadge.Container = False
	recoveryBadge.Classes = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-semibold"
	BANano.Await(recoveryBadge.AddComponent)
	BANano.Await(AddText("badgeText", "recoveryBadge", "OPTIMAL RECOVERY", "span", "xs", "semibold", "", "#6EE7B7"))

	BANano.Await(AddText("scoreCaption", "scoreCard", "+6% vs last week | Deep sleep goal achieved", "p", "xs", "normal", "mt-2", "#C4B5FD"))

	'Vitals Snapshot Trio
	Dim vitalsRow As SDUI5Container
	vitalsRow.Initialize(Me, "vitalsRow", "vitalsRow")
	vitalsRow.ParentID = "contentWrapper"
	vitalsRow.Container = False
	vitalsRow.Classes = "grid grid-cols-3 gap-2 mx-4 mt-3"
	BANano.Await(vitalsRow.AddComponent)

	BANano.Await(AddVitalChip("chip1", "vitalsRow", "Efficiency", "94%", "#FDE047"))
	BANano.Await(AddVitalChip("chip2", "vitalsRow", "Resting HR", "54 bpm", "#FB7185"))
	BANano.Await(AddVitalChip("chip3", "vitalsRow", "Fell Asleep", "14 min", "#6EE7B7"))

	'Card 2: Sleep Stages Breakdown
	BANano.Await(AddCard("stagesCard", "contentWrapper", "rounded-3xl p-5 mx-4 mt-4 bg-white/5 backdrop-blur-xl border border-purple-400/20 shadow-[0_15px_35px_-10px_rgba(124,58,237,0.25)]"))

	Dim stagesHeader As SDUI5Container
	stagesHeader.Initialize(Me, "stagesHeader", "stagesHeader")
	stagesHeader.ParentID = "stagesCard"
	stagesHeader.Container = False
	stagesHeader.Classes = "flex items-center justify-between mb-3"
	BANano.Await(stagesHeader.AddComponent)
	BANano.Await(AddText("stagesTitle", "stagesHeader", "Sleep Stages", "h2", "base", "bold", "font-['Outfit']", "#FFFFFF"))
	BANano.Await(AddText("stagesDuration", "stagesHeader", "7h 48m total", "span", "xs", "semibold", "", "#C4B5FD"))

	'Deep Sleep Bar
	BANano.Await(AddStageHeader("deepHead", "stagesCard", "Deep Sleep - Restoration", "1h 45m (22%)", "#818CF8"))
	deepBar.Initialize(Me, "deepBar", "deepBar")
	deepBar.ParentID = "stagesCard"
	deepBar.Label = "Deep sleep progress"
	deepBar.Value = 22
	deepBar.Color = "#818CF8"
	deepBar.Height = "8px"
	BANano.Await(deepBar.AddComponent)

	'Light Sleep Bar
	BANano.Await(AddStageHeader("lightHead", "stagesCard", "Light Sleep - Mental Rest", "4h 18m (55%)", "#6EE7B7"))
	lightBar.Initialize(Me, "lightBar", "lightBar")
	lightBar.ParentID = "stagesCard"
	lightBar.Label = "Light sleep progress"
	lightBar.Value = 55
	lightBar.Color = "#6EE7B7"
	lightBar.Height = "8px"
	BANano.Await(lightBar.AddComponent)

	'REM Sleep Bar
	BANano.Await(AddStageHeader("remHead", "stagesCard", "REM Sleep - Dreams & Memory", "1h 45m (23%)", "#C084FC"))
	remBar.Initialize(Me, "remBar", "remBar")
	remBar.ParentID = "stagesCard"
	remBar.Label = "REM sleep progress"
	remBar.Value = 23
	remBar.Color = "#C084FC"
	remBar.Height = "8px"
	BANano.Await(remBar.AddComponent)

	'Card 3: Smart Sleep Alarm
	BANano.Await(AddCard("alarmCard", "contentWrapper", "rounded-3xl p-5 mx-4 mt-4 bg-white/5 backdrop-blur-xl border border-amber-300/20 shadow-[0_15px_35px_-10px_rgba(250,204,21,0.15)]"))

	Dim alarmHead As SDUI5Container
	alarmHead.Initialize(Me, "alarmHead", "alarmHead")
	alarmHead.ParentID = "alarmCard"
	alarmHead.Container = False
	alarmHead.Classes = "flex items-center justify-between"
	BANano.Await(alarmHead.AddComponent)
	BANano.Await(AddText("alarmTitle", "alarmHead", "Smart Cycle Alarm", "h2", "base", "bold", "font-['Outfit']", "#FFFFFF"))
	BANano.Await(AddText("alarmWindow", "alarmHead", "6:15 - 6:45 AM", "span", "xs", "semibold", "px-2.5 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/25", "#FDE047"))

	BANano.Await(AddText("alarmTime", "alarmCard", "6:45 AM", "p", "3xl", "bold", "font-['Outfit'] mt-2 tracking-tight", "#FDE047"))
	BANano.Await(AddText("alarmDesc", "alarmCard", "Wakes you gently during the lightest sleep phase", "p", "xs", "normal", "mt-0.5 mb-3", "#C4B5FD"))

	smartAlarm.Initialize(Me, "smartAlarm", "smartAlarm")
	smartAlarm.ParentID = "alarmCard"
	smartAlarm.Label = "Gentle wake window active"
	smartAlarm.Checked = True
	smartAlarm.Color = "#A855F7"
	smartAlarm.ToggleType = "normal"
	BANano.Await(smartAlarm.AddComponent)

	alarmBtn.Initialize(Me, "alarmBtn", "alarmBtn")
	alarmBtn.ParentID = "alarmCard"
	alarmBtn.Text = "Snooze 10 min | Gentle Chime"
	alarmBtn.Block = True
	alarmBtn.Classes = "mt-4 rounded-2xl font-semibold shadow-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-900/40 border-none"
	BANano.Await(alarmBtn.AddComponent)
End Sub

'--- VIEW 2: LOADING SKELETON STATE ---
Private Sub RenderSkeletonView
	Dim skelCard1 As SDUI5Container
	skelCard1.Initialize(Me, "skelCard1", "skelCard1")
	skelCard1.ParentID = "contentWrapper"
	skelCard1.Container = False
	skelCard1.Classes = "rounded-3xl p-6 mx-4 mt-4 flex flex-col items-center bg-white/5 border border-white/10"
	BANano.Await(skelCard1.AddComponent)

	Dim s1 As SDUI5Skeleton
	s1.Initialize(Me, "s1", "s1")
	s1.ParentID = "skelCard1"
	s1.Width = "6rem"
	s1.Height = "1rem"
	s1.Classes = "rounded-md mb-4 bg-white/10"
	BANano.Await(s1.AddComponent)

	Dim sRing As SDUI5Skeleton
	sRing.Initialize(Me, "sRing", "sRing")
	sRing.ParentID = "skelCard1"
	sRing.Width = "10rem"
	sRing.Height = "10rem"
	sRing.Classes = "rounded-full mb-4 bg-white/10"
	BANano.Await(sRing.AddComponent)

	Dim s2 As SDUI5Skeleton
	s2.Initialize(Me, "s2", "s2")
	s2.ParentID = "skelCard1"
	s2.Width = "12rem"
	s2.Height = "1rem"
	s2.Classes = "rounded-md bg-white/10"
	BANano.Await(s2.AddComponent)

	Dim skelCard2 As SDUI5Container
	skelCard2.Initialize(Me, "skelCard2", "skelCard2")
	skelCard2.ParentID = "contentWrapper"
	skelCard2.Container = False
	skelCard2.Classes = "rounded-3xl p-6 mx-4 mt-4 bg-white/5 border border-white/10"
	BANano.Await(skelCard2.AddComponent)

	Dim s3 As SDUI5Skeleton
	s3.Initialize(Me, "s3", "s3")
	s3.ParentID = "skelCard2"
	s3.Width = "8rem"
	s3.Height = "1.25rem"
	s3.Classes = "rounded-md mb-4 bg-white/10"
	BANano.Await(s3.AddComponent)

	Dim sBar1 As SDUI5Skeleton
	sBar1.Initialize(Me, "sBar1", "sBar1")
	sBar1.ParentID = "skelCard2"
	sBar1.Width = "100%"
	sBar1.Height = "0.75rem"
	sBar1.Classes = "rounded-md mb-3 bg-white/10"
	BANano.Await(sBar1.AddComponent)

	Dim sBar2 As SDUI5Skeleton
	sBar2.Initialize(Me, "sBar2", "sBar2")
	sBar2.ParentID = "skelCard2"
	sBar2.Width = "100%"
	sBar2.Height = "0.75rem"
	sBar2.Classes = "rounded-md mb-3 bg-white/10"
	BANano.Await(sBar2.AddComponent)

	Dim sBar3 As SDUI5Skeleton
	sBar3.Initialize(Me, "sBar3", "sBar3")
	sBar3.ParentID = "skelCard2"
	sBar3.Width = "100%"
	sBar3.Height = "0.75rem"
	sBar3.Classes = "rounded-md bg-white/10"
	BANano.Await(sBar3.AddComponent)
End Sub

'--- VIEW 3: ILLUSTRATED EMPTY STATE ---
Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "rounded-3xl p-8 mx-4 mt-6 text-center bg-white/5 border border-white/10"
	BANano.Await(emptyCard.AddComponent)

	BANano.Await(AddText("emptyIcon", "emptyCard", "[ MOONLIGHT SANCTUARY ]", "div", "sm", "bold", "font-['Outfit'] tracking-widest mb-3", "#A855F7"))
	BANano.Await(AddText("emptyTitle", "emptyCard", "No Sleep Session Tracked", "h2", "xl", "bold", "font-['Outfit'] text-white", "#FFFFFF"))
	BANano.Await(AddText("emptyDesc", "emptyCard", "Place your sensor beside your bed before sleep to track restorative stages, light-sleep alarms, and heart recovery.", "p", "xs", "normal", "mt-2 mb-6 max-w-xs mx-auto leading-relaxed", "#C4B5FD"))

	Dim startBtn As SDUI5Button
	startBtn.Initialize(Me, "btnStartTracking", "btnStartTracking")
	startBtn.ParentID = "emptyCard"
	startBtn.Text = "Begin Night Session"
	startBtn.Block = True
	startBtn.Classes = "rounded-2xl font-semibold shadow-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-900/40 border-none"
	BANano.Await(startBtn.AddComponent)
End Sub

'--- VIEW 4: ACTIONABLE ERROR STATE ---
Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "rounded-3xl p-6 mx-4 mt-6 text-center bg-red-950/20 border border-red-500/30"
	BANano.Await(errCard.AddComponent)

	BANano.Await(AddText("errIcon", "errCard", "[ SENSOR SYNC OFFLINE ]", "div", "xs", "bold", "tracking-widest text-rose-400 mb-2", "#FB7185"))
	BANano.Await(AddText("errTitle", "errCard", "Unable to Sync Night Data", "h2", "lg", "bold", "font-['Outfit'] text-white", "#FFFFFF"))
	BANano.Await(AddText("errDesc", "errCard", "The sleep tracking hub timed out while communicating with the bedside BLE sensor. Check Bluetooth proximity.", "p", "xs", "normal", "mt-2 mb-6 leading-relaxed", "#E2E8F0"))

	Dim retryBtn As SDUI5Button
	retryBtn.Initialize(Me, "btnRetry", "btnRetry")
	retryBtn.ParentID = "errCard"
	retryBtn.Text = "Retry Sensor Connection"
	retryBtn.Block = True
	retryBtn.Classes = "rounded-2xl font-semibold bg-rose-400 text-black shadow-rose-900/40 border-none"
	BANano.Await(retryBtn.AddComponent)
End Sub

'--- EVENT HANDLERS ---
Private Sub smartAlarm_Change (e As BANanoEvent)
	e.PreventDefault
End Sub

Private Sub alarmBtn_Click (e As BANanoEvent)
	e.PreventDefault
End Sub

Private Sub btnStartTracking_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnRetry_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStatePopulated_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStateSkeleton_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStateEmpty_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStateError_Click (e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

'--- REUSABLE BUILDERS ---
Private Sub AddCard(id As String, parentId As String, classes As String)
	Dim card As SDUI5Container
	card.Initialize(Me, id, id)
	card.ParentID = parentId
	card.Container = False
	card.Classes = classes
	BANano.Await(card.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

Private Sub AddVitalChip(id As String, parentId As String, title As String, value As String, accentColor As String)
	Dim chip As SDUI5Container
	chip.Initialize(Me, id, id)
	chip.ParentID = parentId
	chip.Container = False
	chip.Classes = "p-2.5 rounded-2xl text-center bg-white/5 border border-white/10"
	BANano.Await(chip.AddComponent)
	BANano.Await(AddText(id & "Val", id, value, "p", "sm", "bold", "font-['Outfit']", accentColor))
	BANano.Await(AddText(id & "Lbl", id, title, "p", "xs", "normal", "mt-0.5", "#A79BDB"))
End Sub

Private Sub AddStageHeader(id As String, parentId As String, label As String, duration As String, colorHex As String)
	Dim row As SDUI5Container
	row.Initialize(Me, id, id)
	row.ParentID = parentId
	row.Container = False
	row.Classes = "flex items-center justify-between mt-3 mb-1 text-xs"
	BANano.Await(row.AddComponent)
	BANano.Await(AddText(id & "Lbl", id, label, "span", "xs", "medium", "", "#E2E8F0"))
	BANano.Await(AddText(id & "Dur", id, duration, "span", "xs", "semibold", "", colorHex))
End Sub

Private Sub AddStateBtn(id As String, parentId As String, label As String, isActive As Boolean)
	Dim btn As SDUI5Button
	btn.Initialize(Me, id, id)
	btn.ParentID = parentId
	btn.Text = label
	btn.TextSize = "xs"
	btn.Size = "xs"
	If isActive Then
		btn.Classes = "rounded-lg font-semibold bg-purple-600/80 text-white border-none px-2.5 py-1"
	Else
		btn.Classes = "rounded-lg text-purple-300 hover:bg-white/10 border-none px-2 py-1"
	End If
	BANano.Await(btn.AddComponent)
End Sub
