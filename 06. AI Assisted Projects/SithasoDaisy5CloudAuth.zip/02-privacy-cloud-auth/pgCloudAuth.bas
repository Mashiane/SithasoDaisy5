﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'Static code module
'=== pgCloudAuth.bas ===
'Northstar privacy-first cloud sign-in and account recovery screens.
#IgnoreWarnings:12

Sub Process_Globals
	Private BANano As BANano	'ignore
	Private app As SDUI5App	'ignore

	Private currentViewState As String = "populated"

	'Responsive split-screen shell
	Private AuthLayout As SDUI5Row	'ignore
	Private BrandColumn As SDUI5Column	'ignore
	Private FormColumn As SDUI5Column	'ignore

	'Brand panel
	Private BrandCard As SDUI5Card	'ignore
	Private BrandMark As SDUI5Avatar	'ignore
	Private BrandName As SDUI5Text	'ignore
	Private BrandEyebrow As SDUI5Text	'ignore
	Private BrandHeadline As SDUI5Text	'ignore
	Private BrandCopy As SDUI5Text	'ignore
	Private VaultPanel As SDUI5Card	'ignore
	Private VaultLabel As SDUI5Text	'ignore
	Private VaultHeadline As SDUI5Text	'ignore
	Private VaultCopy As SDUI5Text	'ignore
	Private BrandFootnote As SDUI5Text	'ignore

	'Sign-in panel
	Private SignInCard As SDUI5Card	'ignore
	Private SignInEyebrow As SDUI5Text	'ignore
	Private SignInTitle As SDUI5Text	'ignore
	Private SignInIntro As SDUI5Text	'ignore
	Private EmailBox As SDUI5TextBox	'ignore
	Private PasswordBox As SDUI5TextBox	'ignore
	Private OptionsRow As SDUI5Row	'ignore
	Private OptionsLeft As SDUI5Column	'ignore
	Private OptionsRight As SDUI5Column	'ignore
	Private RememberCheck As SDUI5CheckBox	'ignore
	Private ForgotLink As SDUI5Link	'ignore
	Private SignInAlert As SDUI5Alert	'ignore
	Private SignInButton As SDUI5Button	'ignore
	Private AccountPrompt As SDUI5Text	'ignore
	Private CreateAccountLink As SDUI5Link	'ignore
	Private PrivacyNote As SDUI5Text	'ignore

	'Recovery panel
	Private RecoveryCard As SDUI5Card	'ignore
	Private RecoveryEyebrow As SDUI5Text	'ignore
	Private RecoveryTitle As SDUI5Text	'ignore
	Private RecoveryIntro As SDUI5Text	'ignore
	Private RecoveryEmailBox As SDUI5TextBox	'ignore
	Private RecoveryAlert As SDUI5Alert	'ignore
	Private SendResetButton As SDUI5Button	'ignore
	Private BackToSignInLink As SDUI5Link	'ignore

	'Two-factor dialog
	Private TwoFactorModal As SDUI5Modal	'ignore
	Private TwoFactorIntro As SDUI5Text	'ignore
	Private TwoFactorCodeBox As SDUI5TextBox	'ignore
End Sub

Sub Show
	app = pgIndex.App
	app.SetTheme("emerald")
	BANano.Await(app.ClearPageView)

	'Main Outer Shell
	Dim mainShell As SDUI5Container
	mainShell.Initialize(Me, "mainShell", "mainShell")
	mainShell.ParentID = app.PageView
	mainShell.Container = False
	mainShell.BackgroundColor = "base-200"
	mainShell.Width = "full"
	mainShell.PaddingAXYTBLR = "a=?; x=4; y=6; t=?; b=?; l=?; r=?"
	mainShell.Classes = "min-h-screen flex flex-col items-center justify-center sm:px-8 lg:px-12"
	BANano.Await(mainShell.AddComponent)

	'State Switcher Deck for interactive preview
	Dim stateDeck As SDUI5Container
	stateDeck.Initialize(Me, "stateDeck", "stateDeck")
	stateDeck.ParentID = "mainShell"
	stateDeck.Container = False
	stateDeck.Classes = "flex flex-wrap items-center justify-center gap-2 p-2 mb-6 rounded-2xl bg-base-100 border border-base-300 shadow-sm z-10"
	BANano.Await(stateDeck.AddComponent)

	Dim lblState As SDUI5Text
	lblState.Initialize(Me, "lblState", "lblState")
	lblState.ParentID = "stateDeck"
	lblState.Text = "Preview State:"
	lblState.TextSize = "xs"
	lblState.FontWeight = "bold"
	lblState.Classes = "text-base-content/60 mr-2 uppercase tracking-wider"
	BANano.Await(lblState.AddComponent)

	Dim btnStPop As SDUI5Button
	btnStPop.Initialize(Me, "btnStPop", "btnStPop")
	btnStPop.ParentID = "stateDeck"
	btnStPop.Text = "Populated"
	btnStPop.Size = "xs"
	If currentViewState = "populated" Then btnStPop.Color = "primary" Else btnStPop.Color = "neutral"
	btnStPop.Ghost = (currentViewState <> "populated")
	BANano.Await(btnStPop.AddComponent)

	Dim btnStSkel As SDUI5Button
	btnStSkel.Initialize(Me, "btnStSkel", "btnStSkel")
	btnStSkel.ParentID = "stateDeck"
	btnStSkel.Text = "Skeleton"
	btnStSkel.Size = "xs"
	If currentViewState = "skeleton" Then btnStSkel.Color = "primary" Else btnStSkel.Color = "neutral"
	btnStSkel.Ghost = (currentViewState <> "skeleton")
	BANano.Await(btnStSkel.AddComponent)

	Dim btnStEmpty As SDUI5Button
	btnStEmpty.Initialize(Me, "btnStEmpty", "btnStEmpty")
	btnStEmpty.ParentID = "stateDeck"
	btnStEmpty.Text = "Empty"
	btnStEmpty.Size = "xs"
	If currentViewState = "empty" Then btnStEmpty.Color = "primary" Else btnStEmpty.Color = "neutral"
	btnStEmpty.Ghost = (currentViewState <> "empty")
	BANano.Await(btnStEmpty.AddComponent)

	Dim btnStErr As SDUI5Button
	btnStErr.Initialize(Me, "btnStErr", "btnStErr")
	btnStErr.ParentID = "stateDeck"
	btnStErr.Text = "Error"
	btnStErr.Size = "xs"
	If currentViewState = "error" Then btnStErr.Color = "primary" Else btnStErr.Color = "neutral"
	btnStErr.Ghost = (currentViewState <> "error")
	BANano.Await(btnStErr.AddComponent)

	'Content Host
	Dim contentHost As SDUI5Container
	contentHost.Initialize(Me, "contentHost", "contentHost")
	contentHost.ParentID = "mainShell"
	contentHost.Container = False
	contentHost.Width = "full"
	contentHost.Classes = "flex justify-center"
	BANano.Await(contentHost.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	pgIndex.UpdateTitle("Northstar - Private Cloud")
End Sub

Private Sub RenderPopulatedView
	AuthLayout.Initialize(Me, "AuthLayout", "AuthLayout")
	AuthLayout.ParentID = "contentHost"
	AuthLayout.GridCols = "1"
	AuthLayout.GridColsMd = "12"
	AuthLayout.Gap = "0"
	AuthLayout.Width = "full"
	AuthLayout.MarginAXYTBLR = "a=?; x=auto; y=?; t=?; b=?; l=?; r=?"
	AuthLayout.AlignItems = "center"
	AuthLayout.Classes = "max-w-7xl"
	BANano.Await(AuthLayout.AddComponent)

	BrandColumn.Initialize(Me, "BrandColumn", "BrandColumn")
	BrandColumn.ParentID = "AuthLayout"
	BrandColumn.Size = "12"
	BrandColumn.SizeMd = "5"
	BrandColumn.PaddingAXYTBLR = "a=?; x=2; y=3; t=?; b=?; l=?; r=?"
	BrandColumn.Classes = "order-2 md:order-1 md:py-8 md:pr-6"
	BANano.Await(BrandColumn.AddComponent)

	FormColumn.Initialize(Me, "FormColumn", "FormColumn")
	FormColumn.ParentID = "AuthLayout"
	FormColumn.Size = "12"
	FormColumn.SizeMd = "7"
	FormColumn.PaddingAXYTBLR = "a=?; x=2; y=3; t=?; b=?; l=?; r=?"
	FormColumn.Classes = "order-1 md:order-2 md:py-8 md:pl-6"
	BANano.Await(FormColumn.AddComponent)

	BANano.Await(BuildBrandPanel)
	BANano.Await(BuildSignInPanel)
	BANano.Await(BuildRecoveryPanel)
	BANano.Await(BuildTwoFactorDialog)
End Sub

Private Sub BuildBrandPanel
	BrandCard.Initialize(Me, "BrandCard", "BrandCard")
	BrandCard.ParentID = "BrandColumn"
	BrandCard.BackgroundColor = "neutral"
	BrandCard.TextColor = "neutral-content"
	BrandCard.TitleVisible = False
	BrandCard.ActionsVisible = False
	BrandCard.Rounded = "3xl"
	BrandCard.Shadow = "2xl"
	BrandCard.Height = "full"
	BrandCard.Width = "full"
	BrandCard.Classes = "min-h-96 overflow-hidden"
	BrandCard.BodyClasses = "h-full p-7 sm:p-10 lg:p-12"
	BrandCard.ContentClasses = "flex h-full flex-col gap-5"
	BrandCard.Content = ""
	BANano.Await(BrandCard.AddComponent)

	BrandMark.Initialize(Me, "BrandMark", "BrandMark")
	BrandMark.ParentID = "BrandCard_content"
	BrandMark.AvatarType = "image"
	BrandMark.Image = "./assets/user-lock-solid.svg"
	BrandMark.Mask = "squircle"
	BrandMark.Size = "52px"
	BrandMark.Classes = "w-14 h-14 bg-primary/20 p-2.5 rounded-2xl"
	BrandMark.Shadow = "lg"
	BrandMark.MarginAXYTBLR = "a=?; x=?; y=?; t=?; b=1; l=?; r=?"
	BANano.Await(BrandMark.AddComponent)

	BrandName.Initialize(Me, "BrandName", "BrandName")
	BrandName.ParentID = "BrandCard_content"
	BrandName.Text = "NORTHSTAR"
	BrandName.TextSize = "sm"
	BrandName.TextColor = "primary"
	BrandName.FontWeight = "bold"
	BrandName.Classes = "tracking-widest"
	BANano.Await(BrandName.AddComponent)

	BrandEyebrow.Initialize(Me, "BrandEyebrow", "BrandEyebrow")
	BrandEyebrow.ParentID = "BrandCard_content"
	BrandEyebrow.Text = "PRIVATE CLOUD  /  BUILT AROUND YOU"
	BrandEyebrow.TextSize = "xs"
	BrandEyebrow.TextColor = "neutral-content"
	BrandEyebrow.MarginAXYTBLR = "a=?; x=?; y=?; t=6; b=?; l=?; r=?"
	BrandEyebrow.FontWeight = "semibold"
	BrandEyebrow.Opacity = 70
	BrandEyebrow.Classes = "tracking-widest"
	BANano.Await(BrandEyebrow.AddComponent)

	BrandHeadline.Initialize(Me, "BrandHeadline", "BrandHeadline")
	BrandHeadline.ParentID = "BrandCard_content"
	BrandHeadline.TextTag = "h1"
	BrandHeadline.Text = "Your files. Your rules."
	BrandHeadline.TextSize = "4xl"
	BrandHeadline.TextColor = "neutral-content"
	BrandHeadline.FontWeight = "semibold"
	BrandHeadline.Classes = "max-w-lg leading-tight tracking-tight sm:text-5xl"
	BANano.Await(BrandHeadline.AddComponent)

	BrandCopy.Initialize(Me, "BrandCopy", "BrandCopy")
	BrandCopy.ParentID = "BrandCard_content"
	BrandCopy.Text = "A quieter, safer home for everything you want to keep close."
	BrandCopy.TextSize = "lg"
	BrandCopy.TextColor = "neutral-content"
	BrandCopy.Opacity = 75
	BrandCopy.Classes = "max-w-md"
	BANano.Await(BrandCopy.AddComponent)

	VaultPanel.Initialize(Me, "VaultPanel", "VaultPanel")
	VaultPanel.ParentID = "BrandCard_content"
	VaultPanel.Width = "full"
	VaultPanel.BackgroundColor = "neutral"
	VaultPanel.TextColor = "neutral-content"
	VaultPanel.Border = True
	VaultPanel.TitleVisible = False
	VaultPanel.ActionsVisible = False
	VaultPanel.Rounded = "2xl"
	VaultPanel.Shadow = "none"
	VaultPanel.MarginAXYTBLR = "a=?; x=?; y=?; t=5; b=?; l=?; r=?"
	VaultPanel.Classes = "border-white/20 bg-white/5"
	VaultPanel.BodyClasses = "p-5 sm:p-6"
	VaultPanel.ContentClasses = "flex flex-col gap-3"
	VaultPanel.Content = ""
	BANano.Await(VaultPanel.AddComponent)

	VaultLabel.Initialize(Me, "VaultLabel", "VaultLabel")
	VaultLabel.ParentID = "VaultPanel_content"
	VaultLabel.Text = "PRIVATE BY DESIGN"
	VaultLabel.TextSize = "xs"
	VaultLabel.TextColor = "primary"
	VaultLabel.FontWeight = "bold"
	VaultLabel.Classes = "tracking-widest"
	BANano.Await(VaultLabel.AddComponent)

	VaultHeadline.Initialize(Me, "VaultHeadline", "VaultHeadline")
	VaultHeadline.ParentID = "VaultPanel_content"
	VaultHeadline.TextTag = "h2"
	VaultHeadline.Text = "Your keys stay yours."
	VaultHeadline.TextSize = "xl"
	VaultHeadline.TextColor = "neutral-content"
	VaultHeadline.FontWeight = "semibold"
	BANano.Await(VaultHeadline.AddComponent)

	VaultCopy.Initialize(Me, "VaultCopy", "VaultCopy")
	VaultCopy.ParentID = "VaultPanel_content"
	VaultCopy.Text = "Files are protected before they sync. Not even we can open your vault."
	VaultCopy.TextColor = "neutral-content"
	VaultCopy.Opacity = 75
	VaultCopy.Classes = "max-w-md"
	BANano.Await(VaultCopy.AddComponent)

	BrandFootnote.Initialize(Me, "BrandFootnote", "BrandFootnote")
	BrandFootnote.ParentID = "BrandCard_content"
	BrandFootnote.Text = "ZERO KNOWLEDGE  |  ZERO NOISE  |  YOURS"
	BrandFootnote.TextSize = "xs"
	BrandFootnote.TextColor = "neutral-content"
	BrandFootnote.MarginAXYTBLR = "a=?; x=?; y=?; t=auto; b=?; l=?; r=?"
	BrandFootnote.PaddingAXYTBLR = "a=?; x=?; y=?; t=5; b=?; l=?; r=?"
	BrandFootnote.FontWeight = "medium"
	BrandFootnote.Opacity = 60
	BrandFootnote.Classes = "tracking-widest"
	BANano.Await(BrandFootnote.AddComponent)
End Sub

Private Sub BuildSignInPanel
	SignInCard.Initialize(Me, "SignInCard", "SignInCard")
	SignInCard.ParentID = "FormColumn"
	SignInCard.BackgroundColor = "base-100"
	SignInCard.Border = True
	SignInCard.Rounded = "3xl"
	SignInCard.Shadow = "xl"
	SignInCard.Width = "full"
	SignInCard.TitleVisible = False
	SignInCard.ActionsVisible = False
	SignInCard.MarginAXYTBLR = "a=?; x=auto; y=?; t=?; b=?; l=?; r=?"
	SignInCard.Classes = "max-w-xl border-base-300"
	SignInCard.BodyClasses = "p-7 sm:p-10"
	SignInCard.ContentClasses = "flex flex-col gap-4"
	SignInCard.Content = ""
	BANano.Await(SignInCard.AddComponent)

	SignInEyebrow.Initialize(Me, "SignInEyebrow", "SignInEyebrow")
	SignInEyebrow.ParentID = "SignInCard_content"
	SignInEyebrow.Text = "YOUR PRIVATE WORKSPACE"
	SignInEyebrow.TextSize = "xs"
	SignInEyebrow.TextColor = "primary"
	SignInEyebrow.FontWeight = "bold"
	SignInEyebrow.Classes = "tracking-widest"
	BANano.Await(SignInEyebrow.AddComponent)

	SignInTitle.Initialize(Me, "SignInTitle", "SignInTitle")
	SignInTitle.ParentID = "SignInCard_content"
	SignInTitle.TextTag = "h2"
	SignInTitle.Text = "Welcome back"
	SignInTitle.TextSize = "4xl"
	SignInTitle.TextColor = "base-content"
	SignInTitle.FontWeight = "semibold"
	SignInTitle.Classes = "tracking-tight"
	BANano.Await(SignInTitle.AddComponent)

	SignInIntro.Initialize(Me, "SignInIntro", "SignInIntro")
	SignInIntro.ParentID = "SignInCard_content"
	SignInIntro.Text = "Sign in to pick up right where you left off."
	SignInIntro.TextColor = "base-content"
	SignInIntro.MarginAXYTBLR = "a=?; x=?; y=?; t=?; b=2; l=?; r=?"
	SignInIntro.Opacity = 70
	BANano.Await(SignInIntro.AddComponent)

	SignInAlert.Initialize(Me, "SignInAlert", "SignInAlert")
	SignInAlert.ParentID = "SignInCard_content"
	SignInAlert.Text = "Check your details and try again."
	SignInAlert.Color = "error"
	SignInAlert.Width = "full"
	SignInAlert.Soft = True
	SignInAlert.Visible = False
	BANano.Await(SignInAlert.AddComponent)

	EmailBox.Initialize(Me, "EmailBox", "EmailBox")
	EmailBox.ParentID = "SignInCard_content"
	EmailBox.Label = "Email address"
	EmailBox.InputType = "legend"
	EmailBox.Width = "full"
	EmailBox.Placeholder = "you@example.com"
	EmailBox.TypeOf = "email"
	EmailBox.BackgroundColor = ""
	EmailBox.Border = False
	EmailBox.BorderColor = ""
	EmailBox.Required = True
	BANano.Await(EmailBox.AddComponent)

	PasswordBox.Initialize(Me, "PasswordBox", "PasswordBox")
	PasswordBox.ParentID = "SignInCard_content"
	PasswordBox.Label = "Password"
	PasswordBox.InputType = "legend"
	PasswordBox.Width = "full"
	PasswordBox.Placeholder = "Enter your password"
	PasswordBox.TypeOf = "password"
	PasswordBox.ShowEyes = True
	PasswordBox.BackgroundColor = ""
	PasswordBox.Border = False
	PasswordBox.BorderColor = ""
	PasswordBox.Required = True
	BANano.Await(PasswordBox.AddComponent)

	OptionsRow.Initialize(Me, "OptionsRow", "OptionsRow")
	OptionsRow.ParentID = "SignInCard_content"
	OptionsRow.GridCols = "12"
	OptionsRow.Gap = "0"
	OptionsRow.AlignItems = "center"
	BANano.Await(OptionsRow.AddComponent)

	OptionsLeft.Initialize(Me, "OptionsLeft", "OptionsLeft")
	OptionsLeft.ParentID = "OptionsRow"
	OptionsLeft.Size = "7"
	OptionsLeft.PaddingAXYTBLR = "a=2; x=0; y=?; t=?; b=?; l=?; r=?"
	BANano.Await(OptionsLeft.AddComponent)

	OptionsRight.Initialize(Me, "OptionsRight", "OptionsRight")
	OptionsRight.ParentID = "OptionsRow"
	OptionsRight.Size = "5"
	OptionsRight.PaddingAXYTBLR = "a=2; x=0; y=?; t=?; b=?; l=?; r=?"
	BANano.Await(OptionsRight.AddComponent)

	RememberCheck.Initialize(Me, "RememberCheck", "RememberCheck")
	RememberCheck.ParentID = "OptionsLeft"
	RememberCheck.Label = "Remember this device"
	RememberCheck.CheckBoxType = "right-label"
	RememberCheck.Checked = False
	RememberCheck.Color = "primary"
	RememberCheck.Classes = "text-sm"
	BANano.Await(RememberCheck.AddComponent)

	ForgotLink.Initialize(Me, "ForgotLink", "ForgotLink")
	ForgotLink.ParentID = "OptionsRight"
	ForgotLink.Text = "Forgot password?"
	ForgotLink.Href = "#recover"
	ForgotLink.Hover = True
	ForgotLink.Color = "primary"
	ForgotLink.Classes = "block text-right text-sm font-semibold"
	BANano.Await(ForgotLink.AddComponent)

	SignInButton.Initialize(Me, "SignInButton", "SignInButton")
	SignInButton.ParentID = "SignInCard_content"
	SignInButton.Text = "Sign in to your vault"
	SignInButton.Color = "primary"
	SignInButton.Size = "lg"
	SignInButton.ResizeIconSize = False
	SignInButton.IconSize = "24px"
	SignInButton.Block = True
	SignInButton.RoundedField = True
	SignInButton.LeftIcon = ""
	SignInButton.MarginAXYTBLR = "a=?; x=?; y=?; t=1; b=?; l=?; r=?"
	SignInButton.Shadow = "md"
	BANano.Await(SignInButton.AddComponent)

	AccountPrompt.Initialize(Me, "AccountPrompt", "AccountPrompt")
	AccountPrompt.ParentID = "SignInCard_content"
	AccountPrompt.Text = "New to Northstar?"
	AccountPrompt.TextSize = "sm"
	AccountPrompt.TextColor = "base-content"
	AccountPrompt.MarginAXYTBLR = "a=?; x=?; y=?; t=3; b=?; l=?; r=?"
	AccountPrompt.TextAlign = "center"
	AccountPrompt.Opacity = 70
	BANano.Await(AccountPrompt.AddComponent)

	CreateAccountLink.Initialize(Me, "CreateAccountLink", "CreateAccountLink")
	CreateAccountLink.ParentID = "SignInCard_content"
	CreateAccountLink.Text = "Create your private account"
	CreateAccountLink.Href = "#signup"
	CreateAccountLink.Hover = True
	CreateAccountLink.Color = "primary"
	CreateAccountLink.MarginAXYTBLR = "a=?; x=?; y=?; t=n3; b=?; l=?; r=?"
	CreateAccountLink.Classes = "text-center font-semibold"
	BANano.Await(CreateAccountLink.AddComponent)

	PrivacyNote.Initialize(Me, "PrivacyNote", "PrivacyNote")
	PrivacyNote.ParentID = "SignInCard_content"
	PrivacyNote.Text = "Your files are encrypted before they leave your device."
	PrivacyNote.TextSize = "xs"
	PrivacyNote.TextColor = "base-content"
	PrivacyNote.MarginAXYTBLR = "a=?; x=?; y=?; t=5; b=?; l=?; r=?"
	PrivacyNote.PaddingAXYTBLR = "a=?; x=?; y=?; t=5; b=?; l=?; r=?"
	PrivacyNote.TextAlign = "center"
	PrivacyNote.Opacity = 60
	PrivacyNote.Classes = "border-t border-base-300"
	BANano.Await(PrivacyNote.AddComponent)
End Sub

Private Sub BuildRecoveryPanel
	RecoveryCard.Initialize(Me, "RecoveryCard", "RecoveryCard")
	RecoveryCard.ParentID = "FormColumn"
	RecoveryCard.BackgroundColor = "base-100"
	RecoveryCard.Border = True
	RecoveryCard.Rounded = "3xl"
	RecoveryCard.Shadow = "xl"
	RecoveryCard.Width = "full"
	RecoveryCard.TitleVisible = False
	RecoveryCard.ActionsVisible = False
	RecoveryCard.Visible = False
	RecoveryCard.MarginAXYTBLR = "a=?; x=auto; y=?; t=?; b=?; l=?; r=?"
	RecoveryCard.Classes = "max-w-xl border-base-300"
	RecoveryCard.BodyClasses = "p-7 sm:p-10"
	RecoveryCard.ContentClasses = "flex flex-col gap-4"
	RecoveryCard.Content = ""
	BANano.Await(RecoveryCard.AddComponent)

	RecoveryEyebrow.Initialize(Me, "RecoveryEyebrow", "RecoveryEyebrow")
	RecoveryEyebrow.ParentID = "RecoveryCard_content"
	RecoveryEyebrow.Text = "ACCOUNT RECOVERY"
	RecoveryEyebrow.TextSize = "xs"
	RecoveryEyebrow.TextColor = "primary"
	RecoveryEyebrow.FontWeight = "bold"
	RecoveryEyebrow.Classes = "tracking-widest"
	BANano.Await(RecoveryEyebrow.AddComponent)

	RecoveryTitle.Initialize(Me, "RecoveryTitle", "RecoveryTitle")
	RecoveryTitle.ParentID = "RecoveryCard_content"
	RecoveryTitle.TextTag = "h2"
	RecoveryTitle.Text = "Let's get you back in."
	RecoveryTitle.TextSize = "3xl"
	RecoveryTitle.TextColor = "base-content"
	RecoveryTitle.FontWeight = "semibold"
	RecoveryTitle.Classes = "tracking-tight"
	BANano.Await(RecoveryTitle.AddComponent)

	RecoveryIntro.Initialize(Me, "RecoveryIntro", "RecoveryIntro")
	RecoveryIntro.ParentID = "RecoveryCard_content"
	RecoveryIntro.Text = "Enter the email on your account. If it exists, we'll send a secure recovery link."
	RecoveryIntro.TextColor = "base-content"
	RecoveryIntro.MarginAXYTBLR = "a=?; x=?; y=?; t=?; b=2; l=?; r=?"
	RecoveryIntro.Opacity = 70
	BANano.Await(RecoveryIntro.AddComponent)

	RecoveryAlert.Initialize(Me, "RecoveryAlert", "RecoveryAlert")
	RecoveryAlert.ParentID = "RecoveryCard_content"
	RecoveryAlert.Text = "If the address exists, a recovery link has been sent."
	RecoveryAlert.Color = "success"
	RecoveryAlert.Width = "full"
	RecoveryAlert.Soft = True
	RecoveryAlert.Visible = False
	BANano.Await(RecoveryAlert.AddComponent)

	RecoveryEmailBox.Initialize(Me, "RecoveryEmailBox", "RecoveryEmailBox")
	RecoveryEmailBox.ParentID = "RecoveryCard_content"
	RecoveryEmailBox.Label = "Email address"
	RecoveryEmailBox.InputType = "legend"
	RecoveryEmailBox.Width = "full"
	RecoveryEmailBox.Placeholder = "you@example.com"
	RecoveryEmailBox.TypeOf = "email"
	RecoveryEmailBox.BackgroundColor = ""
	RecoveryEmailBox.Border = False
	RecoveryEmailBox.BorderColor = ""
	RecoveryEmailBox.Required = True
	BANano.Await(RecoveryEmailBox.AddComponent)

	SendResetButton.Initialize(Me, "SendResetButton", "SendResetButton")
	SendResetButton.ParentID = "RecoveryCard_content"
	SendResetButton.Text = "Send recovery link"
	SendResetButton.Color = "accent"
	SendResetButton.Size = "lg"
	SendResetButton.ResizeIconSize = False
	SendResetButton.IconSize = "24px"
	SendResetButton.Block = True
	SendResetButton.RoundedField = True
	SendResetButton.LeftIcon = ""
	SendResetButton.MarginAXYTBLR = "a=?; x=?; y=?; t=1; b=?; l=?; r=?"
	SendResetButton.Shadow = "md"
	BANano.Await(SendResetButton.AddComponent)

	BackToSignInLink.Initialize(Me, "BackToSignInLink", "BackToSignInLink")
	BackToSignInLink.ParentID = "RecoveryCard_content"
	BackToSignInLink.Text = "Back to sign in"
	BackToSignInLink.Hover = True
	BackToSignInLink.Color = "primary"
	BackToSignInLink.MarginAXYTBLR = "a=?; x=?; y=?; t=3; b=?; l=?; r=?"
	BackToSignInLink.Classes = "text-center font-semibold"
	BANano.Await(BackToSignInLink.AddComponent)
End Sub

Private Sub BuildTwoFactorDialog
	TwoFactorModal.Initialize(Me, "TwoFactorModal", "TwoFactorModal")
	TwoFactorModal.ParentID = "mainShell"
	TwoFactorModal.Title = "Verify it's you"
	TwoFactorModal.ActionType = "yes-no"
	TwoFactorModal.YesCaption = "Verify"
	TwoFactorModal.YesColor = "primary"
	TwoFactorModal.NoCaption = "Cancel"
	TwoFactorModal.NoColor = "neutral"
	TwoFactorModal.Width = "32rem"
	TwoFactorModal.Rounded = "3xl"
	TwoFactorModal.Shadow = "2xl"
	TwoFactorModal.Open = False
	BANano.Await(TwoFactorModal.AddComponent)

	TwoFactorIntro.Initialize(Me, "TwoFactorIntro", "TwoFactorIntro")
	TwoFactorIntro.ParentID = "TwoFactorModal_form"
	TwoFactorIntro.Text = "Enter the six-digit code from your authenticator app."
	TwoFactorIntro.TextColor = "base-content"
	TwoFactorIntro.MarginAXYTBLR = "a=?; x=?; y=?; t=?; b=4; l=?; r=?"
	TwoFactorIntro.Opacity = 70
	BANano.Await(TwoFactorIntro.AddComponent)

	TwoFactorCodeBox.Initialize(Me, "TwoFactorCodeBox", "TwoFactorCodeBox")
	TwoFactorCodeBox.ParentID = "TwoFactorModal_form"
	TwoFactorCodeBox.Label = "Authentication code"
	TwoFactorCodeBox.InputType = "legend"
	TwoFactorCodeBox.Width = "full"
	TwoFactorCodeBox.Placeholder = "000000"
	TwoFactorCodeBox.TypeOf = "text"
	TwoFactorCodeBox.BackgroundColor = ""
	TwoFactorCodeBox.Border = False
	TwoFactorCodeBox.BorderColor = ""
	TwoFactorCodeBox.Required = True
	BANano.Await(TwoFactorCodeBox.AddComponent)
End Sub

Private Sub RenderSkeletonView
	Dim skelLayout As SDUI5Row
	skelLayout.Initialize(Me, "skelLayout", "skelLayout")
	skelLayout.ParentID = "contentHost"
	skelLayout.GridCols = "1"
	skelLayout.GridColsMd = "12"
	skelLayout.Gap = "6"
	skelLayout.Width = "full"
	skelLayout.Classes = "max-w-7xl"
	BANano.Await(skelLayout.AddComponent)

	Dim skelCol1 As SDUI5Column
	skelCol1.Initialize(Me, "skelCol1", "skelCol1")
	skelCol1.ParentID = "skelLayout"
	skelCol1.Size = "12"
	skelCol1.SizeMd = "5"
	BANano.Await(skelCol1.AddComponent)

	Dim skelBrand As SDUI5Skeleton
	skelBrand.Initialize(Me, "skelBrand", "skelBrand")
	skelBrand.ParentID = "skelCol1"
	skelBrand.Classes = "w-full h-[520px] rounded-3xl"
	BANano.Await(skelBrand.AddComponent)

	Dim skelCol2 As SDUI5Column
	skelCol2.Initialize(Me, "skelCol2", "skelCol2")
	skelCol2.ParentID = "skelLayout"
	skelCol2.Size = "12"
	skelCol2.SizeMd = "7"
	BANano.Await(skelCol2.AddComponent)

	Dim skelForm As SDUI5Skeleton
	skelForm.Initialize(Me, "skelForm", "skelForm")
	skelForm.ParentID = "skelCol2"
	skelForm.Classes = "w-full h-[520px] rounded-3xl"
	BANano.Await(skelForm.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyBox As SDUI5Card
	emptyBox.Initialize(Me, "emptyBox", "emptyBox")
	emptyBox.ParentID = "contentHost"
	emptyBox.TitleVisible = False
	emptyBox.ActionsVisible = False
	emptyBox.Rounded = "3xl"
	emptyBox.Classes = "max-w-xl p-12 text-center bg-base-100 border border-base-300 shadow-xl"
	emptyBox.ContentClasses = "flex flex-col items-center justify-center gap-4"
	emptyBox.Content = ""
	BANano.Await(emptyBox.AddComponent)

	Dim emptyIcon As SDUI5Avatar
	emptyIcon.Initialize(Me, "emptyIcon", "emptyIcon")
	emptyIcon.ParentID = "emptyBox_content"
	emptyIcon.AvatarType = "image"
	emptyIcon.Image = "./assets/cloud-arrow-up-solid.svg"
	emptyIcon.Size = "64px"
	emptyIcon.Classes = "w-16 h-16 bg-base-200 p-3 opacity-60 rounded-2xl"
	BANano.Await(emptyIcon.AddComponent)

	Dim emptyTitle As SDUI5Text
	emptyTitle.Initialize(Me, "emptyTitle", "emptyTitle")
	emptyTitle.ParentID = "emptyBox_content"
	emptyTitle.TextTag = "h2"
	emptyTitle.Text = "No Registered Vaults"
	emptyTitle.TextSize = "2xl"
	emptyTitle.FontWeight = "bold"
	emptyTitle.Classes = "text-base-content"
	BANano.Await(emptyTitle.AddComponent)

	Dim emptySub As SDUI5Text
	emptySub.Initialize(Me, "emptySub", "emptySub")
	emptySub.ParentID = "emptyBox_content"
	emptySub.Text = "No active private storage vaults are associated with this tenant domain."
	emptySub.Classes = "text-sm text-base-content/70 max-w-sm"
	BANano.Await(emptySub.AddComponent)

	Dim btnReload As SDUI5Button
	btnReload.Initialize(Me, "btnReload", "btnReload")
	btnReload.ParentID = "emptyBox_content"
	btnReload.Text = "Return to Sign-In"
	btnReload.Color = "neutral"
	btnReload.Classes = "mt-4 rounded-2xl font-bold"
	BANano.Await(btnReload.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errBox As SDUI5Card
	errBox.Initialize(Me, "errBox", "errBox")
	errBox.ParentID = "contentHost"
	errBox.TitleVisible = False
	errBox.ActionsVisible = False
	errBox.Rounded = "3xl"
	errBox.Classes = "max-w-xl p-12 text-center bg-error/10 border border-error/30 shadow-xl"
	errBox.ContentClasses = "flex flex-col items-center justify-center gap-4"
	errBox.Content = ""
	BANano.Await(errBox.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errBox_content"
	errTitle.TextTag = "h2"
	errTitle.Text = "VAULT CLUSTER OFFLINE"
	errTitle.TextSize = "xl"
	errTitle.FontWeight = "bold"
	errTitle.Classes = "text-error"
	BANano.Await(errTitle.AddComponent)

	Dim errSub As SDUI5Text
	errSub.Initialize(Me, "errSub", "errSub")
	errSub.ParentID = "errBox_content"
	errSub.Text = "The zero-knowledge authentication node could not establish a cryptographic handshake (503 Service Unavailable)."
	errSub.Classes = "text-sm text-base-content/70 max-w-sm"
	BANano.Await(errSub.AddComponent)

	Dim btnRetry As SDUI5Button
	btnRetry.Initialize(Me, "btnRetry", "btnRetry")
	btnRetry.ParentID = "errBox_content"
	btnRetry.Text = "Retry Authentication"
	btnRetry.Color = "error"
	btnRetry.Classes = "mt-4 rounded-2xl font-bold"
	BANano.Await(btnRetry.AddComponent)
End Sub

'State switcher handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub btnReload_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnRetry_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

'Auth form handlers
Private Sub SignInButton_Click(e As BANanoEvent)
	SignInAlert.Visible = False
	If EmailBox.Value = "" Or PasswordBox.Value = "" Then
		SignInAlert.Text = "Add your email and password to continue."
		SignInAlert.Visible = True
		Return
	End If

	SignInButton.Loading = True
	TwoFactorModal.Show
	SignInButton.Loading = False
End Sub

Private Sub TwoFactorModal_Yes_Click(e As BANanoEvent)
	TwoFactorModal.Close
	SignInAlert.Color = "success"
	SignInAlert.Text = "You're signed in. Your private workspace is ready."
	SignInAlert.Visible = True
End Sub

Private Sub TwoFactorModal_No_Click(e As BANanoEvent)
	TwoFactorModal.Close
End Sub

Private Sub ForgotLink_Click(e As BANanoEvent)
	SignInCard.Visible = False
	RecoveryCard.Visible = True
	RecoveryAlert.Visible = False
End Sub

Private Sub BackToSignInLink_Click(e As BANanoEvent)
	RecoveryCard.Visible = False
	SignInCard.Visible = True
End Sub

Private Sub SendResetButton_Click(e As BANanoEvent)
	RecoveryAlert.Visible = False
	If RecoveryEmailBox.Value = "" Then
		RecoveryAlert.Color = "error"
		RecoveryAlert.Text = "Enter your email address to continue."
		RecoveryAlert.Visible = True
		Return
	End If

	SendResetButton.Loading = True
	RecoveryAlert.Color = "success"
	RecoveryAlert.Text = "If the address exists, a recovery link has been sent."
	RecoveryAlert.Visible = True
	SendResetButton.Loading = False
End Sub
