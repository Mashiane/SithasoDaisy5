﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnPrev As SDUI5Button 'ignore
	Private btnPlay As SDUI5Button 'ignore
	Private btnNext As SDUI5Button 'ignore
	Private volSlider As SDUI5Range 'ignore
	Private isPlaying As Boolean = True
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)
	
	' Desktop Phone Chassis containment
	Dim page As SDUI5Container
	page.Initialize(Me, "brutalPage", "brutalPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-1 sm:rounded-[28px] sm:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)] border-3 border-black bg-[#F4F1EA] text-black font-['Space_Grotesk',sans-serif] px-4 py-2.5 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top App Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBar", "topBar")
	topBar.ParentID = "brutalPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between border-b-2 border-black pb-1.5"
	BANano.Await(topBar.AddComponent)

	Dim logoText As SDUI5Text
	logoText.Initialize(Me, "logoText", "logoText")
	logoText.ParentID = "topBar"
	logoText.TextTag = "span"
	logoText.Text = "RAW AUDIO // CH.04"
	logoText.Classes = "font-black tracking-widest text-xs uppercase bg-black text-white px-2 py-0.5"
	BANano.Await(logoText.AddComponent)

	Dim statusBadge As SDUI5Badge
	statusBadge.Initialize(Me, "statusBadge", "statusBadge")
	statusBadge.ParentID = "topBar"
	statusBadge.Text = "LIVE 96.4 KHZ"
	statusBadge.Classes = "badge-sm rounded-none border-2 border-black bg-[#A3E635] text-black font-bold tracking-wider"
	BANano.Await(statusBadge.AddComponent)

	' State Switcher Bar
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "brutalPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1 mt-1.5"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white text-black"
	Dim skelStyle As String = "bg-white text-black"
	Dim empStyle As String = "bg-white text-black"
	Dim errStyle As String = "bg-white text-black"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-black text-white"
	Else If currentViewState = "empty" Then
		empStyle = "bg-black text-white"
	Else If currentViewState = "error" Then
		errStyle = "bg-black text-white"
	Else
		popStyle = "bg-black text-white"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "PLAYING", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "BUFFER", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "EMPTY", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "ERROR", errStyle))

	' Content Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "brutalPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-1.5"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	pgIndex.UpdateTitle("Brutal Player | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-none border-2 border-black font-mono font-bold text-[10px] " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Album Artwork Frame
	Dim artWrap As SDUI5Container
	artWrap.Initialize(Me, "artWrap", "artWrap")
	artWrap.ParentID = "contentWrapper"
	artWrap.Container = False
	artWrap.Classes = "relative my-1 flex justify-center"
	BANano.Await(artWrap.AddComponent)

	Dim art As SDUI5Image
	art.Initialize(Me, "brutalArt", "brutalArt")
	art.ParentID = "artWrap"
	art.Src = "./assets/casette.webp"
	art.Alt = "Sample album artwork"
	art.Classes = "w-full h-32 object-cover border-3 border-black shadow-[4px_4px_0px_#000000]"
	BANano.Await(art.AddComponent)

	' Now Playing Header
	Dim metaBox As SDUI5Container
	metaBox.Initialize(Me, "metaBox", "metaBox")
	metaBox.ParentID = "contentWrapper"
	metaBox.Container = False
	metaBox.Classes = "border-2 border-black bg-white p-2 shadow-[2px_2px_0px_#000000] mt-1.5"
	BANano.Await(metaBox.AddComponent)

	Dim brutalTitle As SDUI5Text
	brutalTitle.Initialize(Me, "brutalTitle", "brutalTitle")
	brutalTitle.ParentID = "metaBox"
	brutalTitle.TextTag = "h1"
	brutalTitle.Text = "CONCRETE DREAMS"
	brutalTitle.Classes = "text-base font-black uppercase tracking-tight text-black"
	BANano.Await(brutalTitle.AddComponent)

	Dim brutalArtist As SDUI5Text
	brutalArtist.Initialize(Me, "brutalArtist", "brutalArtist")
	brutalArtist.ParentID = "metaBox"
	brutalArtist.TextTag = "p"
	brutalArtist.Text = "THE STATIC BLOCKS | MASTER 24-BIT"
	brutalArtist.Classes = "text-[11px] font-mono font-bold text-neutral-700 tracking-wider mt-0.5"
	BANano.Await(brutalArtist.AddComponent)

	' Progress Bar & Time
	Dim progBox As SDUI5Container
	progBox.Initialize(Me, "progBox", "progBox")
	progBox.ParentID = "contentWrapper"
	progBox.Container = False
	progBox.Classes = "mt-1.5"
	BANano.Await(progBox.AddComponent)

	Dim pos As SDUI5Progress
	pos.Initialize(Me, "brutalProgress", "brutalProgress")
	pos.ParentID = "progBox"
	pos.Value = "42"
	pos.Height = "8px"
	pos.Classes = "border-2 border-black rounded-none shadow-[2px_2px_0px_#000000] bg-white text-black"
	BANano.Await(pos.AddComponent)

	Dim timeRow As SDUI5Container
	timeRow.Initialize(Me, "timeRow", "timeRow")
	timeRow.ParentID = "progBox"
	timeRow.Container = False
	timeRow.Classes = "flex justify-between font-mono text-[10px] font-bold mt-0.5 text-black"
	BANano.Await(timeRow.AddComponent)

	Dim tElapsed As SDUI5Text
	tElapsed.Initialize(Me, "tElapsed", "tElapsed")
	tElapsed.ParentID = "timeRow"
	tElapsed.TextTag = "span"
	tElapsed.Text = "01:42"
	BANano.Await(tElapsed.AddComponent)

	Dim tTotal As SDUI5Text
	tTotal.Initialize(Me, "tTotal", "tTotal")
	tTotal.ParentID = "timeRow"
	tTotal.TextTag = "span"
	tTotal.Text = "04:05"
	BANano.Await(tTotal.AddComponent)

	' Transport Controls
	Dim ctlRow As SDUI5Container
	ctlRow.Initialize(Me, "ctlRow", "ctlRow")
	ctlRow.ParentID = "contentWrapper"
	ctlRow.Container = False
	ctlRow.Classes = "flex items-center justify-between gap-2 mt-1.5"
	BANano.Await(ctlRow.AddComponent)

	btnPrev.Initialize(Me, "btnPrev", "btnPrev")
	btnPrev.ParentID = "ctlRow"
	btnPrev.Text = "|< PREV"
	btnPrev.Classes = "flex-1 rounded-none border-2 border-black bg-white font-mono font-black text-[11px] py-1 shadow-[2px_2px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(btnPrev.AddComponent)

	btnPlay.Initialize(Me, "btnPlay", "btnPlay")
	btnPlay.ParentID = "ctlRow"
	If isPlaying Then
		btnPlay.Text = "|| PAUSE"
	Else
		btnPlay.Text = "|> PLAY"
	End If
	btnPlay.Classes = "flex-[1.4] rounded-none border-2 border-black bg-[#A3E635] text-black font-black text-xs py-1.5 shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(btnPlay.AddComponent)

	btnNext.Initialize(Me, "btnNext", "btnNext")
	btnNext.ParentID = "ctlRow"
	btnNext.Text = "NEXT >|"
	btnNext.Classes = "flex-1 rounded-none border-2 border-black bg-white font-mono font-black text-[11px] py-1 shadow-[2px_2px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(btnNext.AddComponent)

	' Volume Slider
	Dim volBox As SDUI5Container
	volBox.Initialize(Me, "volBox", "volBox")
	volBox.ParentID = "contentWrapper"
	volBox.Container = False
	volBox.Classes = "mt-1.5 p-1 border border-black bg-[#E5E0D5]"
	BANano.Await(volBox.AddComponent)

	volSlider.Initialize(Me, "volSlider", "volSlider")
	volSlider.ParentID = "volBox"
	volSlider.Label = "MASTER OUTPUT LEVEL"
	volSlider.MinValue = "0"
	volSlider.MaxValue = "100"
	volSlider.Value = "78"
	volSlider.Classes = "range-xs range-accent"
	BANano.Await(volSlider.AddComponent)

	' Up Next Queue
	Dim queueHead As SDUI5Container
	queueHead.Initialize(Me, "queueHead", "queueHead")
	queueHead.ParentID = "contentWrapper"
	queueHead.Container = False
	queueHead.Classes = "flex items-center justify-between mt-1.5 mb-0.5"
	BANano.Await(queueHead.AddComponent)

	Dim qTitle As SDUI5Text
	qTitle.Initialize(Me, "qTitle", "qTitle")
	qTitle.ParentID = "queueHead"
	qTitle.TextTag = "h2"
	qTitle.Text = "CASSETTE QUEUE"
	qTitle.Classes = "font-black text-xs uppercase tracking-wider text-black"
	BANano.Await(qTitle.AddComponent)

	Dim count As SDUI5Badge
	count.Initialize(Me, "brutalCount", "brutalCount")
	count.ParentID = "queueHead"
	count.Text = "3 TAPES"
	count.Classes = "badge-xs rounded-none border border-black bg-black text-white font-mono font-bold"
	BANano.Await(count.AddComponent)

	Dim queue As SDUI5List
	queue.Initialize(Me, "brutalQueue", "brutalQueue")
	queue.ParentID = "contentWrapper"
	queue.Classes = "border-2 border-black divide-y divide-black bg-white shadow-[2px_2px_0px_#000000]"
	BANano.Await(queue.AddComponent)

	BANano.Await(AddTrack("brutalTrack1", "brutalQueue", "01. NEON STATIC", "03:12"))
	BANano.Await(AddTrack("brutalTrack2", "brutalQueue", "02. CONCRETE DREAMS (PLAYING)", "04:05"))
	BANano.Await(AddTrack("brutalTrack3", "brutalQueue", "03. PAPER WALLS", "02:58"))
End Sub

Private Sub RenderSkeletonView
	Dim skelArt As SDUI5Skeleton
	skelArt.Initialize(Me, "skelArt", "skelArt")
	skelArt.ParentID = "contentWrapper"
	skelArt.Classes = "w-full h-32 border-3 border-black bg-neutral-300 rounded-none shadow-[4px_4px_0px_#000000] my-1"
	BANano.Await(skelArt.AddComponent)

	Dim skelMeta As SDUI5Skeleton
	skelMeta.Initialize(Me, "skelMeta", "skelMeta")
	skelMeta.ParentID = "contentWrapper"
	skelMeta.Classes = "w-full h-10 border-2 border-black bg-neutral-300 rounded-none shadow-[2px_2px_0px_#000000] mt-1.5"
	BANano.Await(skelMeta.AddComponent)

	Dim skelProg As SDUI5Skeleton
	skelProg.Initialize(Me, "skelProg", "skelProg")
	skelProg.ParentID = "contentWrapper"
	skelProg.Classes = "w-full h-2 border border-black bg-neutral-300 rounded-none mt-1.5"
	BANano.Await(skelProg.AddComponent)

	Dim skelCtl As SDUI5Skeleton
	skelCtl.Initialize(Me, "skelCtl", "skelCtl")
	skelCtl.ParentID = "contentWrapper"
	skelCtl.Classes = "w-full h-8 border-2 border-black bg-neutral-300 rounded-none mt-1.5"
	BANano.Await(skelCtl.AddComponent)

	Dim skelQueue As SDUI5Skeleton
	skelQueue.Initialize(Me, "skelQueue", "skelQueue")
	skelQueue.ParentID = "contentWrapper"
	skelQueue.Classes = "w-full h-16 border-2 border-black bg-neutral-300 rounded-none mt-1.5 shadow-[2px_2px_0px_#000000]"
	BANano.Await(skelQueue.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-5 my-auto border-3 border-black bg-white shadow-[4px_4px_0px_#000000] text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "CASSETTE DECK EMPTY"
	empTitle.Classes = "text-base font-black uppercase text-black"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "No tapes in queue. Insert an audio reel or load mixtape."
	empMsg.Classes = "text-[11px] font-mono text-neutral-600 mt-1 max-w-xs"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "+ INSERT TAPE"
	empCta.Classes = "mt-3 rounded-none border-2 border-black bg-[#A3E635] text-black font-black text-xs px-4 py-1.5 shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-5 my-auto border-3 border-black bg-[#FCA5A5] shadow-[4px_4px_0px_#000000] text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "TAPE MECHANISM JAMMED"
	errTitle.Classes = "text-base font-black uppercase text-black"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Audio buffer desynchronized (Error: 0xBF88). Rewind tape mechanism to resume."
	errMsg.Classes = "text-[11px] font-mono text-black font-bold mt-1 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "EJECT & REWIND"
	errCta.Classes = "mt-3 rounded-none border-2 border-black bg-black text-white font-black text-xs px-4 py-1.5 shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddTrack(id As String, parentId As String, title As String, duration As String)
	Dim item As SDUI5ListItem
	item.Initialize(Me, id, id)
	item.ParentID = parentId
	item.Text = title & " - " & duration
	item.Classes = "px-2 py-1 font-mono text-[11px] font-bold text-black hover:bg-[#A3E635] cursor-pointer"
	BANano.Await(item.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Tape inserted successfully", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Tape rewound and recalibrated", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub btnPrev_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Rewound to previous tape", 1500)
End Sub

Private Sub btnPlay_Click(e As BANanoEvent)
	e.PreventDefault
	isPlaying = Not(isPlaying)
	If isPlaying Then
		btnPlay.Text = "|| PAUSE"
		app.ShowSwalSuccessToast("Resumed tape playback", 1500)
	Else
		btnPlay.Text = "|> PLAY"
		app.ShowSwalInfoToast("Tape playback paused", 1500)
	End If
End Sub

Private Sub btnNext_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Skipped to next tape", 1500)
End Sub

Private Sub volSlider_Change(e As BANanoEvent)
	e.PreventDefault
End Sub
