﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public BANano As BANano 'ignore
	Public App As SDUI5App	'ignore
	Private pageView As SDUI5Container 'ignore
	Private navBrutal As SDUI5Button 'ignore
	Private navMemphis As SDUI5Button 'ignore
	Private navRetro As SDUI5Button 'ignore
End Sub

Sub Initialize
	BANano.Await(App.Initialize(Me))
	App.RemoveClass("w-screen")
	App.AddClass("font-['Plus_Jakarta_Sans',sans-serif] antialiased min-h-screen bg-[#111116] text-white")
	Dim navrow As SDUI5Container
	navrow.Initialize(Me, "navrow", "navrow")
	navrow.ParentID = App.Here
	navrow.Container = False
	navrow.Classes = "flex justify-center items-center gap-1.5 py-1 px-2 max-w-xs mx-auto mt-1 mb-0.5 rounded-xl bg-neutral-900/80 backdrop-blur-md border border-white/10 shadow-sm"
	BANano.Await(navrow.AddComponent)
	navBrutal.Initialize(Me, "navBrutal", "navBrutal")
	navBrutal.ParentID = "navrow"
	navBrutal.Text = "Brutal"
	navBrutal.Classes = "btn-xs rounded-lg font-bold border-none"
	navBrutal.Color = "neutral"
	BANano.Await(navBrutal.AddComponent)
	navMemphis.Initialize(Me, "navMemphis", "navMemphis")
	navMemphis.ParentID = "navrow"
	navMemphis.Text = "Memphis"
	navMemphis.Classes = "btn-xs rounded-lg font-bold border-none"
	navMemphis.Color = "secondary"
	BANano.Await(navMemphis.AddComponent)
	navRetro.Initialize(Me, "navRetro", "navRetro")
	navRetro.ParentID = "navrow"
	navRetro.Text = "Retro"
	navRetro.Classes = "btn-xs rounded-lg font-bold border-none"
	navRetro.Color = "accent"
	BANano.Await(navRetro.AddComponent)
	pageView.Initialize(Me, "pageview", "pageview")
	pageView.ParentID = App.Here
	pageView.Container = False
	BANano.Await(pageView.AddComponent)
	BANano.Await(pgBrutal.Show)
	App.pageresume
End Sub

Sub UpdateTitle(s As String)
	BANano.Window.SetField("document.title", s)
End Sub

Private Sub navBrutal_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgBrutal.Show)
End Sub

Private Sub navMemphis_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgMemphis.Show)
End Sub

Private Sub navRetro_Click(e As BANanoEvent)
	e.PreventDefault
	BANano.Await(pgRetro.Show)
End Sub
