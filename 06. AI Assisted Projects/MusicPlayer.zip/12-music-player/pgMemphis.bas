﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnPrevM As SDUI5Button 'ignore
	Private btnPlayM As SDUI5Button 'ignore
	Private btnNextM As SDUI5Button 'ignore
	Private volSliderM As SDUI5Range 'ignore
	Private isPlayingM As Boolean = True
	Private currentViewStateM As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)
	
	' Desktop Phone Chassis containment
	Dim page As SDUI5Container
	page.Initialize(Me, "memphisPage", "memphisPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-1 sm:rounded-[28px] sm:shadow-2xl border-3 border-pink-400/40 bg-[#FFF7ED] text-slate-900 font-['Plus_Jakarta_Sans',sans-serif] px-4 py-2.5 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top App Bar
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBarM", "topBarM")
	topBar.ParentID = "memphisPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	Dim logoText As SDUI5Text
	logoText.Initialize(Me, "logoTextM", "logoTextM")
	logoText.ParentID = "topBarM"
	logoText.TextTag = "span"
	logoText.Text = "MEMPHIS BEATS"
	logoText.Classes = "font-black tracking-wider text-xs uppercase text-pink-600 bg-pink-100 px-2.5 py-0.5 rounded-full border border-pink-200"
	BANano.Await(logoText.AddComponent)

	Dim statusBadge As SDUI5Badge
	statusBadge.Initialize(Me, "statusBadgeM", "statusBadgeM")
	statusBadge.ParentID = "topBarM"
	statusBadge.Text = "HIGH FIDELITY"
	statusBadge.Classes = "badge-sm rounded-full bg-amber-200 text-amber-900 font-bold border-none"
	BANano.Await(statusBadge.AddComponent)

	' State Switcher Bar
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBarM", "stateBarM")
	stateBar.ParentID = "memphisPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1 mt-1.5"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white text-purple-900"
	Dim skelStyle As String = "bg-white text-purple-900"
	Dim empStyle As String = "bg-white text-purple-900"
	Dim errStyle As String = "bg-white text-purple-900"

	If currentViewStateM = "skeleton" Then
		skelStyle = "bg-purple-600 text-white shadow-sm"
	Else If currentViewStateM = "empty" Then
		empStyle = "bg-purple-600 text-white shadow-sm"
	Else If currentViewStateM = "error" Then
		errStyle = "bg-purple-600 text-white shadow-sm"
	Else
		popStyle = "bg-purple-600 text-white shadow-sm"
	End If

	BANano.Await(AddStateBtn("btnStPopM", "stateBarM", "PLAYING", popStyle))
	BANano.Await(AddStateBtn("btnStSkelM", "stateBarM", "BUFFER", skelStyle))
	BANano.Await(AddStateBtn("btnStEmptyM", "stateBarM", "EMPTY", empStyle))
	BANano.Await(AddStateBtn("btnStErrM", "stateBarM", "ERROR", errStyle))

	' Content Container
	Dim contentWrapperM As SDUI5Container
	contentWrapperM.Initialize(Me, "contentWrapperM", "contentWrapperM")
	contentWrapperM.ParentID = "memphisPage"
	contentWrapperM.Container = False
	contentWrapperM.Classes = "flex-1 flex flex-col justify-between mt-1.5"
	BANano.Await(contentWrapperM.AddComponent)

	Select Case currentViewStateM
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	pgIndex.UpdateTitle("Memphis Pop Player | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-xl font-bold text-[10px] border-none " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Playful Memphis Album Artwork Frame
	Dim artWrap As SDUI5Container
	artWrap.Initialize(Me, "artWrapM", "artWrapM")
	artWrap.ParentID = "contentWrapperM"
	artWrap.Container = False
	artWrap.Classes = "relative my-1 flex justify-center"
	BANano.Await(artWrap.AddComponent)

	Dim art As SDUI5Image
	art.Initialize(Me, "memphisArt", "memphisArt")
	art.ParentID = "artWrapM"
	art.Src = "./assets/banner_2.jpg"
	art.Alt = "Sample album artwork"
	art.Classes = "w-full h-32 object-cover rotate-1 rounded-2xl border-3 border-white shadow-md"
	BANano.Await(art.AddComponent)

	' Now Playing Meta
	Dim metaBox As SDUI5Container
	metaBox.Initialize(Me, "metaBoxM", "metaBoxM")
	metaBox.ParentID = "contentWrapperM"
	metaBox.Container = False
	metaBox.Classes = "p-2 rounded-xl bg-white shadow-sm border border-pink-100 mt-1.5"
	BANano.Await(metaBox.AddComponent)

	Dim title As SDUI5Text
	title.Initialize(Me, "memphisTitle", "memphisTitle")
	title.ParentID = "metaBoxM"
	title.TextTag = "h1"
	title.Text = "ZIGZAG SUMMER"
	title.Classes = "text-base font-black italic text-purple-700 tracking-tight"
	BANano.Await(title.AddComponent)

	Dim artist As SDUI5Text
	artist.Initialize(Me, "memphisArtist", "memphisArtist")
	artist.ParentID = "metaBoxM"
	artist.TextTag = "p"
	artist.Text = "PALMA SHAPES - ELECTRIC RETRO"
	artist.Classes = "text-[11px] font-bold text-pink-600 tracking-wide mt-0.5"
	BANano.Await(artist.AddComponent)

	' Progress Bar & Time
	Dim progBox As SDUI5Container
	progBox.Initialize(Me, "progBoxM", "progBoxM")
	progBox.ParentID = "contentWrapperM"
	progBox.Container = False
	progBox.Classes = "mt-1.5"
	BANano.Await(progBox.AddComponent)

	Dim pos As SDUI5Progress
	pos.Initialize(Me, "memphisProgress", "memphisProgress")
	pos.ParentID = "progBoxM"
	pos.Value = "42"
	pos.Height = "8px"
	pos.Classes = "rounded-full bg-pink-100 progress-secondary"
	BANano.Await(pos.AddComponent)

	Dim timeRow As SDUI5Container
	timeRow.Initialize(Me, "timeRowM", "timeRowM")
	timeRow.ParentID = "progBoxM"
	timeRow.Container = False
	timeRow.Classes = "flex justify-between font-bold text-[10px] mt-0.5 text-purple-800"
	BANano.Await(timeRow.AddComponent)

	Dim tElapsed As SDUI5Text
	tElapsed.Initialize(Me, "tElapsedM", "tElapsedM")
	tElapsed.ParentID = "timeRowM"
	tElapsed.TextTag = "span"
	tElapsed.Text = "01:42"
	BANano.Await(tElapsed.AddComponent)

	Dim tTotal As SDUI5Text
	tTotal.Initialize(Me, "tTotalM", "tTotalM")
	tTotal.ParentID = "timeRowM"
	tTotal.TextTag = "span"
	tTotal.Text = "04:05"
	BANano.Await(tTotal.AddComponent)

	' Transport Controls
	Dim ctlRow As SDUI5Container
	ctlRow.Initialize(Me, "ctlRowM", "ctlRowM")
	ctlRow.ParentID = "contentWrapperM"
	ctlRow.Container = False
	ctlRow.Classes = "flex items-center justify-between gap-2 mt-1.5"
	BANano.Await(ctlRow.AddComponent)

	btnPrevM.Initialize(Me, "btnPrevM", "btnPrevM")
	btnPrevM.ParentID = "ctlRowM"
	btnPrevM.Text = "PREV"
	btnPrevM.Classes = "flex-1 rounded-xl bg-cyan-100 text-cyan-900 font-black text-[11px] py-1 border-none shadow-xs"
	BANano.Await(btnPrevM.AddComponent)

	btnPlayM.Initialize(Me, "btnPlayM", "btnPlayM")
	btnPlayM.ParentID = "ctlRowM"
	If isPlayingM Then
		btnPlayM.Text = "PAUSE"
	Else
		btnPlayM.Text = "PLAY"
	End If
	btnPlayM.Classes = "flex-[1.4] rounded-xl bg-[#DB2777] text-white font-black text-xs py-1.5 border-none shadow-md shadow-pink-500/30"
	BANano.Await(btnPlayM.AddComponent)

	btnNextM.Initialize(Me, "btnNextM", "btnNextM")
	btnNextM.ParentID = "ctlRowM"
	btnNextM.Text = "NEXT"
	btnNextM.Classes = "flex-1 rounded-xl bg-cyan-100 text-cyan-900 font-black text-[11px] py-1 border-none shadow-xs"
	BANano.Await(btnNextM.AddComponent)

	' Volume Slider
	Dim volBox As SDUI5Container
	volBox.Initialize(Me, "volBoxM", "volBoxM")
	volBox.ParentID = "contentWrapperM"
	volBox.Container = False
	volBox.Classes = "mt-1.5 p-1.5 rounded-xl bg-white/80 border border-pink-200"
	BANano.Await(volBox.AddComponent)

	volSliderM.Initialize(Me, "volSliderM", "volSliderM")
	volSliderM.ParentID = "volBoxM"
	volSliderM.Label = "MASTER SOUND VOLUME"
	volSliderM.MinValue = "0"
	volSliderM.MaxValue = "100"
	volSliderM.Value = "70"
	volSliderM.Classes = "range-xs range-secondary"
	BANano.Await(volSliderM.AddComponent)

	' Up Next Queue
	Dim queueHead As SDUI5Container
	queueHead.Initialize(Me, "queueHeadM", "queueHeadM")
	queueHead.ParentID = "contentWrapperM"
	queueHead.Container = False
	queueHead.Classes = "flex items-center justify-between mt-1.5 mb-0.5"
	BANano.Await(queueHead.AddComponent)

	Dim qTitle As SDUI5Text
	qTitle.Initialize(Me, "qTitleM", "qTitleM")
	qTitle.ParentID = "queueHeadM"
	qTitle.TextTag = "h2"
	qTitle.Text = "UP NEXT TRACKS"
	qTitle.Classes = "font-black text-xs uppercase tracking-wider text-purple-900"
	BANano.Await(qTitle.AddComponent)

	Dim count As SDUI5Badge
	count.Initialize(Me, "memphisCount", "memphisCount")
	count.ParentID = "queueHeadM"
	count.Text = "3 SONGS"
	count.Classes = "badge-xs rounded-full bg-pink-500 text-white font-bold border-none"
	BANano.Await(count.AddComponent)

	Dim queue As SDUI5List
	queue.Initialize(Me, "memphisQueue", "memphisQueue")
	queue.ParentID = "contentWrapperM"
	queue.Classes = "rounded-xl divide-y divide-pink-100 bg-white shadow-xs border border-pink-100"
	BANano.Await(queue.AddComponent)

	BANano.Await(AddTrack("mTrack1", "memphisQueue", "1. Neon Static", "3:12"))
	BANano.Await(AddTrack("mTrack2", "memphisQueue", "2. Zigzag Summer (Now Playing)", "4:05"))
	BANano.Await(AddTrack("mTrack3", "memphisQueue", "3. Paper Walls", "2:58"))
End Sub

Private Sub RenderSkeletonView
	Dim skelArt As SDUI5Skeleton
	skelArt.Initialize(Me, "skelArtM", "skelArtM")
	skelArt.ParentID = "contentWrapperM"
	skelArt.Classes = "w-full h-32 rounded-2xl bg-pink-200/60 my-1"
	BANano.Await(skelArt.AddComponent)

	Dim skelMeta As SDUI5Skeleton
	skelMeta.Initialize(Me, "skelMetaM", "skelMetaM")
	skelMeta.ParentID = "contentWrapperM"
	skelMeta.Classes = "w-full h-10 rounded-xl bg-pink-200/60 mt-1.5"
	BANano.Await(skelMeta.AddComponent)

	Dim skelProg As SDUI5Skeleton
	skelProg.Initialize(Me, "skelProgM", "skelProgM")
	skelProg.ParentID = "contentWrapperM"
	skelProg.Classes = "w-full h-2 rounded-full bg-pink-200/60 mt-1.5"
	BANano.Await(skelProg.AddComponent)

	Dim skelCtl As SDUI5Skeleton
	skelCtl.Initialize(Me, "skelCtlM", "skelCtlM")
	skelCtl.ParentID = "contentWrapperM"
	skelCtl.Classes = "w-full h-8 rounded-xl bg-pink-200/60 mt-1.5"
	BANano.Await(skelCtl.AddComponent)

	Dim skelQueue As SDUI5Skeleton
	skelQueue.Initialize(Me, "skelQueueM", "skelQueueM")
	skelQueue.ParentID = "contentWrapperM"
	skelQueue.Classes = "w-full h-16 rounded-xl bg-pink-200/60 mt-1.5"
	BANano.Await(skelQueue.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCardM", "emptyCardM")
	emptyCard.ParentID = "contentWrapperM"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-5 my-auto rounded-2xl bg-white shadow-md border border-pink-100 text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitleM", "empTitleM")
	empTitle.ParentID = "emptyCardM"
	empTitle.TextTag = "h2"
	empTitle.Text = "PLAYLIST IS SLEEPING"
	empTitle.Classes = "text-base font-black text-purple-900"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsgM", "empMsgM")
	empMsg.ParentID = "emptyCardM"
	empMsg.TextTag = "p"
	empMsg.Text = "No tunes lined up in your pastel playlist. Drop tracks to begin groove."
	empMsg.Classes = "text-[11px] font-semibold text-slate-500 mt-1 max-w-xs"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCtaM", "empCtaM")
	empCta.ParentID = "emptyCardM"
	empCta.Text = "+ ADD TUNES"
	empCta.Classes = "mt-3 rounded-full bg-pink-500 text-white font-black text-xs px-4 py-1.5 shadow-md shadow-pink-500/30 border-none"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCardM", "errCardM")
	errCard.ParentID = "contentWrapperM"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-5 my-auto rounded-2xl bg-red-50 shadow-md border border-red-200 text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitleM", "errTitleM")
	errTitle.ParentID = "errCardM"
	errTitle.TextTag = "h2"
	errTitle.Text = "AUDIO STREAM LOST"
	errTitle.Classes = "text-base font-black text-red-800"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsgM", "errMsgM")
	errMsg.ParentID = "errCardM"
	errMsg.TextTag = "p"
	errMsg.Text = "Connection to the high-res music server dropped. Re-establishing link."
	errMsg.Classes = "text-[11px] font-medium text-red-600 mt-1 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCtaM", "errCtaM")
	errCta.ParentID = "errCardM"
	errCta.Text = "RECONNECT STREAM"
	errCta.Classes = "mt-3 rounded-full bg-red-600 text-white font-black text-xs px-4 py-1.5 shadow-md shadow-red-500/30 border-none"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddTrack(id As String, parentId As String, title As String, duration As String)
	Dim item As SDUI5ListItem
	item.Initialize(Me, id, id)
	item.ParentID = parentId
	item.Text = title & " - " & duration
	item.Classes = "px-2 py-1 text-[11px] font-bold text-slate-800 hover:bg-pink-50 cursor-pointer"
	BANano.Await(item.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPopM_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateM = "populated"
	Show
End Sub

Private Sub btnStSkelM_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateM = "skeleton"
	Show
End Sub

Private Sub btnStEmptyM_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateM = "empty"
	Show
End Sub

Private Sub btnStErrM_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateM = "error"
	Show
End Sub

Private Sub empCtaM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Added 5 summer grooves", 2000)
	currentViewStateM = "populated"
	Show
End Sub

Private Sub errCtaM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Audio stream recovered", 2000)
	currentViewStateM = "populated"
	Show
End Sub

Private Sub btnPrevM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Previous groove", 1500)
End Sub

Private Sub btnPlayM_Click(e As BANanoEvent)
	e.PreventDefault
	isPlayingM = Not(isPlayingM)
	If isPlayingM Then
		btnPlayM.Text = "PAUSE"
		app.ShowSwalSuccessToast("Resumed playback", 1500)
	Else
		btnPlayM.Text = "PLAY"
		app.ShowSwalInfoToast("Playback paused", 1500)
	End If
End Sub

Private Sub btnNextM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Next groove", 1500)
End Sub

Private Sub volSliderM_Change(e As BANanoEvent)
	e.PreventDefault
End Sub
