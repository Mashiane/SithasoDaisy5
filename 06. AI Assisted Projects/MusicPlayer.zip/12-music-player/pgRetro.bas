﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnPrevR As SDUI5Button 'ignore
	Private btnPlayR As SDUI5Button 'ignore
	Private btnNextR As SDUI5Button 'ignore
	Private volSliderR As SDUI5Range 'ignore
	Private isPlayingR As Boolean = True
	Private currentViewStateR As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)
	
	' Desktop Phone Chassis containment with Win95 Teal desktop backdrop
	Dim page As SDUI5Container
	page.Initialize(Me, "retroPage", "retroPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-1 sm:rounded-[24px] sm:shadow-2xl bg-[#008080] p-2 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Windows 95 Style Application Window
	Dim winApp As SDUI5Container
	winApp.Initialize(Me, "winApp", "winApp")
	winApp.ParentID = "retroPage"
	winApp.Container = False
	winApp.Classes = "bg-[#C0C0C0] border-2 border-t-white border-l-white border-b-black border-r-black p-2 flex flex-col justify-between flex-1 shadow-xl"
	BANano.Await(winApp.AddComponent)

	' Win95 Titlebar
	Dim titleBar As SDUI5Container
	titleBar.Initialize(Me, "titleBarR", "titleBarR")
	titleBar.ParentID = "winApp"
	titleBar.Container = False
	titleBar.Classes = "bg-[#000080] text-white px-2 py-0.5 flex items-center justify-between font-bold text-xs"
	BANano.Await(titleBar.AddComponent)

	Dim winTitle As SDUI5Text
	winTitle.Initialize(Me, "winTitle", "winTitle")
	winTitle.ParentID = "titleBarR"
	winTitle.TextTag = "span"
	winTitle.Text = "WIN-AMP 95 - [AMBER REEL.WAV]"
	winTitle.Classes = "tracking-wider font-mono text-[11px]"
	BANano.Await(winTitle.AddComponent)

	Dim winCtls As SDUI5Text
	winCtls.Initialize(Me, "winCtls", "winCtls")
	winCtls.ParentID = "titleBarR"
	winCtls.TextTag = "span"
	winCtls.Text = "[ ? ] [ X ]"
	winCtls.Classes = "font-mono font-black text-xs cursor-pointer"
	BANano.Await(winCtls.AddComponent)

	' State Switcher Bar (Win95 tab row)
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBarR", "stateBarR")
	stateBar.ParentID = "winApp"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1 mt-1"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-[#C0C0C0]"
	Dim skelStyle As String = "bg-[#C0C0C0]"
	Dim empStyle As String = "bg-[#C0C0C0]"
	Dim errStyle As String = "bg-[#C0C0C0]"

	If currentViewStateR = "skeleton" Then
		skelStyle = "bg-[#000080] text-white font-black"
	Else If currentViewStateR = "empty" Then
		empStyle = "bg-[#000080] text-white font-black"
	Else If currentViewStateR = "error" Then
		errStyle = "bg-[#000080] text-white font-black"
	Else
		popStyle = "bg-[#000080] text-white font-black"
	End If

	BANano.Await(AddStateBtn("btnStPopR", "stateBarR", "PLAY", popStyle))
	BANano.Await(AddStateBtn("btnStSkelR", "stateBarR", "BUF", skelStyle))
	BANano.Await(AddStateBtn("btnStEmptyR", "stateBarR", "EMPTY", empStyle))
	BANano.Await(AddStateBtn("btnStErrR", "stateBarR", "ERR", errStyle))

	' Content Container
	Dim contentWrapperR As SDUI5Container
	contentWrapperR.Initialize(Me, "contentWrapperR", "contentWrapperR")
	contentWrapperR.ParentID = "winApp"
	contentWrapperR.Container = False
	contentWrapperR.Classes = "flex-1 flex flex-col justify-between mt-1"
	BANano.Await(contentWrapperR.AddComponent)

	Select Case currentViewStateR
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	pgIndex.UpdateTitle("Retro Win95 Player | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-none border border-t-white border-l-white border-b-black border-r-black text-black font-mono text-[10px] " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Matrix Green VFD Display Box
	Dim lcdBox As SDUI5Container
	lcdBox.Initialize(Me, "lcdBox", "lcdBox")
	lcdBox.ParentID = "contentWrapperR"
	lcdBox.Container = False
	lcdBox.Classes = "bg-black p-2 border-2 border-t-black border-l-black border-b-white border-r-white mt-1 shadow-inner"
	BANano.Await(lcdBox.AddComponent)

	Dim lcdText As SDUI5Text
	lcdText.Initialize(Me, "lcdText", "lcdText")
	lcdText.ParentID = "lcdBox"
	lcdText.TextTag = "div"
	lcdText.Text = "01:42 - AMBER REEL.WAV [128K 44.1K]"
	lcdText.Classes = "font-['VT323',monospace] text-lg text-[#00FF00] tracking-widest leading-none truncate"
	BANano.Await(lcdText.AddComponent)

	Dim lcdViz As SDUI5Text
	lcdViz.Initialize(Me, "lcdViz", "lcdViz")
	lcdViz.ParentID = "lcdBox"
	lcdViz.TextTag = "div"
	lcdViz.Text = "| | || ||| |||| ||||| |||| ||| || | [EQ NORMAL]"
	lcdViz.Classes = "font-['VT323',monospace] text-xs text-[#00FF66] tracking-wider mt-0.5 opacity-80"
	BANano.Await(lcdViz.AddComponent)

	' Album Artwork with sunken frame
	Dim artWrap As SDUI5Container
	artWrap.Initialize(Me, "artWrapR", "artWrapR")
	artWrap.ParentID = "contentWrapperR"
	artWrap.Container = False
	artWrap.Classes = "border-2 border-t-black border-l-black border-b-white border-r-white p-0.5 bg-neutral-900 my-1"
	BANano.Await(artWrap.AddComponent)

	Dim art As SDUI5Image
	art.Initialize(Me, "retroArt", "retroArt")
	art.ParentID = "artWrapR"
	art.Src = "./assets/tape.jpg"
	art.Alt = "Sample album artwork"
	art.Classes = "w-full h-28 object-cover"
	BANano.Await(art.AddComponent)

	' Progress Bar
	Dim progBox As SDUI5Container
	progBox.Initialize(Me, "progBoxR", "progBoxR")
	progBox.ParentID = "contentWrapperR"
	progBox.Container = False
	progBox.Classes = "mt-1"
	BANano.Await(progBox.AddComponent)

	Dim pos As SDUI5Progress
	pos.Initialize(Me, "retroProgress", "retroProgress")
	pos.ParentID = "progBoxR"
	pos.Value = "42"
	pos.Height = "8px"
	pos.Classes = "rounded-none border border-t-black border-l-black border-b-white border-r-white bg-white progress-warning"
	BANano.Await(pos.AddComponent)

	' Beveled Transport Buttons
	Dim ctlRow As SDUI5Container
	ctlRow.Initialize(Me, "ctlRowR", "ctlRowR")
	ctlRow.ParentID = "contentWrapperR"
	ctlRow.Container = False
	ctlRow.Classes = "flex items-center justify-between gap-1 mt-1"
	BANano.Await(ctlRow.AddComponent)

	btnPrevR.Initialize(Me, "btnPrevR", "btnPrevR")
	btnPrevR.ParentID = "ctlRowR"
	btnPrevR.Text = "|<< PREV"
	btnPrevR.Classes = "flex-1 rounded-none border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-black font-mono font-bold text-[11px] py-1 active:border-t-black active:border-l-black"
	BANano.Await(btnPrevR.AddComponent)

	btnPlayR.Initialize(Me, "btnPlayR", "btnPlayR")
	btnPlayR.ParentID = "ctlRowR"
	If isPlayingR Then
		btnPlayR.Text = "[ || PAUSE ]"
	Else
		btnPlayR.Text = "[ |> PLAY ]"
	End If
	btnPlayR.Classes = "flex-[1.4] rounded-none border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-black font-mono font-black text-xs py-1 active:border-t-black active:border-l-black"
	BANano.Await(btnPlayR.AddComponent)

	btnNextR.Initialize(Me, "btnNextR", "btnNextR")
	btnNextR.ParentID = "ctlRowR"
	btnNextR.Text = "NEXT >>|"
	btnNextR.Classes = "flex-1 rounded-none border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-black font-mono font-bold text-[11px] py-1 active:border-t-black active:border-l-black"
	BANano.Await(btnNextR.AddComponent)

	' Sunken Volume Control
	Dim volBox As SDUI5Container
	volBox.Initialize(Me, "volBoxR", "volBoxR")
	volBox.ParentID = "contentWrapperR"
	volBox.Container = False
	volBox.Classes = "mt-1 p-0.5 border border-t-black border-l-black border-b-white border-r-white bg-[#D4D0C8]"
	BANano.Await(volBox.AddComponent)

	volSliderR.Initialize(Me, "volSliderR", "volSliderR")
	volSliderR.ParentID = "volBoxR"
	volSliderR.Label = "WAVE OUTPUT GAIN"
	volSliderR.MinValue = "0"
	volSliderR.MaxValue = "100"
	volSliderR.Value = "70"
	volSliderR.Classes = "range-xs"
	BANano.Await(volSliderR.AddComponent)

	' Sunken Classic Win95 Listbox Queue
	Dim queueHead As SDUI5Container
	queueHead.Initialize(Me, "queueHeadR", "queueHeadR")
	queueHead.ParentID = "contentWrapperR"
	queueHead.Container = False
	queueHead.Classes = "flex items-center justify-between mt-1 mb-0.5"
	BANano.Await(queueHead.AddComponent)

	Dim qTitle As SDUI5Text
	qTitle.Initialize(Me, "qTitleR", "qTitleR")
	qTitle.ParentID = "queueHeadR"
	qTitle.TextTag = "span"
	qTitle.Text = "PLAYLIST.M3U"
	qTitle.Classes = "font-mono font-bold text-xs text-black uppercase"
	BANano.Await(qTitle.AddComponent)

	Dim count As SDUI5Badge
	count.Initialize(Me, "retroCount", "retroCount")
	count.ParentID = "queueHeadR"
	count.Text = "3 FILES"
	count.Classes = "badge-xs rounded-none bg-neutral-700 text-white font-mono"
	BANano.Await(count.AddComponent)

	Dim queue As SDUI5List
	queue.Initialize(Me, "retroQueue", "retroQueue")
	queue.ParentID = "contentWrapperR"
	queue.Classes = "border-2 border-t-black border-l-black border-b-white border-r-white bg-white divide-y divide-neutral-200"
	BANano.Await(queue.AddComponent)

	BANano.Await(AddTrack("rTrack1", "retroQueue", "01_NEON_STATIC.WAV", "3:12"))
	BANano.Await(AddTrack("rTrack2", "retroQueue", "02_AMBER_REEL.WAV [CURRENT]", "4:05"))
	BANano.Await(AddTrack("rTrack3", "retroQueue", "03_PAPER_WALLS.WAV", "2:58"))
End Sub

Private Sub RenderSkeletonView
	Dim skelLcd As SDUI5Skeleton
	skelLcd.Initialize(Me, "skelLcdR", "skelLcdR")
	skelLcd.ParentID = "contentWrapperR"
	skelLcd.Classes = "w-full h-10 bg-neutral-800 rounded-none border border-neutral-600 mt-1"
	BANano.Await(skelLcd.AddComponent)

	Dim skelArt As SDUI5Skeleton
	skelArt.Initialize(Me, "skelArtR", "skelArtR")
	skelArt.ParentID = "contentWrapperR"
	skelArt.Classes = "w-full h-28 bg-neutral-400 rounded-none border border-black my-1"
	BANano.Await(skelArt.AddComponent)

	Dim skelCtl As SDUI5Skeleton
	skelCtl.Initialize(Me, "skelCtlR", "skelCtlR")
	skelCtl.ParentID = "contentWrapperR"
	skelCtl.Classes = "w-full h-8 bg-neutral-400 rounded-none border border-black mt-1"
	BANano.Await(skelCtl.AddComponent)

	Dim skelList As SDUI5Skeleton
	skelList.Initialize(Me, "skelListR", "skelListR")
	skelList.ParentID = "contentWrapperR"
	skelList.Classes = "w-full h-14 bg-white rounded-none border border-black mt-1"
	BANano.Await(skelList.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCardR", "emptyCardR")
	emptyCard.ParentID = "contentWrapperR"
	emptyCard.Container = False
	emptyCard.Classes = "p-4 my-auto border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitleR", "empTitleR")
	empTitle.ParentID = "emptyCardR"
	empTitle.TextTag = "h2"
	empTitle.Text = "NO FILES IN PLAYLIST"
	empTitle.Classes = "font-mono font-bold text-xs text-black uppercase"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsgR", "empMsgR")
	empMsg.ParentID = "emptyCardR"
	empMsg.TextTag = "p"
	empMsg.Text = "Select audio files from Drive C:\SOUNDS\ to build playlist."
	empMsg.Classes = "font-mono text-[11px] text-neutral-700 mt-1"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCtaR", "empCtaR")
	empCta.ParentID = "emptyCardR"
	empCta.Text = "OPEN FILE [Browse...]"
	empCta.Classes = "mt-3 rounded-none border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-black font-mono font-bold text-xs px-3 py-1"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCardR", "errCardR")
	errCard.ParentID = "contentWrapperR"
	errCard.Container = False
	errCard.Classes = "p-4 my-auto border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitleR", "errTitleR")
	errTitle.ParentID = "errCardR"
	errTitle.TextTag = "h2"
	errTitle.Text = "MMSYSTEM ERROR 263"
	errTitle.Classes = "font-mono font-bold text-xs text-red-700 uppercase"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsgR", "errMsgR")
	errMsg.ParentID = "errCardR"
	errMsg.TextTag = "p"
	errMsg.Text = "A sound device error occurred. Check SoundBlaster 16 IRQ 7 DMA 1."
	errMsg.Classes = "font-mono text-[11px] text-black mt-1"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCtaR", "errCtaR")
	errCta.ParentID = "errCardR"
	errCta.Text = "RESET MIDI / DMA"
	errCta.Classes = "mt-3 rounded-none border-2 border-t-white border-l-white border-b-black border-r-black bg-[#C0C0C0] text-black font-mono font-bold text-xs px-3 py-1"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddTrack(id As String, parentId As String, filename As String, duration As String)
	Dim item As SDUI5ListItem
	item.Initialize(Me, id, id)
	item.ParentID = parentId
	item.Text = filename & " [" & duration & "]"
	item.Classes = "px-1.5 py-0.5 font-mono text-[10px] text-black hover:bg-[#000080] hover:text-white cursor-pointer"
	BANano.Await(item.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPopR_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateR = "populated"
	Show
End Sub

Private Sub btnStSkelR_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateR = "skeleton"
	Show
End Sub

Private Sub btnStEmptyR_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateR = "empty"
	Show
End Sub

Private Sub btnStErrR_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewStateR = "error"
	Show
End Sub

Private Sub empCtaR_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Loaded playlist from disk", 2000)
	currentViewStateR = "populated"
	Show
End Sub

Private Sub errCtaR_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Sound card reset successfully", 2000)
	currentViewStateR = "populated"
	Show
End Sub

Private Sub btnPrevR_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Previous audio file", 1500)
End Sub

Private Sub btnPlayR_Click(e As BANanoEvent)
	e.PreventDefault
	isPlayingR = Not(isPlayingR)
	If isPlayingR Then
		btnPlayR.Text = "[ || PAUSE ]"
		app.ShowSwalSuccessToast("Playback resumed", 1500)
	Else
		btnPlayR.Text = "[ |> PLAY ]"
		app.ShowSwalInfoToast("Playback paused", 1500)
	End If
End Sub

Private Sub btnNextR_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Next audio file", 1500)
End Sub

Private Sub volSliderR_Change(e As BANanoEvent)
	e.PreventDefault
End Sub
