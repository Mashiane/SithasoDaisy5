﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Social Profile App Shell
#IgnoreWarnings:12
Sub Process_Globals
	Public BANano As BANano 'ignore
	Public App As SDUI5App	'ignore
	Private pageView As SDUI5Container 'ignore
	Private navPastel As SDUI5Button 'ignore
	Private navMinimal As SDUI5Button 'ignore
	Private navDark As SDUI5Button 'ignore
	Public activeStyle As String = "pastel"
End Sub

Sub Initialize
	BANano.Await(App.Initialize(Me))
	App.RemoveClass("w-screen")
	App.AddClass("font-['Plus_Jakarta_Sans',sans-serif] antialiased min-h-screen bg-[#F0EFEA] text-slate-800")

	Dim navrow As SDUI5Container
	navrow.Initialize(Me, "navrow", "navrow")
	navrow.ParentID = App.Here
	navrow.Container = False
	navrow.Classes = "max-w-md mx-auto flex items-center justify-center gap-2 px-4 pt-2.5 pb-1"
	BANano.Await(navrow.AddComponent)

	navPastel.Initialize(Me, "navPastel", "navPastel")
	navPastel.ParentID = "navrow"
	navPastel.Text = "Pastel Friendly"
	navPastel.TextSize = "xs"
	navPastel.Size = "xs"
	navPastel.Classes = "rounded-xl font-semibold bg-rose-400 text-white border-none shadow-sm"
	BANano.Await(navPastel.AddComponent)

	navMinimal.Initialize(Me, "navMinimal", "navMinimal")
	navMinimal.ParentID = "navrow"
	navMinimal.Text = "Clean Minimal"
	navMinimal.TextSize = "xs"
	navMinimal.Size = "xs"
	navMinimal.Classes = "rounded-xl font-semibold bg-white text-slate-700 border-none shadow-sm hover:bg-slate-100"
	BANano.Await(navMinimal.AddComponent)

	navDark.Initialize(Me, "navDark", "navDark")
	navDark.ParentID = "navrow"
	navDark.Text = "Dark Mode"
	navDark.TextSize = "xs"
	navDark.Size = "xs"
	navDark.Classes = "rounded-xl font-semibold bg-neutral-900 text-white border-none shadow-sm hover:bg-neutral-800"
	BANano.Await(navDark.AddComponent)

	pageView.Initialize(Me, "pageview", "pageview")
	pageView.ParentID = App.Here
	pageView.Container = False
	BANano.Await(pageView.AddComponent)

	BANano.Await(pgPastel.Show)
	App.pageresume
End Sub

Sub UpdateTitle(s As String)
	BANano.Window.SetField("document.title", s)
End Sub

Private Sub navPastel_Click(e As BANanoEvent)
	e.PreventDefault
	activeStyle = "pastel"
	BANano.Await(pgPastel.Show)
End Sub

Private Sub navMinimal_Click(e As BANanoEvent)
	e.PreventDefault
	activeStyle = "minimal"
	BANano.Await(pgMinimal.Show)
End Sub

Private Sub navDark_Click(e As BANanoEvent)
	e.PreventDefault
	activeStyle = "dark"
	BANano.Await(pgDark.Show)
End Sub
