﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Social Media Profile (Pastel Friendly Style)
#IgnoreWarnings:12
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnFollow As SDUI5Button 'ignore
	Private btnMessage As SDUI5Button 'ignore
	Private profileAvatar As SDUI5Avatar 'ignore
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	'Root container with desktop mobile-phone chassis ergonomics
	Dim page As SDUI5Container
	page.Initialize(Me, "pastelPage", "pastelPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-2 sm:rounded-[32px] sm:shadow-xl sm:border sm:border-rose-200/60 overflow-hidden relative pb-4 bg-[#FFFDF9]"
	BANano.Await(page.AddComponent)

	'Profile Header Banner & Avatar Card
	Dim topCard As SDUI5Container
	topCard.Initialize(Me, "topCard", "topCard")
	topCard.ParentID = "pastelPage"
	topCard.Container = False
	topCard.Classes = "pt-5 px-5 text-center"
	BANano.Await(topCard.AddComponent)

	profileAvatar.Initialize(Me, "profileAvatar", "profileAvatar")
	profileAvatar.ParentID = "topCard"
	profileAvatar.AvatarType = "image"
	profileAvatar.Image = "./assets/profile.jpg"
	profileAvatar.Mask = "circle"
	profileAvatar.Size = "16"
	profileAvatar.Ring = True
	profileAvatar.RingColor = "#FBCFE8"
	BANano.Await(profileAvatar.AddComponent)

	BANano.Await(AddText("pastelName", "topCard", "Maya Chen", "h1", "xl", "bold", "font-['Plus_Jakarta_Sans'] mt-2 text-slate-900", "#1E293B"))
	BANano.Await(AddText("pastelHandle", "topCard", "@mayachen | Botanical Illustrator", "p", "xs", "semibold", "mt-0.5 text-rose-500", "#F43F5E"))
	BANano.Await(AddText("pastelBio", "topCard", "Ceramicist and plant lover. Creating warm prints and handmade ceramics for mindful living.", "p", "xs", "normal", "mt-1.5 px-2 text-slate-600 leading-relaxed", "#475569"))

	'Metrics Trio (Posts, Followers, Following)
	Dim metricsRow As SDUI5Container
	metricsRow.Initialize(Me, "metricsRow", "metricsRow")
	metricsRow.ParentID = "pastelPage"
	metricsRow.Container = False
	metricsRow.Classes = "grid grid-cols-3 gap-2 mx-5 mt-2.5 p-2 rounded-xl bg-rose-50/70 border border-rose-100 text-center"
	BANano.Await(metricsRow.AddComponent)

	BANano.Await(AddMetricChip("m1", "metricsRow", "Posts", "248"))
	BANano.Await(AddMetricChip("m2", "metricsRow", "Followers", "14.2K"))
	BANano.Await(AddMetricChip("m3", "metricsRow", "Following", "386"))

	'Action Buttons Duo
	Dim actionsRow As SDUI5Container
	actionsRow.Initialize(Me, "actionsRow", "actionsRow")
	actionsRow.ParentID = "pastelPage"
	actionsRow.Container = False
	actionsRow.Classes = "flex gap-2 mx-5 mt-2.5"
	BANano.Await(actionsRow.AddComponent)

	btnFollow.Initialize(Me, "btnFollow", "btnFollow")
	btnFollow.ParentID = "actionsRow"
	btnFollow.Text = "Follow"
	btnFollow.Classes = "btn-sm flex-1 rounded-xl font-semibold bg-[#F472B6] text-white border-none shadow-xs hover:bg-[#E11D48]"
	BANano.Await(btnFollow.AddComponent)

	btnMessage.Initialize(Me, "btnMessage", "btnMessage")
	btnMessage.ParentID = "actionsRow"
	btnMessage.Text = "Message"
	btnMessage.Classes = "btn-sm flex-1 rounded-xl font-semibold bg-[#DDD6FE] text-purple-900 border-none shadow-xs hover:bg-[#C4B5FD]"
	BANano.Await(btnMessage.AddComponent)

	'3x3 Photo Gallery Grid
	Dim gridRow As SDUI5Container
	gridRow.Initialize(Me, "pastelGrid", "pastelGrid")
	gridRow.ParentID = "pastelPage"
	gridRow.Container = False
	gridRow.Classes = "grid grid-cols-3 gap-1.5 mx-5 mt-2.5"
	BANano.Await(gridRow.AddComponent)

	BANano.Await(AddGridTile("p1", "pastelGrid", "Morning Sketch", "./assets/swiper_01.jpg"))
	BANano.Await(AddGridTile("p2", "pastelGrid", "Studio Vases", "./assets/swiper_02.jpg"))
	BANano.Await(AddGridTile("p3", "pastelGrid", "New Print", "./assets/swiper_03.jpg"))
	BANano.Await(AddGridTile("p4", "pastelGrid", "Fern Corner", "./assets/swiper_04.jpg"))
	BANano.Await(AddGridTile("p5", "pastelGrid", "Clay Pot", "./assets/swiper_05.jpg"))
	BANano.Await(AddGridTile("p6", "pastelGrid", "Worktable", "./assets/swiper_06.jpg"))
	BANano.Await(AddGridTile("p7", "pastelGrid", "Pressed Flora", "./assets/swiper_07.jpg"))
	BANano.Await(AddGridTile("p8", "pastelGrid", "Tea Mug", "./assets/swiper_08.jpg"))
	BANano.Await(AddGridTile("p9", "pastelGrid", "Garden Studio", "./assets/swiper_09.jpg"))

	BANano.Await(AddText("pastelNote", "pastelPage", "Style: Light Pastel Friendly | Demo Mode", "p", "xs", "normal", "text-center mt-2.5 pb-1 text-rose-400", "#FB7185"))

	pgIndex.UpdateTitle("Pastel Profile")
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

Private Sub AddMetricChip(id As String, parentId As String, label As String, value As String)
	Dim chip As SDUI5Container
	chip.Initialize(Me, id, id)
	chip.ParentID = parentId
	chip.Container = False
	chip.Classes = "flex flex-col items-center"
	BANano.Await(chip.AddComponent)
	BANano.Await(AddText(id & "Val", id, value, "span", "base", "bold", "font-['Plus_Jakarta_Sans'] text-slate-800", "#1E293B"))
	BANano.Await(AddText(id & "Lbl", id, label, "span", "xs", "medium", "text-slate-500", "#64748B"))
End Sub

Private Sub AddGridTile(id As String, parentId As String, caption As String, imgPath As String)
	Dim tile As SDUI5Container
	tile.Initialize(Me, id, id)
	tile.ParentID = parentId
	tile.Container = False
	tile.Classes = "aspect-square rounded-2xl overflow-hidden relative shadow-sm group border border-pink-100/60"
	BANano.Await(tile.AddComponent)

	Dim img As SDUI5Image
	img.Initialize(Me, id & "Img", id & "Img")
	img.ParentID = id
	img.Src = imgPath
	img.Alt = caption
	img.Classes = "w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
	BANano.Await(img.AddComponent)

	Dim capBox As SDUI5Container
	capBox.Initialize(Me, id & "CapBox", id & "CapBox")
	capBox.ParentID = id
	capBox.Container = False
	capBox.Classes = "absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/70 via-slate-950/30 to-transparent p-1.5 flex items-end justify-center"
	BANano.Await(capBox.AddComponent)

	BANano.Await(AddText(id & "Cap", id & "CapBox", caption, "span", "xs", "semibold", "text-white text-[10px] drop-shadow text-center leading-tight truncate px-1", "#FFFFFF"))
End Sub

Private Sub btnFollow_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Following Maya Chen", 2000)
End Sub

Private Sub btnMessage_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Opening message composer...", 2000)
End Sub

Private Sub profileAvatar_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Viewing profile photo", 2000)
End Sub
