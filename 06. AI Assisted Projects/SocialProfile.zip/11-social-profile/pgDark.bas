﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Social Media Profile (Dark Mode Sleek Style)
#IgnoreWarnings:12
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnFollowD As SDUI5Button 'ignore
	Private btnMessageD As SDUI5Button 'ignore
	Private profileAvatarD As SDUI5Avatar 'ignore
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	'Root container with desktop mobile-phone chassis ergonomics
	Dim page As SDUI5Container
	page.Initialize(Me, "darkPage", "darkPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-2 sm:rounded-[32px] sm:shadow-[0_20px_50px_rgba(0,0,0,0.8)] sm:border sm:border-neutral-800 overflow-hidden relative pb-4 bg-[#0D0D11] text-white"
	BANano.Await(page.AddComponent)

	'Dark Mode Header & Avatar
	Dim topBox As SDUI5Container
	topBox.Initialize(Me, "topBoxD", "topBoxD")
	topBox.ParentID = "darkPage"
	topBox.Container = False
	topBox.Classes = "pt-5 px-5 text-center"
	BANano.Await(topBox.AddComponent)

	profileAvatarD.Initialize(Me, "profileAvatarD", "profileAvatarD")
	profileAvatarD.ParentID = "topBoxD"
	profileAvatarD.AvatarType = "image"
	profileAvatarD.Image = "./assets/profile.jpg"
	profileAvatarD.Mask = "circle"
	profileAvatarD.Size = "16"
	profileAvatarD.Ring = True
	profileAvatarD.RingColor = "#818CF8"
	BANano.Await(profileAvatarD.AddComponent)

	BANano.Await(AddText("dName", "topBoxD", "Maya Chen", "h1", "xl", "bold", "font-['Plus_Jakarta_Sans'] mt-2 text-white tracking-tight", "#FFFFFF"))
	BANano.Await(AddText("dHandle", "topBoxD", "@mayachen | Creative Director", "p", "xs", "semibold", "mt-0.5 text-indigo-400", "#818CF8"))
	BANano.Await(AddText("dBio", "topBoxD", "Visual director and digital artist. Exploring brutalism, light, and motion in contemporary design.", "p", "xs", "normal", "mt-1.5 px-3 text-neutral-400 leading-relaxed", "#A1A1AA"))

	'Metrics Trio (Dark Carbon Container)
	Dim metricsRow As SDUI5Container
	metricsRow.Initialize(Me, "metricsRowD", "metricsRowD")
	metricsRow.ParentID = "darkPage"
	metricsRow.Container = False
	metricsRow.Classes = "grid grid-cols-3 gap-2 mx-5 mt-2.5 p-2 rounded-xl bg-[#18181F] border border-neutral-800 text-center"
	BANano.Await(metricsRow.AddComponent)

	BANano.Await(AddDarkMetric("dm1", "metricsRowD", "Posts", "312"))
	BANano.Await(AddDarkMetric("dm2", "metricsRowD", "Followers", "42.8K"))
	BANano.Await(AddDarkMetric("dm3", "metricsRowD", "Following", "519"))

	'Action Buttons Duo
	Dim actionsRow As SDUI5Container
	actionsRow.Initialize(Me, "actionsRowD", "actionsRowD")
	actionsRow.ParentID = "darkPage"
	actionsRow.Container = False
	actionsRow.Classes = "flex gap-2 mx-5 mt-2.5"
	BANano.Await(actionsRow.AddComponent)

	btnFollowD.Initialize(Me, "btnFollowD", "btnFollowD")
	btnFollowD.ParentID = "actionsRowD"
	btnFollowD.Text = "Follow"
	btnFollowD.Classes = "btn-sm flex-1 rounded-xl font-semibold bg-[#6366F1] text-white border-none shadow-[0_4px_15px_rgba(99,102,241,0.4)] hover:bg-[#4F46E5]"
	BANano.Await(btnFollowD.AddComponent)

	btnMessageD.Initialize(Me, "btnMessageD", "btnMessageD")
	btnMessageD.ParentID = "actionsRowD"
	btnMessageD.Text = "Message"
	btnMessageD.Classes = "btn-sm flex-1 rounded-xl font-semibold bg-[#1E1E26] text-neutral-200 border border-neutral-700/60 hover:bg-[#272733]"
	BANano.Await(btnMessageD.AddComponent)

	'3x3 Dark Photo Gallery Grid
	Dim gridRow As SDUI5Container
	gridRow.Initialize(Me, "darkGrid", "darkGrid")
	gridRow.ParentID = "darkPage"
	gridRow.Container = False
	gridRow.Classes = "grid grid-cols-3 gap-1.5 mx-5 mt-2.5"
	BANano.Await(gridRow.AddComponent)

	BANano.Await(AddDarkTile("dt1", "darkGrid", "Neon Tunnel", "./assets/swiper_01.jpg"))
	BANano.Await(AddDarkTile("dt2", "darkGrid", "Obsidian Tower", "./assets/swiper_02.jpg"))
	BANano.Await(AddDarkTile("dt3", "darkGrid", "Cyber Bloom", "./assets/swiper_03.jpg"))
	BANano.Await(AddDarkTile("dt4", "darkGrid", "Raw Steel", "./assets/swiper_04.jpg"))
	BANano.Await(AddDarkTile("dt5", "darkGrid", "Violet Dusk", "./assets/swiper_05.jpg"))
	BANano.Await(AddDarkTile("dt6", "darkGrid", "Monolith 01", "./assets/swiper_06.jpg"))
	BANano.Await(AddDarkTile("dt7", "darkGrid", "Laser Mesh", "./assets/swiper_07.jpg"))
	BANano.Await(AddDarkTile("dt8", "darkGrid", "Dark Quartz", "./assets/swiper_08.jpg"))
	BANano.Await(AddDarkTile("dt9", "darkGrid", "Void Study", "./assets/swiper_09.jpg"))

	BANano.Await(AddText("darkNote", "darkPage", "Style: Dark Mode Sleek | Demo Mode", "p", "xs", "normal", "text-center mt-2.5 pb-1 text-neutral-500", "#71717A"))

	pgIndex.UpdateTitle("Dark Mode Profile")
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

Private Sub AddDarkMetric(id As String, parentId As String, label As String, value As String)
	Dim chip As SDUI5Container
	chip.Initialize(Me, id, id)
	chip.ParentID = parentId
	chip.Container = False
	chip.Classes = "text-center"
	BANano.Await(chip.AddComponent)
	BANano.Await(AddText(id & "Val", id, value, "p", "base", "bold", "font-['Plus_Jakarta_Sans'] text-white", "#FFFFFF"))
	BANano.Await(AddText(id & "Lbl", id, label, "p", "xs", "normal", "text-neutral-400", "#A1A1AA"))
End Sub

Private Sub AddDarkTile(id As String, parentId As String, caption As String, imgPath As String)
	Dim tile As SDUI5Container
	tile.Initialize(Me, id, id)
	tile.ParentID = parentId
	tile.Container = False
	tile.Classes = "aspect-square rounded-2xl overflow-hidden relative border border-indigo-950/60 shadow-md group"
	BANano.Await(tile.AddComponent)

	Dim img As SDUI5Image
	img.Initialize(Me, id & "Img", id & "Img")
	img.ParentID = id
	img.Src = imgPath
	img.Alt = caption
	img.Classes = "w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
	BANano.Await(img.AddComponent)

	Dim capBox As SDUI5Container
	capBox.Initialize(Me, id & "CapBox", id & "CapBox")
	capBox.ParentID = id
	capBox.Container = False
	capBox.Classes = "absolute inset-x-0 bottom-0 bg-black/70 p-1 flex items-center justify-center"
	BANano.Await(capBox.AddComponent)

	BANano.Await(AddText(id & "Cap", id & "CapBox", caption, "span", "xs", "semibold", "text-indigo-200 text-[10px] leading-tight truncate px-1", "#C7D2FE"))
End Sub

Private Sub btnFollowD_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Following Maya Chen", 2000)
End Sub

Private Sub btnMessageD_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Opening message composer...", 2000)
End Sub

Private Sub profileAvatarD_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Viewing profile photo", 2000)
End Sub
