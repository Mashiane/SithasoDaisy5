﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module - Social Media Profile (Clean Minimal Light Mode with Liquid Glass Dock)
#IgnoreWarnings:12
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private btnFollowM As SDUI5Button 'ignore
	Private btnMessageM As SDUI5Button 'ignore
	Private profileAvatarM As SDUI5Avatar 'ignore
	Private activeTab As String = "grid"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	'Root container with desktop mobile-phone chassis ergonomics
	Dim page As SDUI5Container
	page.Initialize(Me, "minimalPage", "minimalPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "w-full sm:max-w-md sm:mx-auto sm:my-2 sm:rounded-[32px] sm:shadow-xl sm:border sm:border-slate-200 overflow-hidden relative pb-4 bg-white"
	BANano.Await(page.AddComponent)

	'Minimalist Header & Avatar
	Dim topBox As SDUI5Container
	topBox.Initialize(Me, "topBox", "topBox")
	topBox.ParentID = "minimalPage"
	topBox.Container = False
	topBox.Classes = "pt-5 px-5 text-center"
	BANano.Await(topBox.AddComponent)

	profileAvatarM.Initialize(Me, "profileAvatarM", "profileAvatarM")
	profileAvatarM.ParentID = "topBox"
	profileAvatarM.AvatarType = "image"
	profileAvatarM.Image = "./assets/profile.jpg"
	profileAvatarM.Mask = "circle"
	profileAvatarM.Size = "16"
	profileAvatarM.Ring = True
	profileAvatarM.RingColor = "#E4E4E7"
	BANano.Await(profileAvatarM.AddComponent)

	BANano.Await(AddText("mName", "topBox", "Maya Chen", "h1", "lg", "bold", "font-['Plus_Jakarta_Sans'] mt-2 text-neutral-900 tracking-tight", "#09090B"))
	BANano.Await(AddText("mHandle", "topBox", "@mayachen | Spatial Design", "p", "xs", "medium", "mt-0.5 text-neutral-500", "#71717A"))
	BANano.Await(AddText("mBio", "topBox", "Architectural interiors and minimal objects. Documenting spaces and daylight in Kyoto.", "p", "xs", "normal", "mt-1.5 px-3 text-neutral-600 leading-relaxed", "#52525B"))

	'Metrics Row (Understated Clean Numerals)
	Dim metricsRow As SDUI5Container
	metricsRow.Initialize(Me, "metricsRowM", "metricsRowM")
	metricsRow.ParentID = "minimalPage"
	metricsRow.Container = False
	metricsRow.Classes = "flex justify-around items-center mx-6 mt-2.5 py-2 border-y border-neutral-100"
	BANano.Await(metricsRow.AddComponent)

	BANano.Await(AddMinimalMetric("mm1", "metricsRowM", "Posts", "184"))
	BANano.Await(AddMinimalMetric("mm2", "metricsRowM", "Followers", "28.5K"))
	BANano.Await(AddMinimalMetric("mm3", "metricsRowM", "Following", "412"))

	'Action Buttons Duo
	Dim actionsRow As SDUI5Container
	actionsRow.Initialize(Me, "actionsRowM", "actionsRowM")
	actionsRow.ParentID = "minimalPage"
	actionsRow.Container = False
	actionsRow.Classes = "flex gap-2 mx-6 mt-2.5"
	BANano.Await(actionsRow.AddComponent)

	btnFollowM.Initialize(Me, "btnFollowM", "btnFollowM")
	btnFollowM.ParentID = "actionsRowM"
	btnFollowM.Text = "Follow"
	btnFollowM.Classes = "btn-sm flex-1 rounded-xl font-medium bg-neutral-900 text-white border-none shadow-xs hover:bg-neutral-800"
	BANano.Await(btnFollowM.AddComponent)

	btnMessageM.Initialize(Me, "btnMessageM", "btnMessageM")
	btnMessageM.ParentID = "actionsRowM"
	btnMessageM.Text = "Message"
	btnMessageM.Classes = "btn-sm flex-1 rounded-xl font-medium bg-neutral-100 text-neutral-800 border-none hover:bg-neutral-200"
	BANano.Await(btnMessageM.AddComponent)

	'Tab Selector (Grid, Saved, Tagged)
	Dim tabRow As SDUI5Container
	tabRow.Initialize(Me, "tabRow", "tabRow")
	tabRow.ParentID = "minimalPage"
	tabRow.Container = False
	tabRow.Classes = "flex justify-center gap-6 mx-6 mt-3 border-b border-neutral-100 pb-1.5 text-xs font-semibold"
	BANano.Await(tabRow.AddComponent)

	BANano.Await(AddText("tabGrid", "tabRow", "Grid (184)", "span", "xs", "bold", "text-neutral-900 border-b-2 border-neutral-900 pb-1.5 -mb-2", "#09090B"))
	BANano.Await(AddText("tabSaved", "tabRow", "Saved (32)", "span", "xs", "medium", "text-neutral-400 hover:text-neutral-600 cursor-pointer", "#A1A1AA"))
	BANano.Await(AddText("tabTagged", "tabRow", "Tagged", "span", "xs", "medium", "text-neutral-400 hover:text-neutral-600 cursor-pointer", "#A1A1AA"))

	'Photo Gallery Grid
	Dim gridRow As SDUI5Container
	gridRow.Initialize(Me, "minimalGrid", "minimalGrid")
	gridRow.ParentID = "minimalPage"
	gridRow.Container = False
	gridRow.Classes = "grid grid-cols-3 gap-1.5 mx-6 mt-2.5"
	BANano.Await(gridRow.AddComponent)

	BANano.Await(AddMinimalTile("mTile1", "minimalGrid", "Concrete Arch", "./assets/swiper_01.jpg"))
	BANano.Await(AddMinimalTile("mTile2", "minimalGrid", "Morning Light", "./assets/swiper_02.jpg"))
	BANano.Await(AddMinimalTile("mTile3", "minimalGrid", "Oak Chair", "./assets/swiper_03.jpg"))
	BANano.Await(AddMinimalTile("mTile4", "minimalGrid", "Stair Detail", "./assets/swiper_04.jpg"))
	BANano.Await(AddMinimalTile("mTile5", "minimalGrid", "Glass Pavilion", "./assets/swiper_05.jpg"))
	BANano.Await(AddMinimalTile("mTile6", "minimalGrid", "Tea Room", "./assets/swiper_06.jpg"))

	'Liquid Glass Navigation Dock (Requested Sleek Feature)
	Dim dockBox As SDUI5Container
	dockBox.Initialize(Me, "dockBox", "dockBox")
	dockBox.ParentID = "minimalPage"
	dockBox.Container = False
	dockBox.Classes = "rounded-full px-6 py-2 bg-neutral-900/80 backdrop-blur-md text-white shadow-xl flex items-center justify-around gap-6 border border-white/10 mx-6 mt-3.5"
	BANano.Await(dockBox.AddComponent)

	BANano.Await(AddText("dockHome", "dockBox", "Feed", "span", "xs", "bold", "text-white", "#FFFFFF"))
	BANano.Await(AddText("dockSearch", "dockBox", "Explore", "span", "xs", "medium", "text-neutral-400", "#A1A1AA"))
	BANano.Await(AddText("dockProfile", "dockBox", "Profile", "span", "xs", "bold", "text-teal-400", "#2DD4BF"))

	pgIndex.UpdateTitle("Clean Minimal Profile")
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

Private Sub AddMinimalMetric(id As String, parentId As String, label As String, value As String)
	Dim chip As SDUI5Container
	chip.Initialize(Me, id, id)
	chip.ParentID = parentId
	chip.Container = False
	chip.Classes = "text-center"
	BANano.Await(chip.AddComponent)
	BANano.Await(AddText(id & "Val", id, value, "p", "base", "bold", "text-neutral-900", "#09090B"))
	BANano.Await(AddText(id & "Lbl", id, label, "p", "xs", "normal", "text-neutral-400", "#A1A1AA"))
End Sub

Private Sub AddMinimalTile(id As String, parentId As String, caption As String, imgPath As String)
	Dim tile As SDUI5Container
	tile.Initialize(Me, id, id)
	tile.ParentID = parentId
	tile.Container = False
	tile.Classes = "aspect-square rounded-xl overflow-hidden relative border border-neutral-200/80 shadow-xs group"
	BANano.Await(tile.AddComponent)

	Dim img As SDUI5Image
	img.Initialize(Me, id & "Img", id & "Img")
	img.ParentID = id
	img.Src = imgPath
	img.Alt = caption
	img.Classes = "w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
	BANano.Await(img.AddComponent)

	Dim capBox As SDUI5Container
	capBox.Initialize(Me, id & "CapBox", id & "CapBox")
	capBox.ParentID = id
	capBox.Container = False
	capBox.Classes = "absolute inset-x-0 bottom-0 bg-neutral-900/60 p-1 flex items-center justify-center backdrop-blur-xs"
	BANano.Await(capBox.AddComponent)

	BANano.Await(AddText(id & "Cap", id & "CapBox", caption, "span", "xs", "medium", "text-white text-[10px] leading-tight truncate px-1", "#FFFFFF"))
End Sub

Private Sub btnFollowM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Following Maya Chen", 2000)
End Sub

Private Sub btnMessageM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Opening message composer...", 2000)
End Sub

Private Sub profileAvatarM_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Avatar clicked", 2000)
End Sub
