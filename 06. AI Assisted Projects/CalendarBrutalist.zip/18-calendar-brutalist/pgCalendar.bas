﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  brutalist month calendar.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private currentViewState As String = "populated"
	Private currentMonth As String = "OCTOBER 2026"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with manila brutalist background
	Dim page As SDUI5Container
	page.Initialize(Me, "calPage", "calPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.4)] border-4 border-black bg-[#FDFBF7] text-black font-['Space_Grotesk',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Asymmetric Header Section
	Dim topSec As SDUI5Container
	topSec.Initialize(Me, "topSec", "topSec")
	topSec.ParentID = "calPage"
	topSec.Container = False
	topSec.Classes = "flex flex-col"
	BANano.Await(topSec.AddComponent)

	Dim sticker As SDUI5Container
	sticker.Initialize(Me, "sticker", "sticker")
	sticker.ParentID = "topSec"
	sticker.Container = False
	sticker.Classes = "flex items-center justify-between"
	BANano.Await(sticker.AddComponent)

	BANano.Await(AddText("calKicker", "sticker", "CHAOS PLANNER // V1", "span", "xs", "bold", "-rotate-2 bg-black text-white px-2.5 py-1 font-mono tracking-widest text-[11px]", "#FFFFFF"))

	Dim tagToday As SDUI5Badge
	tagToday.Initialize(Me, "tagToday", "tagToday")
	tagToday.ParentID = "sticker"
	tagToday.Text = "OCT 14 = TODAY"
	tagToday.Classes = "badge-sm rounded-none border-2 border-black bg-[#FDE047] text-black font-black rotate-1 shadow-[2px_2px_0_#000000]"
	BANano.Await(tagToday.AddComponent)

	BANano.Await(AddText("calTitle", "topSec", currentMonth, "h1", "3xl", "black", "tracking-tight uppercase mt-2 text-black", "#000000"))

	' State Switcher Deck
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "calPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-3"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white text-black"
	Dim skelStyle As String = "bg-white text-black"
	Dim empStyle As String = "bg-white text-black"
	Dim errStyle As String = "bg-white text-black"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-black text-[#FDE047] font-bold"
	Else If currentViewState = "empty" Then
		empStyle = "bg-black text-[#FDE047] font-bold"
	Else If currentViewState = "error" Then
		errStyle = "bg-black text-[#FDE047] font-bold"
	Else
		popStyle = "bg-black text-[#FDE047] font-bold"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "SCHEDULE", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "BUFFER", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "CLEAR DAY", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "CONFLICT", errStyle))

	' Content Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "calPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-3"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "calPage", "High-Velocity Task Architecture | No Grid Compromise", "p", "xs", "bold", "text-center text-neutral-500 font-mono mt-4", "#737373"))
	pgIndex.UpdateTitle("Brutal Calendar | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-none border-2 border-black font-mono text-[10px] " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Day of Week Header Grid
	Dim headGrid As SDUI5Container
	headGrid.Initialize(Me, "headGrid", "headGrid")
	headGrid.ParentID = "contentWrapper"
	headGrid.Container = False
	headGrid.Classes = "grid grid-cols-7 gap-1"
	BANano.Await(headGrid.AddComponent)

	Dim dows As List = Array("MO", "TU", "WE", "TH", "FR", "SA", "SU")
	For i = 0 To dows.Size - 1
		Dim dowCell As SDUI5Container
		dowCell.Initialize(Me, "dow" & i, "dow" & i)
		dowCell.ParentID = "headGrid"
		dowCell.Container = False
		dowCell.Classes = "py-1 text-center border-2 border-black bg-black text-white font-mono font-bold text-[10px] shadow-[2px_2px_0_#FDE047]"
		BANano.Await(dowCell.AddComponent)
		BANano.Await(AddText("dowT" & i, "dow" & i, dows.Get(i), "span", "xs", "bold", "block", "#FFFFFF"))
	Next

	' Calendar Weeks (October 2026 starts Thursday)
	Dim calGrid As SDUI5Container
	calGrid.Initialize(Me, "calGrid", "calGrid")
	calGrid.ParentID = "contentWrapper"
	calGrid.Container = False
	calGrid.Classes = "grid grid-cols-7 gap-1 mt-1"
	BANano.Await(calGrid.AddComponent)

	BANano.Await(AddDayCells("calGrid", Array("", "", "", "1", "2", "3", "4")))
	BANano.Await(AddDayCells("calGrid", Array("5", "6", "7", "8", "9", "10", "11")))
	BANano.Await(AddDayCells("calGrid", Array("12", "13", "14", "15", "16", "17", "18")))
	BANano.Await(AddDayCells("calGrid", Array("19", "20", "21", "22", "23", "24", "25")))
	BANano.Await(AddDayCells("calGrid", Array("26", "27", "28", "29", "30", "31", "")))

	' Upcoming Sticky Note Tasks Section
	Dim taskSec As SDUI5Container
	taskSec.Initialize(Me, "taskSec", "taskSec")
	taskSec.ParentID = "contentWrapper"
	taskSec.Container = False
	taskSec.Classes = "mt-4 flex flex-col gap-2"
	BANano.Await(taskSec.AddComponent)

	Dim taskHead As SDUI5Container
	taskHead.Initialize(Me, "taskHead", "taskHead")
	taskHead.ParentID = "taskSec"
	taskHead.Container = False
	taskHead.Classes = "flex justify-between items-center"
	BANano.Await(taskHead.AddComponent)

	BANano.Await(AddText("taskHeadTitle", "taskHead", "UPCOMING STICKY TASKS", "h2", "xs", "black", "font-mono font-bold uppercase tracking-wider text-black", "#000000"))

	Dim countTag As SDUI5Badge
	countTag.Initialize(Me, "countTag", "countTag")
	countTag.ParentID = "taskHead"
	countTag.Text = "4 DUE"
	countTag.Classes = "badge-xs rounded-none border border-black bg-black text-white font-mono"
	BANano.Await(countTag.AddComponent)

	BANano.Await(AddStickyNote("note1", "taskSec", "14 OCT // 10:30", "Dentist of Doom Checkup", "bg-[#FDE047] -rotate-1", "URGENT"))
	BANano.Await(AddStickyNote("note2", "taskSec", "18 OCT // 14:00", "Ship It Saturday Release", "bg-[#A7F3D0] rotate-1", "DEPLOY"))
	BANano.Await(AddStickyNote("note3", "taskSec", "25 OCT // 20:00", "Brutal Birthday Bash", "bg-[#FBCFE8] -rotate-1", "PARTY"))
	BANano.Await(AddStickyNote("note4", "taskSec", "31 OCT // 23:59", "Midnight Pumpkin Hackathon", "bg-[#DDD6FE] rotate-1", "HACK"))

	' Month Navigation Row
	Dim navRow As SDUI5Container
	navRow.Initialize(Me, "navRowC", "navRowC")
	navRow.ParentID = "contentWrapper"
	navRow.Container = False
	navRow.Classes = "grid grid-cols-2 gap-2 mt-4"
	BANano.Await(navRow.AddComponent)

	Dim prevBtn As SDUI5Button
	prevBtn.Initialize(Me, "monthPrev", "monthPrev")
	prevBtn.ParentID = "navRowC"
	prevBtn.Text = "< PREV MONTH"
	prevBtn.Classes = "rounded-none border-2 border-black bg-white text-black font-mono font-bold text-xs py-2 shadow-[2px_2px_0_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(prevBtn.AddComponent)

	Dim nextBtn As SDUI5Button
	nextBtn.Initialize(Me, "monthNext", "monthNext")
	nextBtn.ParentID = "navRowC"
	nextBtn.Text = "NEXT MONTH >"
	nextBtn.Classes = "rounded-none border-2 border-black bg-[#FDE047] text-black font-mono font-bold text-xs py-2 shadow-[2px_2px_0_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(nextBtn.AddComponent)
End Sub

Private Sub RenderSkeletonView
	Dim skelGrid As SDUI5Skeleton
	skelGrid.Initialize(Me, "skelGrid", "skelGrid")
	skelGrid.ParentID = "contentWrapper"
	skelGrid.Classes = "w-full h-44 rounded-none border-2 border-black bg-neutral-200"
	BANano.Await(skelGrid.AddComponent)

	Dim skelTasks As SDUI5Skeleton
	skelTasks.Initialize(Me, "skelTasks", "skelTasks")
	skelTasks.ParentID = "contentWrapper"
	skelTasks.Classes = "w-full h-48 rounded-none border-2 border-black bg-neutral-200 mt-4"
	BANano.Await(skelTasks.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto border-4 border-black bg-white shadow-[6px_6px_0_#000000] text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "ZERO SCHEDULE CONFLICTS"
	empTitle.Classes = "text-xl font-black uppercase text-black"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "All sticky notes cleared for this cycle. Slap on a new task or enjoy free time."
	empMsg.Classes = "text-xs font-mono text-neutral-600 mt-2 max-w-xs"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "+ SLAP STICKY NOTE"
	empCta.Classes = "mt-5 rounded-none border-3 border-black bg-[#FDE047] text-black font-black text-xs px-6 py-2.5 shadow-[4px_4px_0_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto border-4 border-black bg-[#FCA5A5] shadow-[6px_6px_0_#000000] text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "SCHEDULE COLLISION"
	errTitle.Classes = "text-xl font-black uppercase text-black"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Double booking conflict detected on Oct 14 at 10:30. Reschedule lower priority note."
	errMsg.Classes = "text-xs font-mono font-bold text-black mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "RESOLVE COLLISION"
	errCta.Classes = "mt-5 rounded-none border-3 border-black bg-black text-white font-black text-xs px-6 py-2.5 shadow-[4px_4px_0_#000000] active:translate-x-0.5 active:translate-y-0.5"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddDayCells(parentId As String, days As List)
	For i = 0 To days.Size - 1
		Dim dayStr As String = days.Get(i)
		Dim dCell As SDUI5Container
		dCell.Initialize(Me, "day_" & dayStr & "_" & DateTime.Now, "day_" & dayStr & "_" & DateTime.Now)
		dCell.ParentID = parentId
		dCell.Container = False
		If dayStr = "" Then
			dCell.Classes = "h-8 border border-dashed border-neutral-300 bg-white/40"
		Else If dayStr = "14" Then
			dCell.Classes = "h-8 border-2 border-black bg-[#FDE047] font-black text-black flex items-center justify-center text-xs shadow-[2px_2px_0_#000000]"
		Else If dayStr = "18" Or dayStr = "25" Or dayStr = "31" Then
			dCell.Classes = "h-8 border-2 border-black bg-[#FBCFE8] font-bold text-black flex items-center justify-center text-xs shadow-[1.5px_1.5px_0_#000000]"
		Else
			dCell.Classes = "h-8 border border-black bg-white font-semibold text-black flex items-center justify-center text-xs hover:bg-neutral-100 cursor-pointer"
		End If
		BANano.Await(dCell.AddComponent)
		If dayStr <> "" Then
			BANano.Await(AddText("dt_" & dayStr, dCell.ID, dayStr, "span", "xs", "bold", "", "#000000"))
		End If
	Next
End Sub

Private Sub AddStickyNote(id As String, parentId As String, timeSlot As String, taskName As String, extraClasses As String, tagText As String)
	Dim note As SDUI5Container
	note.Initialize(Me, id, id)
	note.ParentID = parentId
	note.Container = False
	note.Classes = "p-3 border-2 border-black shadow-[3px_3px_0_#000000] flex items-center justify-between " & extraClasses
	BANano.Await(note.AddComponent)

	Dim noteText As SDUI5Container
	noteText.Initialize(Me, id & "Text", id & "Text")
	noteText.ParentID = id
	noteText.Container = False
	noteText.Classes = "flex flex-col"
	BANano.Await(noteText.AddComponent)

	BANano.Await(AddText(id & "Time", id & "Text", timeSlot, "p", "xs", "bold", "font-mono text-black text-[10px]", "#000000"))
	BANano.Await(AddText(id & "Name", id & "Text", taskName, "h3", "xs", "black", "font-bold text-black mt-0.5", "#000000"))

	Dim tag As SDUI5Badge
	tag.Initialize(Me, id & "Tag", id & "Tag")
	tag.ParentID = id
	tag.Text = tagText
	tag.Classes = "badge-xs rounded-none border border-black bg-black text-white font-mono font-bold"
	BANano.Await(tag.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Added note: Buy grok fuel", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Shifted Dentist of Doom to 14:00", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub monthPrev_Click(e As BANanoEvent)
	e.PreventDefault
	currentMonth = "SEPTEMBER 2026"
	BANano.Await(Show)
End Sub

Private Sub monthNext_Click(e As BANanoEvent)
	e.PreventDefault
	currentMonth = "NOVEMBER 2026"
	BANano.Await(Show)
End Sub
