﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  Swiss minimal stopwatch.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private timeText As SDUI5Text 'ignore
	Private startBtn As SDUI5Button 'ignore
	Private stopBtn As SDUI5Button 'ignore
	Private isTiming As Boolean = True
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with crisp Swiss background
	Dim page As SDUI5Container
	page.Initialize(Me, "watchPage", "watchPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-2xl border border-neutral-300 bg-[#FAFAF8] text-[#111111] font-['Space_Grotesk',sans-serif] px-6 py-7 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top Swiss Mathematical Grid Header
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBar", "topBar")
	topBar.ParentID = "watchPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between border-b border-neutral-300 pb-3"
	BANano.Await(topBar.AddComponent)

	Dim swissTitle As SDUI5Text
	swissTitle.Initialize(Me, "swissTitle", "swissTitle")
	swissTitle.ParentID = "topBar"
	swissTitle.TextTag = "span"
	swissTitle.Text = "CHRONOMETER // 03"
	swissTitle.Classes = "font-black tracking-widest text-xs uppercase text-[#111111]"
	BANano.Await(swissTitle.AddComponent)

	Dim swissBadge As SDUI5Badge
	swissBadge.Initialize(Me, "swissBadge", "swissBadge")
	swissBadge.ParentID = "topBar"
	swissBadge.Text = "+ SWISS CALIBRE"
	swissBadge.Classes = "badge-sm rounded-none bg-[#D90429] text-white font-black text-[10px] tracking-wider border-none"
	BANano.Await(swissBadge.AddComponent)

	' State Switcher Deck
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "watchPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-4"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white text-neutral-800"
	Dim skelStyle As String = "bg-white text-neutral-800"
	Dim empStyle As String = "bg-white text-neutral-800"
	Dim errStyle As String = "bg-white text-neutral-800"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-[#111111] text-white font-bold"
	Else If currentViewState = "empty" Then
		empStyle = "bg-[#111111] text-white font-bold"
	Else If currentViewState = "error" Then
		errStyle = "bg-[#111111] text-white font-bold"
	Else
		popStyle = "bg-[#111111] text-white font-bold"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "TIMING", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "CALIBRATE", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "READY", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "FAULT", errStyle))

	' Content Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "watchPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-4"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	BANano.Await(AddText("sampleNote", "watchPage", "Certified Chronometer Standard | DIN 8306 Specification", "p", "xs", "normal", "text-center text-neutral-400 mt-4", "#9CA3AF"))
	pgIndex.UpdateTitle("Swiss Stopwatch | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-none border border-neutral-300 font-mono text-[10px] " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Monolithic Chrono Readout Box
	Dim dialBox As SDUI5Container
	dialBox.Initialize(Me, "dialBox", "dialBox")
	dialBox.ParentID = "contentWrapper"
	dialBox.Container = False
	dialBox.Classes = "py-6 text-center border-y border-neutral-300 my-2"
	BANano.Await(dialBox.AddComponent)

	BANano.Await(AddText("subLabel", "dialBox", "SPLIT INTERVAL // 1/100S", "p", "xs", "bold", "tracking-widest text-neutral-500 font-mono", "#6B7280"))

	timeText.Initialize(Me, "timeText", "timeText")
	timeText.ParentID = "dialBox"
	timeText.TextTag = "h1"
	timeText.Text = "12:34.56"
	timeText.Classes = "text-5xl font-extrabold font-['JetBrains_Mono',monospace] tracking-tighter text-[#111111] mt-1 tabular-nums"
	BANano.Await(timeText.AddComponent)

	BANano.Await(AddText("sessionMeta", "dialBox", "SESSION 03 - 4 LAPS LOGGED", "p", "xs", "semibold", "text-neutral-500 font-mono mt-1", "#6B7280"))

	' Dual Monolithic Action Blocks
	Dim btnRow As SDUI5Container
	btnRow.Initialize(Me, "btnRow", "btnRow")
	btnRow.ParentID = "contentWrapper"
	btnRow.Container = False
	btnRow.Classes = "grid grid-cols-2 gap-3 my-4"
	BANano.Await(btnRow.AddComponent)

	stopBtn.Initialize(Me, "stopBtn", "stopBtn")
	stopBtn.ParentID = "btnRow"
	stopBtn.Text = "SPLIT / LAP"
	stopBtn.Classes = "w-full rounded-none border border-black bg-[#111111] text-white font-mono font-bold text-xs py-3.5 tracking-wider active:bg-neutral-800"
	BANano.Await(stopBtn.AddComponent)

	startBtn.Initialize(Me, "startBtn", "startBtn")
	startBtn.ParentID = "btnRow"
	If isTiming Then
		startBtn.Text = "HALT [STOP]"
		startBtn.Classes = "w-full rounded-none border border-[#D90429] bg-[#D90429] text-white font-mono font-bold text-xs py-3.5 tracking-wider active:bg-red-800"
	Else
		startBtn.Text = "RESUME"
		startBtn.Classes = "w-full rounded-none border border-emerald-600 bg-emerald-600 text-white font-mono font-bold text-xs py-3.5 tracking-wider active:bg-emerald-800"
	End If
	BANano.Await(startBtn.AddComponent)

	' Swiss Precision Lap Table
	Dim lapSec As SDUI5Container
	lapSec.Initialize(Me, "lapSec", "lapSec")
	lapSec.ParentID = "contentWrapper"
	lapSec.Container = False
	lapSec.Classes = "mt-2"
	BANano.Await(lapSec.AddComponent)

	Dim lapHead As SDUI5Container
	lapHead.Initialize(Me, "lapHead", "lapHead")
	lapHead.ParentID = "lapSec"
	lapHead.Container = False
	lapHead.Classes = "flex justify-between items-center pb-1 border-b border-neutral-300 font-mono text-[11px] text-neutral-500 font-bold uppercase"
	BANano.Await(lapHead.AddComponent)

	BANano.Await(AddText("lhLap", "lapHead", "SPLIT ID", "span", "xs", "bold", "", "#6B7280"))
	BANano.Await(AddText("lhTime", "lapHead", "SPLIT TIME", "span", "xs", "bold", "", "#6B7280"))
	BANano.Await(AddText("lhDelta", "lapHead", "DELTA", "span", "xs", "bold", "", "#6B7280"))

	Dim lapList As SDUI5List
	lapList.Initialize(Me, "lapList", "lapList")
	lapList.ParentID = "lapSec"
	lapList.Classes = "divide-y divide-neutral-200 bg-white border border-neutral-200"
	BANano.Await(lapList.AddComponent)

	BANano.Await(AddLapRow("lap4", "lapList", "LAP 04", "02:52.99", "BEST", True))
	BANano.Await(AddLapRow("lap3", "lapList", "LAP 03", "03:21.02", "+28.03s", False))
	BANano.Await(AddLapRow("lap2", "lapList", "LAP 02", "03:08.15", "+15.16s", False))
	BANano.Await(AddLapRow("lap1", "lapList", "LAP 01", "03:12.40", "+19.41s", False))
End Sub

Private Sub RenderSkeletonView
	Dim skelDial As SDUI5Skeleton
	skelDial.Initialize(Me, "skelDial", "skelDial")
	skelDial.ParentID = "contentWrapper"
	skelDial.Classes = "w-full h-32 rounded-none bg-neutral-200 border border-neutral-300 my-2"
	BANano.Await(skelDial.AddComponent)

	Dim skelBtns As SDUI5Skeleton
	skelBtns.Initialize(Me, "skelBtns", "skelBtns")
	skelBtns.ParentID = "contentWrapper"
	skelBtns.Classes = "w-full h-12 rounded-none bg-neutral-200 my-4"
	BANano.Await(skelBtns.AddComponent)

	Dim skelTable As SDUI5Skeleton
	skelTable.Initialize(Me, "skelTable", "skelTable")
	skelTable.ParentID = "contentWrapper"
	skelTable.Classes = "w-full h-44 rounded-none bg-neutral-200 border border-neutral-300 mt-2"
	BANano.Await(skelTable.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto border border-neutral-300 bg-white text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "CHRONOGRAPH STANDBY"
	empTitle.Classes = "text-xl font-bold uppercase tracking-wider text-[#111111]"
	BANano.Await(empTitle.AddComponent)

	Dim empZero As SDUI5Text
	empZero.Initialize(Me, "empZero", "empZero")
	empZero.ParentID = "emptyCard"
	empZero.TextTag = "div"
	empZero.Text = "00:00.00"
	empZero.Classes = "text-3xl font-extrabold font-['JetBrains_Mono',monospace] text-neutral-400 my-3"
	BANano.Await(empZero.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "No active split intervals recorded. System calibrated and primed."
	empMsg.Classes = "text-xs font-mono text-neutral-500 max-w-xs"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "START TIMING"
	empCta.Classes = "mt-5 rounded-none border border-[#D90429] bg-[#D90429] text-white font-mono font-bold text-xs px-6 py-3 tracking-widest active:bg-red-800"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto border-2 border-[#D90429] bg-white text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "QUARTZ OSCILLATOR DRIFT"
	errTitle.Classes = "text-xl font-bold uppercase text-[#D90429]"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Timekeeping discrepancy detected (+0.042 ms). Re-synchronize with official atomic clock standard."
	errMsg.Classes = "text-xs font-mono text-neutral-600 mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "RE-CALIBRATE OSCILLATOR"
	errCta.Classes = "mt-5 rounded-none border border-black bg-black text-white font-mono font-bold text-xs px-6 py-3 tracking-widest active:bg-neutral-800"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddLapRow(id As String, parentId As String, lapName As String, splitTime As String, deltaText As String, isBest As Boolean)
	Dim item As SDUI5ListItem
	item.Initialize(Me, id, id)
	item.ParentID = parentId
	item.Text = lapName & "    " & splitTime & "    " & deltaText
	If isBest Then
		item.Classes = "p-3 font-mono text-xs font-bold text-[#D90429] bg-red-50/50"
	Else
		item.Classes = "p-3 font-mono text-xs font-medium text-neutral-800 hover:bg-neutral-50"
	End If
	BANano.Await(item.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Chronometer engaged at 00:00.00", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Atomic time re-calibrated (0.000 ms jitter)", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub startBtn_Click(e As BANanoEvent)
	e.PreventDefault
	isTiming = Not(isTiming)
	If isTiming Then
		startBtn.Text = "HALT [STOP]"
		startBtn.Classes = "w-full rounded-none border border-[#D90429] bg-[#D90429] text-white font-mono font-bold text-xs py-3.5 tracking-wider active:bg-red-800"
		app.ShowSwalSuccessToast("Timing active", 1500)
	Else
		startBtn.Text = "RESUME"
		startBtn.Classes = "w-full rounded-none border border-emerald-600 bg-emerald-600 text-white font-mono font-bold text-xs py-3.5 tracking-wider active:bg-emerald-800"
		app.ShowSwalInfoToast("Chronograph halted at 12:34.56", 1500)
	End If
End Sub

Private Sub stopBtn_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Split 05 logged: 03:04.12", 1500)
End Sub
