﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module  -  Y2K glossy banking home.
Sub Process_Globals
	Private BANano As BANano 'ignore
	Private app As SDUI5App 'ignore
	Private currentViewState As String = "populated"
End Sub

Sub Show
	app = pgIndex.App
	BANano.Await(app.ClearPageView)

	' Desktop Phone Chassis containment with Y2K liquid pastel gradient
	Dim page As SDUI5Container
	page.Initialize(Me, "bankPage", "bankPage")
	page.ParentID = app.PageView
	page.Container = False
	page.Classes = "min-h-screen w-full sm:max-w-md sm:mx-auto sm:my-3 sm:rounded-[36px] sm:shadow-[0_25px_60px_-15px_rgba(124,58,237,0.3)] bg-gradient-to-b from-[#C9F2FF] via-[#E8E6FF] to-[#FFE9F6] text-slate-800 font-['Plus_Jakarta_Sans',sans-serif] px-5 py-6 flex flex-col justify-between"
	BANano.Await(page.AddComponent)

	' Top App Bar with Y2K Badge
	Dim topBar As SDUI5Container
	topBar.Initialize(Me, "topBar", "topBar")
	topBar.ParentID = "bankPage"
	topBar.Container = False
	topBar.Classes = "flex items-center justify-between"
	BANano.Await(topBar.AddComponent)

	Dim userMeta As SDUI5Container
	userMeta.Initialize(Me, "userMeta", "userMeta")
	userMeta.ParentID = "topBar"
	userMeta.Container = False
	userMeta.Classes = "flex flex-col"
	BANano.Await(userMeta.AddComponent)

	BANano.Await(AddText("bankEyebrow", "userMeta", "NEON VAULT // Y2K EDITION", "p", "xs", "bold", "tracking-widest uppercase text-purple-700", "#7C3AED"))
	BANano.Await(AddText("bankHello", "userMeta", "Hey, Starr!", "h1", "2xl", "extrabold", "tracking-tight text-slate-900 mt-0.5", "#0F172A"))

	Dim statusBadge As SDUI5Badge
	statusBadge.Initialize(Me, "statusBadge", "statusBadge")
	statusBadge.ParentID = "topBar"
	statusBadge.Text = "PLATINUM 2000"
	statusBadge.Classes = "badge-sm rounded-full bg-white/90 backdrop-blur-md text-purple-700 font-black border border-purple-200 shadow-sm"
	BANano.Await(statusBadge.AddComponent)

	' State Switcher Deck
	Dim stateBar As SDUI5Container
	stateBar.Initialize(Me, "stateBar", "stateBar")
	stateBar.ParentID = "bankPage"
	stateBar.Container = False
	stateBar.Classes = "grid grid-cols-4 gap-1.5 mt-4"
	BANano.Await(stateBar.AddComponent)

	Dim popStyle As String = "bg-white/70 text-purple-900"
	Dim skelStyle As String = "bg-white/70 text-purple-900"
	Dim empStyle As String = "bg-white/70 text-purple-900"
	Dim errStyle As String = "bg-white/70 text-purple-900"

	If currentViewState = "skeleton" Then
		skelStyle = "bg-purple-700 text-white shadow-md"
	Else If currentViewState = "empty" Then
		empStyle = "bg-purple-700 text-white shadow-md"
	Else If currentViewState = "error" Then
		errStyle = "bg-purple-700 text-white shadow-md"
	Else
		popStyle = "bg-purple-700 text-white shadow-md"
	End If

	BANano.Await(AddStateBtn("btnStPop", "stateBar", "VAULT", popStyle))
	BANano.Await(AddStateBtn("btnStSkel", "stateBar", "SYNCING", skelStyle))
	BANano.Await(AddStateBtn("btnStEmpty", "stateBar", "EMPTY", empStyle))
	BANano.Await(AddStateBtn("btnStErr", "stateBar", "FROZEN", errStyle))

	' Dynamic View Container
	Dim contentWrapper As SDUI5Container
	contentWrapper.Initialize(Me, "contentWrapper", "contentWrapper")
	contentWrapper.ParentID = "bankPage"
	contentWrapper.Container = False
	contentWrapper.Classes = "flex-1 flex flex-col justify-between mt-4"
	BANano.Await(contentWrapper.AddComponent)

	Select Case currentViewState
		Case "skeleton"
			BANano.Await(RenderSkeletonView)
		Case "empty"
			BANano.Await(RenderEmptyView)
		Case "error"
			BANano.Await(RenderErrorView)
		Case Else
			BANano.Await(RenderPopulatedView)
	End Select

	' Liquid Bottom Dock
	Dim dock As SDUI5Dock
	dock.Initialize(Me, "bankDock", "bankDock")
	dock.ParentID = "bankPage"
	dock.Size = "md"
	dock.Classes = "rounded-3xl bg-white/80 backdrop-blur-xl border border-white/80 shadow-lg mt-4"
	BANano.Await(dock.AddComponent)

	BANano.Await(AddDockBtn("dockHome", "bankDock", "Home", "primary"))
	BANano.Await(AddDockBtn("dockCards", "bankDock", "Cards", "neutral"))
	BANano.Await(AddDockBtn("dockStats", "bankDock", "Stats", "neutral"))

	pgIndex.UpdateTitle("Neon Vault Banking | SithasoDaisy5")
End Sub

Private Sub AddStateBtn(id As String, parentId As String, text As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = text
	b.Classes = "btn-xs rounded-xl font-bold text-[10px] border-none backdrop-blur-md " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub RenderPopulatedView
	' Glossy Holographic Balance Hero Card
	Dim balCard As SDUI5Container
	balCard.Initialize(Me, "balCard", "balCard")
	balCard.ParentID = "contentWrapper"
	balCard.Container = False
	balCard.Classes = "rounded-[32px] p-6 bg-gradient-to-tr from-[#7C3AED] via-[#9333EA] to-[#EC4899] text-white shadow-xl shadow-purple-500/25 border-2 border-white/60 relative overflow-hidden"
	BANano.Await(balCard.AddComponent)

	BANano.Await(AddText("balTitle", "balCard", "TOTAL VAULT BALANCE", "p", "xs", "bold", "tracking-wider text-purple-200", "#E9D5FF"))
	BANano.Await(AddText("balAmount", "balCard", "$12,480.90", "h2", "3xl", "black", "font-['Space_Grotesk'] text-white mt-1 tracking-tight", "#FFFFFF"))

	Dim balMeta As SDUI5Container
	balMeta.Initialize(Me, "balMeta", "balMeta")
	balMeta.ParentID = "balCard"
	balMeta.Container = False
	balMeta.Classes = "flex items-center gap-2 mt-3"
	BANano.Await(balMeta.AddComponent)

	Dim gainBadge As SDUI5Badge
	gainBadge.Initialize(Me, "gainBadge", "gainBadge")
	gainBadge.ParentID = "balMeta"
	gainBadge.Text = "+$214.10 this week"
	gainBadge.Classes = "badge-sm rounded-full bg-emerald-400 text-emerald-950 font-bold border-none"
	BANano.Await(gainBadge.AddComponent)

	Dim acctsPill As SDUI5Badge
	acctsPill.Initialize(Me, "acctsPill", "acctsPill")
	acctsPill.ParentID = "balMeta"
	acctsPill.Text = "3 ACCOUNTS"
	acctsPill.Classes = "badge-sm rounded-full bg-white/20 text-white font-bold border-none"
	BANano.Await(acctsPill.AddComponent)

	' Swipeable Holographic Cards Carousel
	Dim carSec As SDUI5Container
	carSec.Initialize(Me, "carSec", "carSec")
	carSec.ParentID = "contentWrapper"
	carSec.Container = False
	carSec.Classes = "mt-4"
	BANano.Await(carSec.AddComponent)

	Dim carHead As SDUI5Container
	carHead.Initialize(Me, "carHead", "carHead")
	carHead.ParentID = "carSec"
	carHead.Container = False
	carHead.Classes = "flex items-center justify-between mb-2"
	BANano.Await(carHead.AddComponent)

	BANano.Await(AddText("carouselTitle", "carHead", "Holographic Cards", "h2", "sm", "bold", "text-slate-800", "#1E293B"))
	BANano.Await(AddText("carouselSub", "carHead", "Swipe >", "p", "xs", "bold", "text-purple-600 font-mono", "#9333EA"))

	Dim carousel As SDUI5Carousel
	carousel.Initialize(Me, "cardsCarousel", "cardsCarousel")
	carousel.ParentID = "carSec"
	carousel.Height = "165px"
	carousel.Width = "100%"
	carousel.Rounded = "3xl"
	carousel.RoundedBox = True
	carousel.SpaceX = "3"
	carousel.Classes = "max-w-full overflow-x-auto"
	BANano.Await(carousel.AddComponent)

	BANano.Await(AddCarouselCard("slide1", "cardsCarousel", "STAR SAVINGS", "**** 4401", "$8,210.00", "bg-gradient-to-tr from-cyan-400 to-indigo-500"))
	BANano.Await(AddCarouselCard("slide2", "cardsCarousel", "DAILY CHECKING", "**** 8817", "$3,102.55", "bg-gradient-to-tr from-pink-500 to-amber-400"))
	BANano.Await(AddCarouselCard("slide3", "cardsCarousel", "CRYPTO POCKET", "**** 0099", "$1,168.35", "bg-gradient-to-tr from-emerald-400 to-teal-500"))

	' Jelly Quick Action Buttons
	Dim actions As SDUI5Container
	actions.Initialize(Me, "quickActions", "quickActions")
	actions.ParentID = "contentWrapper"
	actions.Container = False
	actions.Classes = "grid grid-cols-4 gap-2 mt-4"
	BANano.Await(actions.AddComponent)

	BANano.Await(AddAction("quickSend", "quickActions", "Send", "bg-indigo-600 text-white"))
	BANano.Await(AddAction("quickTopup", "quickActions", "Top Up", "bg-pink-500 text-white"))
	BANano.Await(AddAction("quickPay", "quickActions", "Pay", "bg-cyan-500 text-white"))
	BANano.Await(AddAction("quickMore", "quickActions", "More", "bg-purple-600 text-white"))

	' Recent Activity List with Frosted Glass
	Dim actSec As SDUI5Container
	actSec.Initialize(Me, "actSec", "actSec")
	actSec.ParentID = "contentWrapper"
	actSec.Container = False
	actSec.Classes = "mt-4"
	BANano.Await(actSec.AddComponent)

	BANano.Await(AddText("txTitle", "actSec", "Recent Activity", "h2", "sm", "bold", "text-slate-800 mb-2", "#1E293B"))

	Dim tx As SDUI5List
	tx.Initialize(Me, "txList", "txList")
	tx.ParentID = "actSec"
	tx.Classes = "rounded-[24px] bg-white/70 backdrop-blur-md border border-white/80 shadow-sm divide-y divide-purple-50"
	BANano.Await(tx.AddComponent)

	BANano.Await(AddTx("tx1", "txList", "Bubble Tea Studio", "-$6.80", "Food & Drink"))
	BANano.Await(AddTx("tx2", "txList", "Bi-Weekly Payday", "+$2,400.00", "Direct Deposit"))
	BANano.Await(AddTx("tx3", "txList", "Transfer to Milo", "-$45.00", "Peer-to-Peer"))
	BANano.Await(AddTx("tx4", "txList", "Cyber Sticker Market", "-$12.25", "Merchandise"))
End Sub

Private Sub RenderSkeletonView
	Dim skelHero As SDUI5Skeleton
	skelHero.Initialize(Me, "skelHero", "skelHero")
	skelHero.ParentID = "contentWrapper"
	skelHero.Classes = "w-full h-36 rounded-[32px] bg-white/60 backdrop-blur-md"
	BANano.Await(skelHero.AddComponent)

	Dim skelCar As SDUI5Skeleton
	skelCar.Initialize(Me, "skelCar", "skelCar")
	skelCar.ParentID = "contentWrapper"
	skelCar.Classes = "w-full h-40 rounded-[28px] bg-white/60 backdrop-blur-md mt-4"
	BANano.Await(skelCar.AddComponent)

	Dim skelAct As SDUI5Skeleton
	skelAct.Initialize(Me, "skelAct", "skelAct")
	skelAct.ParentID = "contentWrapper"
	skelAct.Classes = "w-full h-48 rounded-[24px] bg-white/60 backdrop-blur-md mt-4"
	BANano.Await(skelAct.AddComponent)
End Sub

Private Sub RenderEmptyView
	Dim emptyCard As SDUI5Container
	emptyCard.Initialize(Me, "emptyCard", "emptyCard")
	emptyCard.ParentID = "contentWrapper"
	emptyCard.Container = False
	emptyCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-white/80 backdrop-blur-xl border border-white shadow-xl text-center"
	BANano.Await(emptyCard.AddComponent)

	Dim empTitle As SDUI5Text
	empTitle.Initialize(Me, "empTitle", "empTitle")
	empTitle.ParentID = "emptyCard"
	empTitle.TextTag = "h2"
	empTitle.Text = "NO HOLOGRAPHIC CARDS"
	empTitle.Classes = "text-xl font-black text-purple-900"
	BANano.Await(empTitle.AddComponent)

	Dim empMsg As SDUI5Text
	empMsg.Initialize(Me, "empMsg", "empMsg")
	empMsg.ParentID = "emptyCard"
	empMsg.TextTag = "p"
	empMsg.Text = "Your digital vault currently has no active accounts linked. Issue a customized holographic debit card."
	empMsg.Classes = "text-xs font-medium text-slate-600 mt-2 max-w-xs leading-relaxed"
	BANano.Await(empMsg.AddComponent)

	Dim empCta As SDUI5Button
	empCta.Initialize(Me, "empCta", "empCta")
	empCta.ParentID = "emptyCard"
	empCta.Text = "+ ISSUE HOLOGRAPHIC CARD"
	empCta.Classes = "mt-5 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white font-extrabold text-xs px-6 py-3 shadow-lg shadow-purple-500/30 border-none"
	BANano.Await(empCta.AddComponent)
End Sub

Private Sub RenderErrorView
	Dim errCard As SDUI5Container
	errCard.Initialize(Me, "errCard", "errCard")
	errCard.ParentID = "contentWrapper"
	errCard.Container = False
	errCard.Classes = "flex flex-col items-center justify-center p-8 my-auto rounded-[32px] bg-red-50/90 backdrop-blur-xl border border-red-200 shadow-xl text-center"
	BANano.Await(errCard.AddComponent)

	Dim errTitle As SDUI5Text
	errTitle.Initialize(Me, "errTitle", "errTitle")
	errTitle.ParentID = "errCard"
	errTitle.TextTag = "h2"
	errTitle.Text = "VAULT LOCKDOWN"
	errTitle.Classes = "text-xl font-black text-red-900"
	BANano.Await(errTitle.AddComponent)

	Dim errMsg As SDUI5Text
	errMsg.Initialize(Me, "errMsg", "errMsg")
	errMsg.ParentID = "errCard"
	errMsg.TextTag = "p"
	errMsg.Text = "Security cipher mismatch (Error 0xY2K). Biometric handshake required to unlock funds."
	errMsg.Classes = "text-xs font-medium text-red-600 mt-2 max-w-xs"
	BANano.Await(errMsg.AddComponent)

	Dim errCta As SDUI5Button
	errCta.Initialize(Me, "errCta", "errCta")
	errCta.ParentID = "errCard"
	errCta.Text = "VERIFY BIOMETRICS"
	errCta.Classes = "mt-5 rounded-full bg-red-600 text-white font-extrabold text-xs px-6 py-3 shadow-lg shadow-red-500/30 border-none"
	BANano.Await(errCta.AddComponent)
End Sub

Private Sub AddCarouselCard(id As String, parentId As String, name As String, number As String, amount As String, gradientClass As String)
	Dim item As SDUI5CarouselItem
	item.Initialize(Me, id, id)
	item.ParentID = parentId
	item.TypeOf = "custom"
	BANano.Await(item.AddComponent)

	Dim body As SDUI5Container
	body.Initialize(Me, id & "Body", id & "Body")
	body.ParentID = id
	body.Container = False
	body.Classes = "rounded-[24px] p-4 w-60 h-36 flex flex-col justify-between text-white border-2 border-white/50 shadow-md " & gradientClass
	BANano.Await(body.AddComponent)

	Dim cTop As SDUI5Container
	cTop.Initialize(Me, id & "Top", id & "Top")
	cTop.ParentID = id & "Body"
	cTop.Container = False
	cTop.Classes = "flex justify-between items-center"
	BANano.Await(cTop.AddComponent)

	BANano.Await(AddText(id & "Name", id & "Top", name, "p", "xs", "bold", "tracking-wider", "#FFFFFF"))
	BANano.Await(AddText(id & "Chip", id & "Top", "[CHIP]", "span", "xs", "bold", "font-mono opacity-80", "#FFFFFF"))

	BANano.Await(AddText(id & "Amt", id & "Body", amount, "h3", "2xl", "extrabold", "font-['Space_Grotesk'] tracking-tight", "#FFFFFF"))
	BANano.Await(AddText(id & "Num", id & "Body", number, "p", "xs", "normal", "tracking-widest font-mono opacity-90", "#FFFFFF"))
End Sub

Private Sub AddAction(id As String, parentId As String, caption As String, extraClasses As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = caption
	b.Classes = "rounded-2xl font-bold text-xs py-3 shadow-md border-none " & extraClasses
	BANano.Await(b.AddComponent)
End Sub

Private Sub AddTx(id As String, parentId As String, title As String, amount As String, category As String)
	Dim li As SDUI5ListItem
	li.Initialize(Me, id, id)
	li.ParentID = parentId
	li.Text = title & " (" & category & ")  -  " & amount
	li.Classes = "p-3 font-semibold text-xs text-slate-800 hover:bg-white/50 cursor-pointer"
	BANano.Await(li.AddComponent)
End Sub

Private Sub AddDockBtn(id As String, parentId As String, caption As String, color As String)
	Dim b As SDUI5Button
	b.Initialize(Me, id, id)
	b.ParentID = parentId
	b.Text = caption
	b.Color = color
	b.DockItem = True
	BANano.Await(b.AddComponent)
End Sub

Private Sub AddText(id As String, parentId As String, value As String, tag As String, size As String, weight As String, classes As String, color As String)
	Dim label As SDUI5Text
	label.Initialize(Me, id, id)
	label.ParentID = parentId
	label.TextTag = tag
	label.Text = value
	label.TextSize = size
	label.FontWeight = weight
	label.TextColor = color
	label.Classes = classes
	BANano.Await(label.AddComponent)
End Sub

' Event Handlers
Private Sub btnStPop_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "populated"
	Show
End Sub

Private Sub btnStSkel_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "skeleton"
	Show
End Sub

Private Sub btnStEmpty_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "empty"
	Show
End Sub

Private Sub btnStErr_Click(e As BANanoEvent)
	e.PreventDefault
	currentViewState = "error"
	Show
End Sub

Private Sub empCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Holographic card issued to your wallet", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub errCta_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Biometric verification verified: Starr", 2000)
	currentViewState = "populated"
	Show
End Sub

Private Sub quickSend_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Opened Neon Send transfer pad", 1500)
End Sub

Private Sub quickTopup_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Added $100.00 to Star Savings", 1500)
End Sub

Private Sub quickPay_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalSuccessToast("Contactless NFC payment ready", 1500)
End Sub

Private Sub quickMore_Click(e As BANanoEvent)
	e.PreventDefault
	app.ShowSwalInfoToast("More options: Statements, Limits, Virtual Cards", 1500)
End Sub
