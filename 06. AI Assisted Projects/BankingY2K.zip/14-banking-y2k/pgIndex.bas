﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
#IgnoreWarnings:12
Sub Process_Globals
	Public BANano As BANano 'ignore
	Public App As SDUI5App	'ignore
	Private pageView As SDUI5Container 'ignore
End Sub

Sub Initialize
	BANano.Await(App.Initialize(Me))
	App.RemoveClass("w-screen")
	App.AddClass("font-['Plus_Jakarta_Sans',sans-serif] antialiased min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 text-slate-800")
	pageView.Initialize(Me, "pageview", "pageview")
	pageView.ParentID = App.Here
	pageView.Container = False
	BANano.Await(pageView.AddComponent)
	BANano.Await(pgBanking.Show)
	App.pageresume
End Sub

Sub UpdateTitle(s As String)
	BANano.Window.SetField("document.title", s)
End Sub
