﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10
@EndOfDesignText@
#IgnoreWarnings:12
#DesignerProperty: Key: ReadMe, DisplayName: ReadMe, FieldType: String, DefaultValue: Child Item _title|_content, Description: Child Item _title|_content
#DesignerProperty: Key: ParentID, DisplayName: ParentID, FieldType: String, DefaultValue: , Description: The ParentID of this component
#DesignerProperty: Key: GroupName, DisplayName: Group Name, FieldType: String, DefaultValue: , Description: Group Name
#DesignerProperty: Key: Icon, DisplayName: Icon, FieldType: String, DefaultValue: , Description: Icon
#DesignerProperty: Key: IconColor, DisplayName: Icon Color, FieldType: String, DefaultValue: , Description: Icon Color
#DesignerProperty: Key: IconSize, DisplayName: Icon Size, FieldType: String, DefaultValue: 32px, Description: Icon Size
#DesignerProperty: Key: Title, DisplayName: Title, FieldType: String, DefaultValue: Collapse, Description: Title
#DesignerProperty: Key: TitleBackgroundColor, DisplayName: Title Background Color, FieldType: String, DefaultValue: , Description: Title Background Color
#DesignerProperty: Key: TitleTextColor, DisplayName: Title Text Color, FieldType: String, DefaultValue: , Description: Title Text Color
#DesignerProperty: Key: TitleClass, DisplayName: Title Class, FieldType: String, DefaultValue: font-semibold, Description: Title Class
#DesignerProperty: Key: RawContent, DisplayName: HTML Content, FieldType: String, DefaultValue: Collapse Content, Description: HTML Content
#DesignerProperty: Key: ContentBackgroundColor, DisplayName: Content Background Color, FieldType: String, DefaultValue: base-100, Description: Content Background Color
#DesignerProperty: Key: ContentTextColor, DisplayName: Content Text Color, FieldType: String, DefaultValue: , Description: Content Text Color
#DesignerProperty: Key: ContentTextSize, DisplayName: Content Text Size, FieldType: String, DefaultValue: sm, Description: Content Text Size, List: 2xl|3xl|4xl|5xl|6xl|7xl|8xl|9xl|base|lg|md|none|sm|xl|xs
#DesignerProperty: Key: ContentClass, DisplayName: Content Class, FieldType: String, DefaultValue: , Description: Content Class
#DesignerProperty: Key: Active, DisplayName: Active, FieldType: Boolean, DefaultValue: False, Description: Active
#DesignerProperty: Key: RightIcon, DisplayName: Right Icon, FieldType: String, DefaultValue: arrow, Description: Right Icon, List: arrow|plus
#DesignerProperty: Key: JoinItem, DisplayName: Join Item, FieldType: Boolean, DefaultValue: False, Description: Join Item
#DesignerProperty: Key: TextColor, DisplayName: Text Color, FieldType: String, DefaultValue: , Description: Text Color
#DesignerProperty: Key: BackgroundColor, DisplayName: Background Color, FieldType: String, DefaultValue: base-100, Description: Background Color
#DesignerProperty: Key: Border, DisplayName: Border, FieldType: Boolean, DefaultValue: True, Description: Border
#DesignerProperty: Key: BorderColor, DisplayName: Border Color, FieldType: String, DefaultValue: base-300, Description: Border Color
#DesignerProperty: Key: OpenClose, DisplayName: Open Close, FieldType: String, DefaultValue: none, Description: Open Close, List: close|none|open
#DesignerProperty: Key: Rounded, DisplayName: Rounded, FieldType: String, DefaultValue: none, Description: Rounded, List: 0|2xl|3xl|full|lg|md|none|rounded|sm|xl
#DesignerProperty: Key: Shadow, DisplayName: Shadow, FieldType: String, DefaultValue: none, Description: Shadow, List: 2xl|inner|lg|md|none|shadow|sm|xl
#DesignerProperty: Key: Visible, DisplayName: Visible, FieldType: Boolean, DefaultValue: True, Description: If visible.
#DesignerProperty: Key: Enabled, DisplayName: Enabled, FieldType: Boolean, DefaultValue: True, Description: If enabled.
#DesignerProperty: Key: PositionStyle, DisplayName: Position Style, FieldType: String, DefaultValue: none, Description: Position, List: absolute|fixed|none|relative|static|sticky
#DesignerProperty: Key: Position, DisplayName: Position Locations, FieldType: String, DefaultValue: t=?; b=?; r=?; l=?, Description: Position Locations
#DesignerProperty: Key: MarginAXYTBLR, DisplayName: Margins, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Margins A(all)-X(LR)-Y(TB)-T-B-L-R
#DesignerProperty: Key: PaddingAXYTBLR, DisplayName: Paddings, FieldType: String, DefaultValue: a=?; x=?; y=?; t=?; b=?; l=?; r=? , Description: Paddings A(all)-X(LR)-Y(TB)-T-B-L-R
#DesignerProperty: Key: RawClasses, DisplayName: Classes (;), FieldType: String, DefaultValue: , Description: Classes added to the HTML tag.
#DesignerProperty: Key: RawStyles, DisplayName: Styles (JSON), FieldType: String, DefaultValue: , Description: Styles added to the HTML tag. Must be a json String use = and ;
#DesignerProperty: Key: RawAttributes, DisplayName: Attributes (JSON), FieldType: String, DefaultValue: , Description: Attributes added to the HTML tag. Must be a json String use = and ;
'global variables in this module
Sub Class_Globals
	Public UI As UIShared 'ignore
	Public CustProps As Map 'ignore
	Private mCallBack As Object 'ignore
	Private mEventName As String 'ignore
	Private mElement As BANanoElement 'ignore
	Private mTarget As BANanoElement 'ignore
	Private mName As String 'ignore
	Private BANano As BANano   'ignore
	Private sPosition As String = "t=?; b=?; r=?; l=?"
	Private sPositionStyle As String = "none"
	Private sRawClasses As String = ""
	Private sRawStyles As String = ""
	Private sRawAttributes As String = ""
	Private sMarginAXYTBLR As String = "a=?; x=?; y=?; t=?; b=?; l=?; r=?"
	Private sPaddingAXYTBLR As String = "a=?; x=?; y=?; t=?; b=?; l=?; r=?"
	Private sParentID As String = ""
	Private bVisible As Boolean = True	'ignore
	Private bEnabled As Boolean = True	'ignore
	Public Tag As Object
	Private sBackgroundColor As String = "base-100"
	Private bBorder As Boolean = True
	Private sBorderColor As String = "base-300"
	Private sContentBackgroundColor As String = "base-100"
	Private sContentTextColor As String = ""
	Private sContentTextSize As String = "sm"
	Private bJoinItem As Boolean = False
	Private sOpenClose As String = "none"
	Private sRawContent As String = "Collapse Content"
	Private sRightIcon As String = "arrow"
	Private sRounded As String = "none"
	Private sShadow As String = "none"
	Private sTextColor As String = ""
	Private sTitle As String = "Collapse"
	Private sTitleBackgroundColor As String = ""
	Private sTitleTextColor As String = ""
	Public CONST OPENCLOSE_CLOSE As String = "close"
	Public CONST OPENCLOSE_NONE As String = "none"
	Public CONST OPENCLOSE_OPEN As String = "open"
	Public CONST RIGHTICON_ARROW As String = "arrow"
	Public CONST RIGHTICON_PLUS As String = "plus"
	Private bActive As Boolean = False
	Private sGroupName As String = ""
	Private sIcon As String = ""
	Private sIconColor As String = ""
	Private sIconSize As String = "32px"
	Private sContentClass As String = ""
	Private sTitleClass As String = "font-semibold"
End Sub
'initialize the custom view class
Public Sub Initialize (Callback As Object, Name As String, EventName As String)
	UI.Initialize(Me)
	mElement = Null
	mEventName = UI.CleanID(EventName)
	mName = UI.CleanID(Name)
	mCallBack = Callback
	CustProps.Initialize
	SetDefaults
End Sub

private Sub SetDefaults
	CustProps.Put("ParentID", "")
	CustProps.Put("GroupName", "")
	CustProps.Put("Icon", "")
	CustProps.Put("IconColor", "")
	CustProps.Put("IconSize", "32px")
	CustProps.Put("Title", "Collapse")
	CustProps.Put("RawContent", "Collapse Content")
	CustProps.Put("Active", False)
	CustProps.Put("RightIcon", "arrow")
	CustProps.Put("JoinItem", False)
	CustProps.Put("TitleBackgroundColor", "")
	CustProps.Put("TitleTextColor", "")
	CustProps.Put("ContentBackgroundColor", "base-100")
	CustProps.Put("ContentTextColor", "")
	CustProps.Put("ContentTextSize", "sm")
	CustProps.Put("TextColor", "")
	CustProps.Put("BackgroundColor", "base-100")
	CustProps.Put("Border", True)
	CustProps.Put("BorderColor", "base-300")
	CustProps.Put("OpenClose", "none")
	CustProps.Put("Rounded", "none")
	CustProps.Put("Shadow", "none")
	CustProps.Put("Visible", True)
	CustProps.Put("Enabled", True)
	CustProps.Put("PositionStyle", "none")
	CustProps.Put("Position", "t=?; b=?; r=?; l=?")
	CustProps.Put("MarginAXYTBLR", "a=?; x=?; y=?; t=?; b=?; l=?; r=?")
	CustProps.Put("PaddingAXYTBLR", "a=?; x=?; y=?; t=?; b=?; l=?; r=?")
	CustProps.Put("RawClasses", "")
	CustProps.Put("RawStyles", "")
	CustProps.Put("RawAttributes", "")
	CustProps.Put("ContentClass", "")
	CustProps.Put("TitleClass", "font-semibold")
End Sub

' returns the element id
Public Sub getID() As String
	Return mName
End Sub
'set properties from an outside source
Sub SetProperties(props As Map)
	CustProps = BANano.DeepClone(props)
	sParentID = CustProps.Get("ParentID")
End Sub

Sub GetProperties As Map
	Return CustProps
End Sub
'add this element to an existing parent element using current props
Public Sub AddComponent
	If sParentID = "" Then Return
	sParentID = UI.CleanID(sParentID)
	mTarget = BANano.GetElement("#" & sParentID)
	DesignerCreateView(mTarget, CustProps)
End Sub
'remove this element from the dom
Public Sub Remove()
	mElement.Remove
	BANano.SetMeToNull
End Sub
'set the parent id
Sub setParentID(s As String)
	s = UI.CleanID(s)
	sParentID = s
	CustProps.Put("ParentID", sParentID)
End Sub
'get the parent id
Sub getParentID As String
	Return sParentID
End Sub
'return the #ID of the element
Public Sub getHere() As String
	Return $"#${mName}"$
End Sub
'set Visible
Sub setVisible(b As Boolean)
	bVisible = b
	CustProps.Put("Visible", b)
	If mElement = Null Then Return
	UI.SetVisible(mElement, b)
End Sub
'get Visible
Sub getVisible As Boolean
	bVisible = UI.GetVisible(mElement)
	Return bVisible
End Sub
'set Enabled
Sub setEnabled(b As Boolean)
	bEnabled = b
	CustProps.Put("Enabled", b)
	If mElement = Null Then Return
	UI.SetEnabled(mElement, b)
End Sub
'get Enabled
Sub getEnabled As Boolean
	bEnabled = UI.GetEnabled(mElement)
	Return bEnabled
End Sub
'set Position Style
'options: static|relative|fixed|absolute|sticky|none
Sub setPositionStyle(s As String)
	sPositionStyle = s
	CustProps.put("PositionStyle", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetStyle(mElement, "position", s)
End Sub
Sub getPositionStyle As String
	Return sPositionStyle
End Sub
'set raw positions
Sub setPosition(s As String)
	sPosition = s
	CustProps.Put("Position", sPosition)
	If mElement = Null Then Return
	If s <> "" Then UI.SetPosition(mElement, sPosition)
End Sub
Sub getPosition As String
	Return sPosition
End Sub
Sub setAttributes(s As String)
	sRawAttributes = s
	CustProps.Put("RawAttributes", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetAttributes(mElement, sRawAttributes)
End Sub
'
Sub setStyles(s As String)
	sRawStyles = s
	CustProps.Put("RawStyles", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetStyles(mElement, sRawStyles)
End Sub
'
Sub setClasses(s As String)
	sRawClasses = s
	CustProps.put("RawClasses", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetClasses(mElement, sRawClasses)
End Sub
'
Sub setPaddingAXYTBLR(s As String)
	sPaddingAXYTBLR = s
	CustProps.Put("PaddingAXYTBLR", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetPaddingAXYTBLR(mElement, sPaddingAXYTBLR)
End Sub
'
Sub setMarginAXYTBLR(s As String)
	sMarginAXYTBLR = s
	CustProps.Put("MarginAXYTBLR", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetMarginAXYTBLR(mElement, sMarginAXYTBLR)
End Sub
'
Sub getAttributes As String
	Return sRawAttributes
End Sub
'
Sub getStyles As String
	Return sRawStyles
End Sub
'
Sub getClasses As String
	Return sRawClasses
End Sub
'
Sub getPaddingAXYTBLR As String
	Return sPaddingAXYTBLR
End Sub
'
Sub getMarginAXYTBLR As String
	Return sMarginAXYTBLR
End Sub
'code to design the view
Public Sub DesignerCreateView (Target As BANanoElement, Props As Map)
	mTarget = Target
	If Props <> Null Then
		CustProps = Props
		UI.SetProps(Props)
		'UI.ExcludeBackgroundColor = True
		'UI.ExcludeTextColor = True
		'UI.ExcludeVisible = True
		'UI.ExcludeEnabled = True
		'sBackgroundColor = Props.GetDefault("BackgroundColor", "base-100")
		'sBackgroundColor = UI.CStr(sBackgroundColor)
		'If sBackgroundColor = "base-100" Then sBackgroundColor = ""
		sBorderColor = Props.GetDefault("BorderColor", "base-300")
		sBorderColor = UI.CStr(sBorderColor)
		sContentBackgroundColor = Props.GetDefault("ContentBackgroundColor", "base-100")
		sContentBackgroundColor = UI.CStr(sContentBackgroundColor)
		sContentTextColor = Props.GetDefault("ContentTextColor", "")
		sContentTextColor = UI.CStr(sContentTextColor)
		sContentTextSize = Props.GetDefault("ContentTextSize", "sm")
		sContentTextSize = UI.CStr(sContentTextSize)
		If sContentTextSize = "none" Then sContentTextSize = ""
		bJoinItem = Props.GetDefault("JoinItem", False)
		bJoinItem = UI.CBool(bJoinItem)
		sOpenClose = Props.GetDefault("OpenClose", "none")
		sOpenClose = UI.CStr(sOpenClose)
		If sOpenClose = "none" Then sOpenClose = ""
		sRawContent = Props.GetDefault("RawContent", "Collapse Content")
		sRawContent = UI.CStr(sRawContent)
		sRightIcon = Props.GetDefault("RightIcon", "arrow")
		sRightIcon = UI.CStr(sRightIcon)
		sRounded = Props.GetDefault("Rounded", "none")
		sRounded = UI.CStr(sRounded)
		If sRounded = "none" Then sRounded = ""
		sShadow = Props.GetDefault("Shadow", "none")
		sShadow = UI.CStr(sShadow)
		If sShadow = "none" Then sShadow = ""
		sTextColor = Props.GetDefault("TextColor", "")
		sTextColor = UI.CStr(sTextColor)
		sTitle = Props.GetDefault("Title", "Collapse")
		sTitle = UI.CStr(sTitle)
		sTitleBackgroundColor = Props.GetDefault("TitleBackgroundColor", "")
		sTitleBackgroundColor = UI.CStr(sTitleBackgroundColor)
		sTitleTextColor = Props.GetDefault("TitleTextColor", "")
		sTitleTextColor = UI.CStr(sTitleTextColor)
		bActive = Props.GetDefault("Active", False)
		bActive = UI.CBool(bActive)
		sGroupName = Props.GetDefault("GroupName", "")
		sGroupName = UI.CStr(sGroupName)    
		sIcon = Props.GetDefault("Icon", "")
		sIconSize = Props.GetDefault("IconSize", "32px")
		sIconColor = Props.GetDefault("IconColor", "")
		sIcon = UI.CStr(sIcon)
		sIconColor = UI.CStr(sIconColor)
		sIconSize = UI.CStr(sIconSize)    
		sContentClass = Props.GetDefault("ContentClass", "")
		sContentClass = UI.cstr(sContentClass)
		bBorder = Props.GetDefault("Border", True)
		bBorder = UI.CBool(bBorder)
		sTitleClass = Props.GetDefault("TitleClass", "font-semibold")
		sTitleClass = UI.CStr(sTitleClass)
	End If
	'
	UI.AddClassDT("collapse")
	If bBorder = True Then UI.AddClassDT("border")
	If sBorderColor <> "" Then UI.AddBorderColorDT(sBorderColor)
	If bJoinItem = True Then UI.AddClassDT("join-item")
	If sOpenClose <> "" Then UI.UpdateClassDT("openclose", "collapse-" & sOpenClose)
	If sRightIcon <> "" Then UI.UpdateClassDT("righticon", "collapse-" & sRightIcon)
	If sRounded <> "" Then UI.AddRoundedDT(sRounded)
	If sShadow <> "" Then UI.AddShadowDT(sShadow)
	Dim xattrs As String = UI.BuildExAttributes
	Dim xstyles As String = UI.BuildExStyle
	Dim xclasses As String = UI.BuildExClass
	If sParentID <> "" Then
		'does the parent exist
		If BANano.Exists($"#${sParentID}"$) = False Then
			BANano.Throw($"${mName}.DesignerCreateView: '${sParentID}' parent does not exist!"$)
			Return
		End If
		mTarget.Initialize($"#${sParentID}"$)
	End If
	mElement = mTarget.Append($"[BANCLEAN]
	<div id="${mName}" class="${xclasses}" ${xattrs} style="${xstyles}">
		<input id="${mName}_check" type="radio"></input>
		<div id="${mName}_title" class="collapse-title">
			<svg-renderer id="${mName}_titleicon" style="pointer-events:none;" fit="false" fill="currentColor" data-js="enabled" class="hidden"></svg-renderer>
			<div id="${mName}_titletext">${sTitle}</div>
		</div>
		<div id="${mName}_content" class="collapse-content"></div>
	</div>"$).Get("#" & mName)
	setContentBackgroundColor(sContentBackgroundColor)
	setContentTextColor(sContentTextColor)
	setContentTextSize(sContentTextSize)
	setTitleBackgroundColor(sTitleBackgroundColor)
	setTitleTextColor(sTitleTextColor)
	setActive(bActive)
	setGroupName(sGroupName)
	setJoinItem(bJoinItem)
	setIcon(sIcon)
	setIconColor(sIconColor)
	setIconSize(sIconSize)
	setContentClass(sContentClass)
	setContent(sRawContent)
	setTitleClass(sTitleClass)
'	setVisible(bVisible)
	UI.OnEvent(mElement, "change", Me, "itemchange")
End Sub

Sub setTitleClass(s As String)				'ignoredeadcode
	sTitleClass = s
	CustProps.Put("TitleClass", s)
	If mElement = Null Then Return
	UI.AddClassByID($"${mName}_title"$, sTitleClass)
End Sub

Sub getTitleClass As String
	Return sTitleClass
End Sub

Sub setContentClass(s As String)			'ignoredeadcode
	sContentClass = s
	CustProps.Put("ContentClass", s)
	If mElement = Null Then Return
	UI.AddClassByID($"${mName}_content"$, sContentClass)
End Sub

Sub getContentClass As String
	Return sContentClass
End Sub	

Sub LinkExisting
	mElement.Initialize($"#${mName}"$)
	mTarget = BANano.GetElement("#" & sParentID)
	UI.OnEvent(mElement, "change", Me, "itemchange")
End Sub

Sub ClearContent
	If mElement = Null Then Return
	UI.ClearByID($"${mName}_content"$)
End Sub


Sub HideContent(skey As String)
	skey = UI.CleanID(skey)
	If mElement = Null Then Return
	UI.SetVisibleByID($"${skey}_${sParentID}_content"$, False)
End Sub

Sub ShowContent(skey As String)
	skey = UI.CleanID(skey)
	If mElement = Null Then Return
	UI.SetVisibleByID($"${skey}_${sParentID}_content"$, True)
End Sub

Sub setIcon(s As String)				'ignoredeadcode
	sIcon = s
	CustProps.Put("Icon", s)
	If mElement = Null Then Return
	UI.SetVisibleByID($"${mName}_titleicon"$, False)
	If s = "" Then Return
	UI.SetAttrByID($"${mName}_titleicon"$, "data-src", sIcon)
	UI.AddClassByID($"${mName}_title"$, "flex items-center gap-3")
	UI.SetVisibleByID($"${mName}_titleicon"$, True)
End Sub

Sub getIcon As String
	Return sIcon
End Sub

Sub setIconColor(s As String)				'ignoredeadcode
	sIconColor = s
	CustProps.Put("IconColor", s)
	If mElement = Null Then Return
	If s = "" Then Return
	UI.SetTextColorByID($"${mName}_titleicon"$, s)
End Sub

Sub getIconColor As String
	Return sIconColor
End Sub

Sub setIconSize(s As String)			'ignoredeadcode
	sIconSize = s
	CustProps.Put("IconSize", s)
	If mElement = Null Then Return
	If s = "" Then Return
	UI.SetWidthByID($"${mName}_titleicon"$, s)
	UI.SetHeightByID($"${mName}_titleicon"$, s)
End Sub

Sub getIconSize As String
	Return sIconSize
End Sub

private Sub itemchange(e As BANanoEvent)			'ignoredeadcode
	e.PreventDefault
	Dim itemName As String = UI.MvField(e.ID, 1, "_")
	BANano.CallSub(mCallBack, $"${sParentID}_change"$, Array(itemName))
End Sub


'set Group Name
Sub setGroupName(s As String)			'ignoredeadcode
	sGroupName = s
	CustProps.put("GroupName", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetAttrByID($"${mName}_check"$, "name", s)
End Sub

'get Group Name
Sub getGroupName As String
	Return sGroupName
End Sub

'set Active
Sub setActive(b As Boolean)		'ignoredeadcode
	bActive = b
	CustProps.put("Active", b)
	If mElement = Null Then Return
	UI.SetCheckedByID($"${mName}_check"$, b)
End Sub

'get Active
Sub getActive As Boolean
	Return bActive
End Sub

'set Background Color
Sub setBackgroundColor(s As String)
	sBackgroundColor = s
	CustProps.put("BackgroundColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetBackgroundColor(mElement, sBackgroundColor)
End Sub
'set Border Color
Sub setBorderColor(s As String)
	sBorderColor = s
	CustProps.put("BorderColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetColor(mElement, "bordercolor", "border", s)
End Sub
'set Content Background Color
Sub setContentBackgroundColor(s As String)			'ignoredeadcode
	sContentBackgroundColor = s
	CustProps.put("ContentBackgroundColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetBackgroundColorByID($"${mName}_content"$, s)
End Sub
'set Content Text Color
Sub setContentTextColor(s As String)				'ignoredeadcode
	sContentTextColor = s
	CustProps.put("ContentTextColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetTextColorByID($"${mName}_content"$, s)
End Sub
'set Content Text Size
'options: xs|none|sm|md|lg|xl|base|2xl|3xl|4xl|5xl|6xl|7xl|8xl|9xl
Sub setContentTextSize(s As String)			'ignoredeadcode
	sContentTextSize = s
	CustProps.put("ContentTextSize", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetTextSizeByID($"${mName}_content"$, s)
End Sub
'set Join Item
Sub setJoinItem(b As Boolean)			'ignoredeadcode
	bJoinItem = b
	CustProps.put("JoinItem", b)
	If mElement = Null Then Return
	If b = True Then
		UI.AddClass(mElement, "join-item")
	Else
		UI.RemoveClass(mElement, "join-item")
	End If
End Sub
'set Open Close
'options: close|none|open
Sub setOpenClose(s As String)
	sOpenClose = s
	CustProps.put("OpenClose", s)
	If mElement = Null Then Return
	If s <> "" Then UI.AddClass(mElement, "collapse-" & s)
End Sub
'set Raw Content
Sub setContent(s As String)			'ignoredeadcode
	sRawContent = s
	CustProps.put("RawContent", s)
	If mElement = Null Then Return
	UI.AppendByID($"${mName}_content"$, s)
End Sub
'set Right Icon
'options: arrow|plus
Sub setRightIcon(s As String)
	sRightIcon = s
	CustProps.put("RightIcon", s)
	If mElement = Null Then Return
	If s <> "" Then UI.AddClass(mElement, "collapse-" & s)
End Sub
'set Rounded
'options: none|rounded|2xl|3xl|full|lg|md|sm|xl|0
Sub setRounded(s As String)
	sRounded = s
	CustProps.put("Rounded", s)
	If mElement = Null Then Return
	UI.SetRounded(mElement, sRounded)
End Sub
'set Shadow
'options: shadow|sm|md|lg|xl|2xl|inner|none
Sub setShadow(s As String)
	sShadow = s
	CustProps.put("Shadow", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetShadow(mElement, s)
End Sub
'set Text Color
Sub setTextColor(s As String)
	sTextColor = s
	CustProps.put("TextColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetTextColor(mElement, sTextColor)
End Sub
'set Title
Sub setTitle(s As String)
	sTitle = s
	CustProps.put("Title", s)
	If mElement = Null Then Return
	UI.SetTextByID($"${mName}_titletext"$, s)
End Sub
'set Title Background Color
Sub setTitleBackgroundColor(s As String)			'ignoredeadcode
	sTitleBackgroundColor = s
	CustProps.put("TitleBackgroundColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetBackgroundColorByID($"${mName}_title"$, s)
End Sub
'set Title Text Color
Sub setTitleTextColor(s As String)				'ignoredeadcode
	sTitleTextColor = s
	CustProps.put("TitleTextColor", s)
	If mElement = Null Then Return
	If s <> "" Then UI.SetTextColorByID($"${mName}_title"$, s)
End Sub
'get Background Color
Sub getBackgroundColor As String
	Return sBackgroundColor
End Sub
'get Border Color
Sub getBorderColor As String
	Return sBorderColor
End Sub
'get Content Background Color
Sub getContentBackgroundColor As String
	Return sContentBackgroundColor
End Sub
'get Content Text Color
Sub getContentTextColor As String
	Return sContentTextColor
End Sub
'get Content Text Size
Sub getContentTextSize As String
	Return sContentTextSize
End Sub
'get Join Item
Sub getJoinItem As Boolean
	Return bJoinItem
End Sub
'get Open Close
Sub getOpenClose As String
	Return sOpenClose
End Sub
'get Raw Content
Sub getContent As String
	Return sRawContent
End Sub
'get Right Icon
Sub getRightIcon As String
	Return sRightIcon
End Sub
'get Rounded
Sub getRounded As String
	Return sRounded
End Sub
'get Shadow
Sub getShadow As String
	Return sShadow
End Sub
'get Text Color
Sub getTextColor As String
	Return sTextColor
End Sub
'get Title
Sub getTitle As String
	Return sTitle
End Sub
'get Title Background Color
Sub getTitleBackgroundColor As String
	Return sTitleBackgroundColor
End Sub
'get Title Text Color
Sub getTitleTextColor As String
	Return sTitleTextColor
End Sub
