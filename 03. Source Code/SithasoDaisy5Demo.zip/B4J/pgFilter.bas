﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'Static code module
Sub Process_Globals
	Private BANano As BANano		'ignore
	Private app As SDUI5App			'ignore
	Private SDUI5Filter1 As SDUI5Filter
End Sub


Sub Show
	App = pgIndex.app
	BANano.LoadLayout(app.PageView, "filterview")
	pgIndex.UpdateTitle("SDUI5Filter")
End Sub

Private Sub SDUI5Filter1_Change (Value As String)
	app.ShowToastSuccess(Value)
End Sub