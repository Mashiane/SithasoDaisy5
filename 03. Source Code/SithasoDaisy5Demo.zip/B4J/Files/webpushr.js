(function (w, d, s, id) {
  if (typeof w.webpushr !== "undefined") return;
  w.webpushr =
    w.webpushr ||
    function () {
      (w.webpushr.q = w.webpushr.q || []).push(arguments);
    };
  var js,
    fjs = d.getElementsByTagName(s)[0];
  js = d.createElement(s);
  js.id = id;
  js.async = 1;
  js.src = "https://cdn.webpushr.com/app.min.js";
  fjs.parentNode.appendChild(js);
})(window, document, "script", "webpushr-jssdk");
webpushr("setup", {
  key: "BKJS_h9HSPZN1mnd84-Qy9xJDsZq5lb5w5ZiZZ5QyDjF-sjnohH8EedErY_aP3XJ5RMn6TOy3jPrU5oeZbDUM6c",
});
