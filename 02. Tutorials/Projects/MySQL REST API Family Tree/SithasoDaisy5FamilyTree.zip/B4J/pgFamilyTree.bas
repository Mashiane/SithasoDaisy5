﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
Sub Process_Globals
	Private BANano As BANano 						'ignore
	Private app As SDUI5App							'ignore
	Private tblPeople As SDUI5Table			'ignore
	Private prefPeople As SDUI5Preferences	'ignore
	Private Mode As String = ""						'CRUD control
	Private toDeleteID As String						'id of item to delete
	Private toDeleteName As String					'name of item to delete
	Public name As String = "people"
	Public title As String = "People"
	Public icon As String = "./assets/page.svg"
	Public color As String = "#000000"
	'define foreign table maps
	Private PeopleObject As Map
	Private PeopleObjectM As Map
	Private SDUI5Column1 As SDUI5Column			'ignore
	Private SDUI5Column2 As SDUI5Column			'ignore
End Sub
'executed when the page is shown
Public Sub Show(MainApp As SDUI5App)
	app = MainApp
	app.PagePause
	'load the layout
	BANano.LoadLayout(app.PageView, "peopleview")
	'update navbar title on baselayout
	pgIndex.UpdateTitle("People")
	'lets set up the table
	tblPeople.Title = "People"
	BANano.Await(BuildTablePeople)
	'setup the preference dialog
	BANano.Await(BuildPreferencePeople)
	'mount the records
	BANano.Await(MountPeople)
	app.PageResume
End Sub
Private Sub BuildTablePeople
	'lets create the table columns
	tblPeople.Title = "People"
	tblPeople.HasAlphaChooser = True
	tblPeople.AlphaChooserColumn = "firstname"
	tblPeople.HasColumnChooser = True
	tblPeople.AddNewTooltip = "Add a Person"
	tblPeople.RefreshTooltip = "Refresh People"
	'tblPeople.DeleteAllTooltip = "Delete all People"
	'tblPeople.UploadToolbarTooltip = "Upload People"
	'tblPeople.DownloadToolbarTooltip = "Download People"
	tblPeople.BackTooltip = "Go back to Dashboard"
	tblPeople.HasEdit = True
	tblPeople.EditTooltip = "Edit Person"
	tblPeople.HasClone = True
	tblPeople.CloneTooltip = "Clone Person"
	tblPeople.HasDelete = True
	tblPeople.DeleteTooltip = "Delete Person"
	tblPeople.AlphaChooserColumn = "firstname"
	'lets build the table columns
	tblPeople.AddColumn("id", "#")
	tblPeople.SetColumnVisible("id", False)
	tblPeople.AddColumnAvatar("profiledisplay", "Profile Display", "60px", "circle")
	tblPeople.AddColumnBadge("gender", "Gender", "neutral")
	tblPeople.AddColumnTextBox("firstname", "First Name", False)
	tblPeople.AddColumnTextBox("middlename", "Middle Name", False)
	tblPeople.SetColumnVisible("middlename", False)
	tblPeople.AddColumnTextBox("lastname", "Last Name", False)
	tblPeople.AddColumnTextBox("suffix", "Suffix", False)
	tblPeople.SetColumnVisible("suffix", False)
	tblPeople.AddColumnDatePicker("dateofbirth", "Date of Birth", False, "Y-m-d", "F j, Y", False, False, False, "en")
	tblPeople.AddColumnCheckBox("isliving", "Living", "success", False)
	tblPeople.AddColumnTextBox("placeofbirth", "Place of Birth", False)
	tblPeople.SetColumnVisible("placeofbirth", False)
	tblPeople.AddColumnDatePicker("dateofdeath", "Date of Death", False, "Y-m-d", "F j, Y", False, False, False, "en")
	tblPeople.SetColumnVisible("dateofdeath", False)
	tblPeople.AddColumnTextBox("placeofdeath", "Place of Death", False)
	tblPeople.SetColumnVisible("placeofdeath", False)
	tblPeople.AddColumnSelect("father", "Father", False, True, CreateMap())
	tblPeople.SetColumnVisible("father", False)
	tblPeople.AddColumnSelect("mother", "Mother", False, True, CreateMap())
	tblPeople.SetColumnVisible("mother", False)
	tblPeople.AddColumnSelect("parentsstatus", "Parents Status", False, True, CreateMap("married":"Married","divorced":"Divorced","nevermarried":"Never Married","other":"Other","separated":"Separated"))
	tblPeople.SetColumnVisible("parentsstatus", False)
	'add edit/delete/clone buttons
	tblPeople.AddDesignerColums
	'move back button to the end
	tblPeople.MoveBackButton
End Sub
Private Sub BuildPreferencePeople
	prefPeople.AddPropertyTextBox("id", "#", "", True)
	prefPeople.SetPropertyVisible("id", False)
	prefPeople.AddPropertyAvatar("profiledisplay", "Profile Display", "60px", "circle", "./assets/mashy.jpg")
	prefPeople.SetPropertyAvatarRing("profiledisplay", False, "primary", "2", "base-100")
	prefPeople.SetPropertyAvatarOnline("profiledisplay", False, False)
	prefPeople.AddPropertyCamera("selectprofile", "Choose Profile Image", "60px", "38px", "error", "#ffffff")
	Dim genderoptions As Map
	genderoptions.Initialize
	genderoptions.put("Male", "Male")
	genderoptions.put("Female", "Female")
	prefPeople.AddPropertyRadioGroup("gender", "Gender", "Male", "neutral", "#22c55e", genderoptions)
	prefPeople.AddPropertyTextBox("firstname", "First Name", "", True)
	prefPeople.AddPropertyTextBox("middlename", "Middle Name", "", False)
	prefPeople.AddPropertyTextBox("lastname", "Last Name", "", True)
	prefPeople.AddPropertyTextBox("suffix", "Suffix", "", False)
	prefPeople.AddPropertyDatePicker("dateofbirth", "Date of Birth", "", False, "Y-m-d", "F j, Y", "en")
	prefPeople.AddPropertyCheckBox("isliving", "Living", True, "success")
	prefPeople.SetPropertyChecked("isliving", True)
	prefPeople.AddPropertyTextBox("placeofbirth", "Place of Birth", "", False)
	prefPeople.AddPropertyDatePicker("dateofdeath", "Date of Death", "", False, "Y-m-d", "F j, Y", "en")
	prefPeople.AddPropertyTextBox("placeofdeath", "Place of Death", "", False)
	Dim fatheroptions As Map
	fatheroptions.Initialize
	prefPeople.AddPropertySelect("father", "Father", "", False, fatheroptions)
	Dim motheroptions As Map
	motheroptions.Initialize
	prefPeople.AddPropertySelect("mother", "Mother", "", False, motheroptions)
	Dim parentsstatusoptions As Map
	parentsstatusoptions.Initialize
	parentsstatusoptions.put("married", "Married")
	parentsstatusoptions.put("divorced", "Divorced")
	parentsstatusoptions.put("nevermarried", "Never Married")
	parentsstatusoptions.put("other", "Other")
	parentsstatusoptions.put("separated", "Separated")
	prefPeople.AddPropertyFilter("parentsstatus", "Parents Status", "married", "neutral", "#22c55e", parentsstatusoptions)
	prefPeople.AddPropertyTextArea("clannames", "Clan Names", "", False, "4")
End Sub
'load People records from the database
Private Sub MountPeople
	SDUI5Column1.Size = 12
	SDUI5Column2.Visible = False
	'turn to add mode
	app.PagePause
	'load foreign tables
	BANano.Await(LoadPeople)
	'select People from the database
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	'link this api class to the data models
	db.SetSchemaFromDataModel(app.DataModels)
	'the api file will be api.php
	db.ApiFile = "api"
	'we are using an api key to make calls
	db.UseApiKey = True
	'specify the api key
	db.ApiKey = Main.APIKey
	'clear any where clauses
	db.CLEAR_WHERE
	'order by firstname
	db.ADD_ORDER_BY("firstname")
	'order by lastname
	db.ADD_ORDER_BY("lastname")
	'execute a select all
	BANano.Await(db.SELECT_ALL)
	'load foreign tables content on columns
	tblPeople.SetColumnOptions("father", PeopleObject)
	tblPeople.SetColumnOptions("mother", PeopleObject)
	'load the records to the table
	tblPeople.SetItemsPaginate(db.result)
	app.PageResume
End Sub
'executed when the add button is clicked on the table
Private Sub tblPeople_Add (e As BANanoEvent)
	e.preventdefault
	app.PagePause
	'load foreign tables
	BANano.Await(LoadPeople)
	BANano.Await(AddMode)
	app.PageResume
End Sub
'executed when the refresh button is clicked on the table
Private Sub tblPeople_Refresh (e As BANanoEvent)
	e.PreventDefault
	app.PagePause
	BANano.Await(MountPeople)
	app.pageresume
End Sub
'executed when the back button is clicked on the table
Private Sub tblPeople_Back (e As BANanoEvent)
	e.preventdefault
	'show the dashboard
	pgTreeSpider.Show(app)
	'Main.MyApp.ShowDashBoard
End Sub
'executed to prepare the preference dialog for adding a new record
private Sub AddMode
	'turn the mode to CREATE
	Mode = "C"
	SDUI5Column1.Size = 8
	SDUI5Column2.Visible = True
	'change the title of the pref dialog
	prefPeople.Title = "Add Person"
	BANano.Await(prefPeople.SetPropertySelectMap("father", PeopleObject))
	BANano.Await(prefPeople.SetPropertySelectMap("mother", PeopleObject))
	'set the default properties
	BANano.Await(prefPeople.SetPropertyBagDefaults)
	prefPeople.SetPropertyValue("id", app.NextID)
	'focus on the firstname
	prefPeople.SetPropertyFocus("firstname")
End Sub
'executed when a table row is being edited
private Sub EditMode(item As Map)
	'turn the mode to UPDATE
	Mode = "U"
	SDUI5Column1.Size = 8
	SDUI5Column2.Visible = True
	'change the title of the pref dialog
	prefPeople.Title = "Edit Person"
	BANano.Await(prefPeople.SetPropertySelectMap("father", PeopleObject))
	BANano.Await(prefPeople.SetPropertySelectMap("mother", PeopleObject))
	'set the properties
	BANano.Await(prefPeople.SetPropertyBagDefaults)
	item.Remove("selectprofile")
	prefPeople.PropertyBag = item
	'focus on the firstname
	prefPeople.SetPropertyFocus("firstname")
End Sub
'executed when a table row is being edited
private Sub CloneMode(item As Map)
	'turn the mode to UPDATE
	Mode = "C"
	SDUI5Column1.Size = 8
	SDUI5Column2.Visible = True
	'change the title of the pref dialog
	prefPeople.Title = "Add Person"
	BANano.Await(prefPeople.SetPropertySelectMap("father", PeopleObject))
	BANano.Await(prefPeople.SetPropertySelectMap("mother", PeopleObject))
	'set the properties
	BANano.Await(prefPeople.SetPropertyBagDefaults)
	item.Put("id", app.NextID)
	item.Remove("selectprofile")
	prefPeople.PropertyBag = item
	'focus on the firstname
	prefPeople.SetPropertyFocus("firstname")
End Sub
'executed when a table row edit button is clicked
Private Sub tblPeople_EditRow (Row As Int, item As Map)
	app.pagepause
	'load foreign tables
	BANano.Await(LoadPeople)
	Dim sID As String = item.Get("id")
	'execute a read from the database
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	'assign schema
	db.SetSchemaFromDataModel(app.DataModels)
	'use api key
	db.ApiFile = "api"
	db.UseApiKey = True
	db.ApiKey = Main.APIKey
	'read the record
	Dim rec As Map = BANano.Await(db.READ(sID))
	BANano.Await(EditMode(rec))
	app.pageresume
End Sub
'executed when a table row delete button is clicked
Private Sub tblPeople_DeleteRow (Row As Int, item As Map)
	'get the id and firstname of the item to delete
	toDeleteID = item.Get("id")
	toDeleteName = item.Get("firstname")
	'build the confirmation message
	Dim sMsg As String = $"<h2 class="text-2xl font-bold mt-2">${toDeleteName}</h2><br>Are you sure that you want to delete this Person?"$
	'wait for the user to confirm
	Dim bConfirm As Boolean = BANano.Await(app.ShowSwalConfirmWait("Confirm Delete", sMsg, "Yes", "No"))
	'the user has click No, exit
	If bConfirm = False Then Return
	app.pagepause
	'execute a delete using the id of the Person
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	db.SetSchemaFromDataModel(app.DataModels)
	db.ApiFile = "api"
	db.UseApiKey = True
	db.ApiKey = Main.APIKey
	BANano.Await(db.DELETE(toDeleteID))
	'reload the People
	BANano.Await(MountPeople)
	app.pageresume
End Sub
'executed when a table row clone button is clicked
Private Sub tblPeople_CloneRow (Row As Int, item As Map)
	app.PagePause
	'load foreign tables
	BANano.Await(LoadPeople)
	Dim sID As String = item.Get("id")
	'execute a read from the database
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	'assign schema
	db.SetSchemaFromDataModel(app.DataModels)
	'use api key
	db.ApiFile = "api"
	db.UseApiKey = True
	db.ApiKey = Main.APIKey
	'read the record
	Dim rec As Map = BANano.Await(db.READ(sID))
	BANano.Await(CloneMode(rec))
	app.PageResume
End Sub
'trap changes on table inline edits
Private Sub tblPeople_ChangeRow (Row As Int, Value As Object, Column As String, item As Map)
	item.Remove("selectprofile")
	'update the map column with value
	item.Put(Column, Value)
	'update the row contents at this position
	tblPeople.UpdateRow(Row, item)
	'
	'get the CurrentPage
	tblPeople.SaveLastAccessedPage
	'process the update Person
	'execute an update using the id of the Person
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	db.SetSchemaFromDataModel(app.DataModels)
	db.ApiFile = "api"
	db.UseApiKey = True
	db.ApiKey = Main.APIKey
	db.SetRecord(item)
	'execute an update
	Dim newid As String = banano.Await(db.UPDATE)
	If newid <> "" Then
		app.ShowSwalSuccess("The Person has been saved!")
	Else
		app.ShowSwalError("The Person could not be saved, please try again!")
		Return
	End If
	're-load the People
	banano.Await(MountPeople)
	'go to the last page
	banano.Await(tblPeople.ShowLastAccessedPage)
	tblPeople.SetRowEnsureVisible(Row)
End Sub
'executed when a Apply button is clicked on the preference dialog
Private Sub prefPeople_Yes_Click (e As BANanoEvent)
	e.PreventDefault
	'validate the property bag details
	Dim bValid As Boolean = BANano.Await(prefPeople.IsPropertyBagValid)
	If bValid = False Then
		BANano.Await(app.ShowSwalErrorWait("Person", "The person details are not complete!", "Ok"))
		Return
	End If
	'get the property bag fields as a map
	Dim pb As Map = BANano.Await(prefPeople.PropertyBag)
	pb.Remove("selectprofile")
	app.pagepause
	'open the database and save the record
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	db.SetSchemaFromDataModel(app.DataModels)
	db.ApiFile = "api"
	db.UseApiKey = True
	db.ApiKey = Main.APIKey
	'pass the map record
	db.SetRecord(pb)
	Select Case Mode
		Case "C"
			'create a new record
			Dim nid As String = BANano.Await(db.CREATE)
		Case "U"
			'update an existing record
			Dim nid As String = BANano.Await(db.UPDATE)
	End Select
	If nid <> "" Then
		app.ShowToastSuccess("Person has been created/updated.")
	Else
		app.ShowToastError("Person has NOT been created/updated. Please try again")
		Return
	End If
	BANano.Await(MountPeople)
	app.pageresume
End Sub
'executed when a Cancel button is clicked on the preference dialog
Private Sub prefPeople_No_Click (e As BANanoEvent)
	SDUI5Column1.Size = 12
	SDUI5Column2.Visible = False
End Sub
'this is executed when prefPeople_selectprofile_filechange is fired
Private Sub prefPeople_selectprofile_filechange(e As BANanoEvent)
	e.PreventDefault
	'has the file been selected
	Dim fileObj As Map = prefPeople.GetFileFromEvent(e)
	'the user cancelled, exit
	If BANano.IsNull(fileObj) Or BANano.IsUndefined(fileObj) Then Return
	'get file details
	Dim fileDet As FileObject
	fileDet = app.GetFileDetails(fileObj)
	'get the file name
	Dim fn As String = fileDet.FileName
	'you can check the size here
	Dim fs As Long = fileDet.FileSize
	Dim maxSize As Int = app.UI.ToKiloBytes(500)
	If fs > maxSize Then
		app.ShowToastError("File Size is limited to 500KB!")
		Return
	End If
	Dim fText As String = BANano.Await(app.readAsDataURLWait(fileObj))
	'Dim fJSON As Map = BANano.Await(app.readAsJsonWait(fileObj))
	'Dim fBuffer As Object = BANano.Await(app.readAsArrayBufferWait(fileObj))
	'Dim fText As String = BANano.Await(app.readAsTextWait(fileObj))
	'start uploading the file to assets folder
	'fileDet = UI.UploadFileWait(fileObj)
	'fileDet = UI.UploadFileOptionsWait(fileObj, "../assets", "n")
	prefPeople.SetPropertyValue("profiledisplay", fText)
End Sub
'Load People
Private Sub LoadPeople				'ignore
	PeopleObject.Initialize
	PeopleObjectM.Initialize
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	'link this api class to the data models
	db.SetSchemaFromDataModel(app.DataModels)
	'the api file will be api.php
	db.ApiFile = "api"
	'we are using an api key to make calls
	db.UseApiKey = True
	'specify the api key
	db.ApiKey = Main.APIKey
	'clear any where clauses
	db.CLEAR_WHERE
	'order by firstname
	db.ADD_ORDER_BY("firstname")
	'order by lastname
	db.ADD_ORDER_BY("lastname")
	db.ADD_FIELDS(Array("firstname","id","lastname"))
	'execute a select all
	BANano.Await(db.SELECT_ALL)
	Do While db.NextRow
		Dim rec As Map = db.Record
		Dim sid As String = db.GetString("id")
		Dim sfirstname As String = db.GetString("firstname")
		Dim slastname As String = db.GetString("lastname")
		PeopleObject.Put(sid, sfirstname & " " & slastname)
		PeopleObjectM.Put(sid, rec)
	Loop
End Sub
