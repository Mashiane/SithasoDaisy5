﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.2
@EndOfDesignText@
'Static code module
Sub Process_Globals
	Private BANano As BANano		'ignore
	Private app As SDUI5App			'ignore
	Private tsOrganogram As SDUI5TreeSpider
End Sub


Sub Show(MainApp As SDUI5App)
	app = MainApp
	BANano.LoadLayout(app.PageView, "treespiderview")
	pgIndex.UpdateTitle("My Family")
	'
	BANano.Await(MountPeople)
'	
'	tsOrganogram.AddItem("1", "3", "Troy Manuel", "Software Developer", "Alberta, Canada", "./assets/face3.jpg")
'	tsOrganogram.AddItem("1", "4", "Rebecca Oslon", "Software Developer", "London, United Kingdom", "./assets/face4.jpg")
'	tsOrganogram.AddItem("1", "5", "David Scheg", "Product Designer", "Jiaozian, China", "./assets/face5.jpg")
'	tsOrganogram.AddItem("2", "6", "James Zucks", "DevOps", "Accra, Ghana", "./assets/face6.jpg")
'	tsOrganogram.AddItem("2", "7", "Zu Po Xe", "Backend Developer", "Johanesburg, South Africa", "./assets/face7.jpg")
'	tsOrganogram.AddItem("2", "8", "Scott Ziagler", "FrontEnd Developer Intern", "", "./assets/face8.jpg")
'	tsOrganogram.AddItem("7", "9", "Xervia Allero", "FrontEnd Developer Intern", "", "./assets/face9.jpg")
'	tsOrganogram.AddItem("3", "10", "Adebowale Ajanlekoko", "Fullstack Developer", "", "./assets/face10.jpg")
	tsOrganogram.Refresh
End Sub

Private Sub MountPeople
	'turn to add mode
	app.PagePause
	'clear the family tree
	tsOrganogram.Clear	
	'select People from the database
	Dim db As SDUIMySQLREST
	db.Initialize(Me, "people", Main.ServerURL, "people")
	'link this api class to the data models
	db.SetSchemaFromDataModel(app.DataModels)
	'the api file will be api.php
	db.ApiFile = "api"
	'we are using an api key to make calls
	db.UseApiKey = True
	'specify the api key
	db.ApiKey = Main.APIKey
	'clear any where clauses
	db.CLEAR_WHERE
	db.ADD_ORDER_BY("father")
	db.ADD_ORDER_BY("dateofbirth")
	'order by firstname
	db.ADD_ORDER_BY("firstname")
	'order by lastname
	db.ADD_ORDER_BY("lastname")
	'execute a select all
	BANano.Await(db.SELECT_ALL)
	Do While db.NextRow
		Dim sid As String = db.GetString("id")
		Dim sfirstname As String = db.getstring("firstname")
		Dim slastname As String = db.GetString("lastname")
		Dim sprofiledisplay As String = db.GetString("profiledisplay")
		Dim sdateofbirth As String = db.GetString("dateofbirth")
		Dim sdateofdeath As String = db.getstring("dateofdeath")
		Dim sfather As String = db.GetString("father")
		Dim smother As String = db.getstring("mother")
		Dim splaceofbirth As String = db.GetString("placeofbirth")
		If sprofiledisplay = "" Then sprofiledisplay = "./assets/600by600.jpg"
		Dim xFromTo As String = ""
		Dim xDied As String = ""
		If sdateofbirth <> "" Then
			xFromTo = app.UI.NiceDate(sdateofbirth)
		End If
		If sdateofdeath <> "" Then
			xDied = app.UI.NiceDate(sdateofdeath)
		End If
		Dim myDates As List
		myDates.Initialize 
		myDates.Add(xFromTo)
		myDates.Add(xDied)
		Dim theDates As String = app.UI.Join(" - ", myDates)
		Dim xName As String = $"${sfirstname}, ${slastname}"$
		
		If sfather <> "" Then
			tsOrganogram.AddItem(sfather, sid, xName, theDates, splaceofbirth, sprofiledisplay)
		Else
			tsOrganogram.AddItem(smother, sid, xName, theDates, splaceofbirth, sprofiledisplay)
		End If	
	Loop
	app.PageResume
End Sub